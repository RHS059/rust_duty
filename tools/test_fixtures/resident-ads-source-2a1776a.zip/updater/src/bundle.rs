//! RDBND001 is a deterministic, uncompressed regular-file-only archive.
use crate::{invalid, Result, MAX_ASSET};
use std::{
    collections::HashSet,
    fs::{File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
};
pub const MAGIC: &[u8; 8] = b"RDBND001";
pub fn safe_path(value: &str) -> Result<PathBuf> {
    if value.len() > 240 || value.is_empty() || !value.is_ascii() || value.contains('\\') {
        return Err(invalid("unsafe bundle path"));
    }
    for component in value.split('/') {
        if component.is_empty()
            || component == "."
            || component == ".."
            || component.ends_with('.')
            || component.ends_with(' ')
            || !component
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b"._- ".contains(&b))
        {
            return Err(invalid("unsafe bundle path"));
        }
        let stem = component.split('.').next().unwrap().to_ascii_uppercase();
        if matches!(stem.as_str(), "CON" | "PRN" | "AUX" | "NUL")
            || (stem.len() == 4
                && (stem.starts_with("COM") || stem.starts_with("LPT"))
                && stem.as_bytes()[3].is_ascii_digit())
        {
            return Err(invalid("Windows device name in bundle"));
        }
    }
    if value.split('/').any(|part| {
        part.eq_ignore_ascii_case("private-assets")
            || part.eq_ignore_ascii_case(".rust-duty-updates")
            || part.eq_ignore_ascii_case("fps-arms.vrs")
            || part.eq_ignore_ascii_case("first-person.vrs")
    }) {
        return Err(invalid(
            "private asset and updater-state paths are forbidden in public update bundles",
        ));
    }
    let first = value.split('/').next().unwrap().to_ascii_lowercase();
    if matches!(
        first.as_str(),
        "settings.cfg"
            | ".rust-duty-updates"
            | "telemetry.csv"
            | "private-assets"
            | "user"
            | "userdata"
            | "saves"
            | "cache"
            | "versions"
            | "install.json"
            | "control.json"
            | "payload.rdb"
            | "version.json"
            | "launcher.lock"
            | "manifest.cache.json"
            | "status.json"
            | "launch.json"
            | "launcher-location.json"
    ) {
        return Err(invalid("bundle contains protected user/install data"));
    }
    Ok(PathBuf::from(value))
}
pub fn unpack(bundle: &Path, destination: &Path, entrypoint: &str) -> Result<()> {
    crate::reject_symlink(destination)?;
    read_bundle(bundle, entrypoint, |input, relative, mode, size| {
        let target = destination.join(relative);
        crate::safe_dir(target.parent().unwrap())?;
        crate::reject_symlink(&target)?;
        let mut output = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&target)?;
        crate::delta::copy_exact(input, &mut output, size, &mut [0; 65536])?;
        output.sync_all()?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(
                &target,
                std::fs::Permissions::from_mode(if mode == 1 { 0o755 } else { 0o644 }),
            )?;
        }
        #[cfg(not(unix))]
        let _ = mode;
        Ok(())
    })?;
    crate::sync_dir(destination)
}

/// Verify the extracted runtime byte-for-byte against the already authenticated
/// bundle. Never follow symlinks or trust mutable extracted asset files alone.
pub fn verify_extracted(
    bundle: &Path,
    destination: &Path,
    entrypoint: &str,
) -> Result<HashSet<PathBuf>> {
    crate::reject_symlink(destination)?;
    let mut verified = HashSet::new();
    read_bundle(bundle, entrypoint, |input, relative, _mode, size| {
        let target = destination.join(relative);
        crate::reject_symlink(&target)?;
        let mut extracted = File::open(&target)?;
        if !extracted.metadata()?.is_file() || extracted.metadata()?.len() != size {
            return Err(invalid("managed runtime file type or size mismatch"));
        }
        let mut expected = [0u8; 65536];
        let mut actual = [0u8; 65536];
        let mut remaining = size;
        while remaining > 0 {
            let count = remaining.min(expected.len() as u64) as usize;
            input.read_exact(&mut expected[..count])?;
            extracted.read_exact(&mut actual[..count])?;
            if expected[..count] != actual[..count] {
                return Err(invalid("managed runtime file differs from verified bundle"));
            }
            remaining -= count as u64;
        }
        verified.insert(relative.to_owned());
        Ok(())
    })?;
    Ok(verified)
}

fn read_bundle(
    bundle: &Path,
    entrypoint: &str,
    mut consume: impl FnMut(&mut File, &Path, u8, u64) -> Result<()>,
) -> Result<()> {
    crate::reject_symlink(bundle)?;
    let mut input = File::open(bundle)?;
    let length = input.metadata()?.len();
    if length > MAX_ASSET {
        return Err(invalid("oversized bundle"));
    }
    let mut magic = [0; 8];
    input.read_exact(&mut magic)?;
    if &magic != MAGIC {
        return Err(invalid("invalid bundle magic"));
    }
    let mut n = [0; 4];
    input.read_exact(&mut n)?;
    let count = u32::from_le_bytes(n);
    if count == 0 || count > 50_000 {
        return Err(invalid("invalid bundle file count"));
    }
    let mut seen = HashSet::new();
    let mut total = 0u64;
    let mut has_entry = false;
    for _ in 0..count {
        let mut n = [0; 2];
        input.read_exact(&mut n)?;
        let n = u16::from_le_bytes(n) as usize;
        if n == 0 || n > 240 {
            return Err(invalid("unsafe path length"));
        }
        let mut path = vec![0; n];
        input.read_exact(&mut path)?;
        let path = String::from_utf8(path).map_err(|_| invalid("non-UTF8 bundle path"))?;
        let relative = safe_path(&path)?;
        if !seen.insert(path.to_ascii_lowercase()) {
            return Err(invalid("duplicate/case-colliding bundle paths"));
        }
        let mut mode = [0];
        input.read_exact(&mut mode)?;
        if mode[0] > 1 {
            return Err(invalid("unsupported bundle file type/mode"));
        }
        let mut size = [0; 8];
        input.read_exact(&mut size)?;
        let size = u64::from_le_bytes(size);
        total = total
            .checked_add(size)
            .ok_or_else(|| invalid("bundle overflow"))?;
        if total > length {
            return Err(invalid("bundle declared size overflow"));
        }
        consume(&mut input, &relative, mode[0], size)?;
        if path == entrypoint {
            has_entry = true;
            if mode[0] != 1 {
                return Err(invalid("entrypoint must be executable"));
            }
        }
    }
    let mut tail = [0];
    if !has_entry || input.read(&mut tail)? != 0 {
        return Err(invalid("missing entrypoint or trailing bundle data"));
    }
    Ok(())
}

/// One-file RDBND001 image of an executable. This is the baseline `adopt` and
/// the in-game updater store for a build that is already running, so a content
/// delta can COPY those bytes instead of downloading them again.
pub fn write_single_executable(
    name: &str,
    source: &mut impl Read,
    source_len: u64,
    output: &mut impl Write,
) -> Result<()> {
    safe_path(name)?;
    if name.len() > u16::MAX as usize || source_len == 0 || source_len > MAX_ASSET - 1024 {
        return Err(invalid("invalid running executable size"));
    }
    output.write_all(MAGIC)?;
    output.write_all(&1u32.to_le_bytes())?;
    output.write_all(&(name.len() as u16).to_le_bytes())?;
    output.write_all(name.as_bytes())?;
    output.write_all(&[1u8])?;
    output.write_all(&source_len.to_le_bytes())?;
    crate::delta::copy_exact(source, output, source_len, &mut [0; 65536])?;
    let mut extra = [0u8; 1];
    if source.read(&mut extra)? != 0 {
        return Err(invalid(
            "running executable changed during baseline capture",
        ));
    }
    Ok(())
}
