import os,subprocess,json,hashlib,shutil,urllib.request,time
from pathlib import Path
root=Path("/content/rust-duty-gpu-20261012");current=root/"build-source";base=root/"baseline-source";base.mkdir()
b=json.loads((root/"build2-status.json").read_text());assert b["passed"]
packages=root/"packages";packages.mkdir()
candidate=packages/"candidate";candidate.mkdir()
exe=root/"target/release/vector-range";assert hashlib.sha256(exe.read_bytes()).hexdigest()==b["executable_sha256"];shutil.copy2(exe,candidate/"vector-range")
origin="adc270635ee2faa24fe66ee0dfaa85b0b617ba5c";changed=["src/authored_viewmodel.rs","src/weapon_model.rs"]
receipt={"schema":"rust-duty-colab-loader-pair-preparation/v1","candidate_origin":b["source"],"baseline_loader_origin":origin,"candidate_files":b["source_files"],"compiler":b["compiler"],"changed_files":changed,"started":time.time(),"passed":False}
env=dict(os.environ,CARGO_HOME=str(root/"cargo"),RUSTUP_HOME=str(root/"rustup"),RUSTUP_TOOLCHAIN="1.99.0",CARGO_TARGET_DIR=str(root/"target"),CI="true");assert "VR_WEAPON_ASSET" not in env
env["PATH"]=str(root/"cargo/bin")+":"+env["PATH"]
try:
 for name,h in b["source_files"].items():
  data=(current/name).read_bytes();assert hashlib.sha256(data).hexdigest()==h,name
  p=base/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 for name in changed:
  data=urllib.request.urlopen("https://raw.githubusercontent.com/RHS059/rust_duty/"+origin+"/"+name,timeout=60).read()
  assert data and b["source_files"][name]!=hashlib.sha256(data).hexdigest()
  (base/name).write_bytes(data)
 receipt["baseline_files"]={name:hashlib.sha256((base/name).read_bytes()).hexdigest() for name in b["source_files"]}
 assert sorted(name for name in b["source_files"] if b["source_files"][name]!=receipt["baseline_files"][name])==sorted(changed)
 (root/"pair-preparation.json").write_text(json.dumps(receipt,indent=2))
 subprocess.run(["cargo","build","--locked","--no-default-features","--features","wgpu-runtime","--release","--bin","vector-range"],cwd=base,env=env,check=True,timeout=1200)
 baseline=packages/"baseline";baseline.mkdir();shutil.copy2(exe,baseline/"vector-range")
 receipt["executables"]={name:{"bytes":(packages/name/"vector-range").stat().st_size,"sha256":hashlib.sha256((packages/name/"vector-range").read_bytes()).hexdigest()} for name in ["baseline","candidate"]}
 for name,h in b["source_files"].items():assert hashlib.sha256((current/name).read_bytes()).hexdigest()==h,name
 for name,h in receipt["baseline_files"].items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==h,name
 receipt["passed"]=True
except BaseException as e:receipt["error"]=repr(e)
finally:
 receipt["finished"]=time.time();(root/"pair-preparation.json").write_text(json.dumps(receipt,indent=2));print("PAIR_PREPARATION",json.dumps({k:v for k,v in receipt.items() if k not in ["candidate_files","baseline_files"]}),flush=True)
