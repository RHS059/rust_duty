import os, subprocess, json, time, hashlib, shutil
from pathlib import Path
root=Path("/content/rust-duty-gpu-20261012");source=root/"source";dest=root/"build-source"
env=dict(os.environ,GIT_TERMINAL_PROMPT="0",GIT_CONFIG_GLOBAL="/dev/null",GIT_CONFIG_NOSYSTEM="1",GIT_LFS_SKIP_SMUDGE="1",CARGO_HOME=str(root/"cargo"),RUSTUP_HOME=str(root/"rustup"),RUSTUP_TOOLCHAIN="1.99.0",CARGO_TARGET_DIR=str(root/"target"),CI="true")
assert "VR_WEAPON_ASSET" not in env
env["PATH"]=str(root/"cargo/bin")+":"+env["PATH"]
status={"source":"c111eba1bbd67b9988aeada4fbf9b2b528d43b65","tree":"02d3969b2f79e22571736a3651ee239b4b5e0d75","started":time.time(),"phase":"materialize-source","done":False}
def save():(root/"build2-status.json").write_text(json.dumps(status,indent=2))
def run(phase,args,cwd=None,timeout=1800):
 status["phase"]=phase;save();print("PHASE",phase,flush=True);return subprocess.run(args,cwd=cwd or root,env=env,check=True,timeout=timeout)
try:
 with (source/".git/info/sparse-checkout").open("a") as f:f.write("/THIRD_PARTY_LICENSES.txt\n/rust-toolchain\n/rust-toolchain.toml\n/.cargo/\n/.gitattributes\n/.gitignore\n/ui/\n/profiles/\n/settings.cfg\n/assets/sight_alignment.json\n/assets/animations.cfg\n")
 run("source-public-paths",["git","-C",str(source),"read-tree","-mu","HEAD"],timeout=120)
 assert subprocess.check_output(["git","-C",str(source),"rev-parse","HEAD^{tree}"],env=env,text=True).strip()==status["tree"]
 assert not (source/"assets/weapons").exists()
 dest.mkdir()
 for p in source.iterdir():
  if p.name in [".git","target"]:continue
  if p.is_dir():shutil.copytree(p,dest/p.name)
  elif p.is_file():shutil.copy2(p,dest/p.name)
 status["source_files"]={str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob("*") if p.is_file()}
 for rel,h in status["source_files"].items():
  raw=subprocess.check_output(["git","-C",str(source),"show","HEAD:"+rel],env=env)
  assert hashlib.sha256(raw).hexdigest()==h,rel
 status["compiler"]=subprocess.check_output(["rustc","--version","--verbose"],env=env,text=True)
 save()
 run("cargo-build",["cargo","build","--locked","--no-default-features","--features","wgpu-runtime","--release","--bin","vector-range"],cwd=dest)
 exe=root/"target/release/vector-range"
 status.update(executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),executable_bytes=exe.stat().st_size,passed=True)
 run("linkage",["ldd",str(exe)],timeout=20)
except BaseException as e:status.update(passed=False,error=repr(e));print("BUILD2_ERROR",repr(e),flush=True)
finally:status.update(done=True,finished=time.time());save();print("BUILD2_FINISHED",json.dumps({k:v for k,v in status.items() if k!="source_files"}),flush=True)
