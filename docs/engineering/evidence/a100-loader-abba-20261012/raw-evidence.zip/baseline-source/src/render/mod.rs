//! Backend-neutral CPU text and feature-gated native GPU rendering.
pub mod present_policy;
pub mod text;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct RuntimeDiagnostics {
    pub present_mode: present_policy::PresentModeRequest,
    pub gpu_timestamps: bool,
}

#[cfg(feature = "wgpu-runtime")]
pub(crate) mod gpu_timing;

#[cfg(feature = "wgpu-runtime")]
mod arena;
#[cfg(feature = "wgpu-runtime")]
mod backend;
#[cfg(feature = "wgpu-runtime")]
mod capture;
#[cfg(feature = "wgpu-runtime")]
pub(crate) mod device;
#[cfg(feature = "wgpu-runtime")]
mod frame;
#[cfg(feature = "wgpu-runtime")]
mod lines;
#[cfg(feature = "wgpu-runtime")]
mod mesh;
#[cfg(feature = "wgpu-runtime")]
mod plan;
#[cfg(feature = "wgpu-runtime")]
pub mod runtime;
#[cfg(feature = "wgpu-runtime")]
mod sprite2d;
#[cfg(feature = "wgpu-runtime")]
mod target;

#[cfg(feature = "wgpu-runtime")]
pub use backend::WgpuRenderer;
#[cfg(feature = "wgpu-runtime")]
pub use device::BackendSelection;

/// Source-driven diagnostic fixture; never used by gameplay or original captures.
#[cfg(feature = "wgpu-runtime")]
#[doc(hidden)]
pub mod finite_warp_probe;

#[cfg(feature = "wgpu-runtime")]
mod upload_cache;
#[cfg(all(test, feature = "wgpu-runtime"))]
mod upload_reuse_tests;
