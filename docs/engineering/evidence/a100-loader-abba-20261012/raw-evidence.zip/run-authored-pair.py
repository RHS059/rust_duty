"""Bounded Colab A100 Vulkan actual-loader ABBA comparison. No source edits."""
from pathlib import Path
import json,hashlib,shutil,subprocess,os,time,sys,signal
ROOT=Path("/content/rust-duty-gpu-20261012")
pair=json.loads((ROOT/"pair-preparation.json").read_text())
assets=json.loads((ROOT/"public-assets-receipt.json").read_text())
assert pair["passed"] and assets["passed"]
order=["baseline","candidate","candidate","baseline"]
result={"schema":"rust-duty-colab-authored-loader-abba/v1","source_pair_sha256":hashlib.sha256((ROOT/"pair-preparation.json").read_bytes()).hexdigest(),"asset_receipt_sha256":hashlib.sha256((ROOT/"public-assets-receipt.json").read_bytes()).hexdigest(),"order":order,"record_seconds_requested":30,"gpu_timestamps_requested":True,"input":"stationary after Enter; no movement or mouse replay","passed":False,"runs":[],"started":time.time()}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify_inputs():
 for variant,directory in [("candidate","build-source"),("baseline","baseline-source")]:
  for name,h in pair[variant+"_files"].items():assert sha(ROOT/directory/name)==h,(variant,name)
  assert sha(ROOT/"packages"/variant/"vector-range")==pair["executables"][variant]["sha256"]
 actual={str(p.relative_to(ROOT/"authored-assets")) for p in (ROOT/"authored-assets").rglob("*") if p.is_file()}
 assert actual==set(assets["files"])
 for name,row in assets["files"].items():assert sha(ROOT/"authored-assets"/name)==row["sha256"],name
def save():(ROOT/"authored-pair-result.json").write_text(json.dumps(result,indent=2))

def process_snapshot():
 rows={}
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   f=p.read_text().rsplit(') ',1)[1].split();rows[int(p.parent.name)]=(int(f[1]),int(f[19]),f[0])
  except (OSError,ValueError,IndexError):pass
 return rows
def track(pid,known):
 rows=process_snapshot();selected={pid} if pid in rows and pid in known and known[pid]==rows[pid][1] else set()
 selected|={p for p,start in known.items() if p in rows and rows[p][1]==start}
 while True:
  children={p for p,(parent,_,_) in rows.items() if parent in selected}
  if children<=selected:break
  selected|=children
 known.update({p:rows[p][1] for p in selected})
 return {p for p in selected if rows[p][2]!='Z'}
def cleanup_driver(proc,known,reason):
 cleanup={'reason':reason,'signals':[],'remaining':[]}
 for sig in (signal.SIGTERM,signal.SIGKILL):
  live=track(proc.pid,known)
  for pid in sorted(live,key=lambda x:x==proc.pid):
   now=process_snapshot().get(pid)
   if now is not None and now[1]==known.get(pid):
    try:os.kill(pid,sig);cleanup['signals'].append([pid,int(sig)])
    except ProcessLookupError:pass
  until=time.monotonic()+5
  while time.monotonic()<until and track(proc.pid,known):time.sleep(.1)
 cleanup['remaining']=sorted(track(proc.pid,known))
 try:proc.wait(timeout=2)
 except subprocess.TimeoutExpired:cleanup['driver_wait_timeout']=True
 return cleanup
def run_driver(path,log):
 proc=subprocess.Popen([sys.executable,str(path)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 initial=process_snapshot().get(proc.pid)
 known={proc.pid:initial[1]} if initial is not None else {}
 deadline=time.monotonic()+120
 try:
  while proc.poll() is None:
   track(proc.pid,known)
   if time.monotonic()>deadline:raise TimeoutError('owned driver deadline')
   time.sleep(.25)
  if proc.returncode:raise RuntimeError(('driver exit',proc.returncode))
  live=track(proc.pid,known)
  if live:raise RuntimeError(('driver left children',sorted(live)))
 except BaseException as e:
  result.setdefault('driver_cleanup',[]).append(cleanup_driver(proc,known,repr(e)));save();raise

def inventory(folder):
 paths=list(folder.rglob('*'));assert not any(p.is_symlink() for p in paths)
 return {str(p.relative_to(folder)):sha(p) for p in paths if p.is_file()}
def verify_outputs():
 for row in result['runs']:
  for name,expected in row.get('retained_outputs',{}).items():assert inventory(ROOT/name)==expected,('prior output changed',name)

try:
 verify_inputs()
 template=(ROOT/"vulkan-smoke3.py").read_text()
 for i,variant in enumerate(order,1):
  name=f"authored-r{i:02d}";work=ROOT/(name+"-work");work.mkdir()
  public_inputs={p:h for p,h in pair["candidate_files"].items() if p=="settings.cfg" or p.startswith(("ui/","profiles/"))}
  for p,h in public_inputs.items():
   dest=work/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/"build-source"/p,dest);assert sha(dest)==h
  script=template.replace('out=root/"vulkan-smoke3"',f'out=root/"{name}"')
  script=script.replace('source=root/"build-source";exe=root/"target/release/vector-range"',f'source=root/"{name}-work";exe=root/"packages/{variant}/vector-range"')
  script=script.replace("fccc181957a2cb064a3ca29539f194bc93170b795e1be3dff83b17169cc1ddde",pair["executables"][variant]["sha256"])
  script=script.replace('"--procedural-weapon"','"--animation-manifest="+str(root/"authored-assets/assets/animations.cfg")')
  script=script.replace("for i in range(10):","for i in range(30):")
  script=script.replace("procedural physical1080p Vulkan hardware surface/Record smoke; not authored performance acceptance","stationary authored loader comparison on A100 Vulkan; not RTX acceptance")
  script=script.replace('time.sleep(3);key("Return");time.sleep(2);key("F8")','''deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  assert game.poll() is None,("early_game_exit",game.returncode)
  log=(out/"game.log").read_text()
  assert not any(e in log for e in ["Authored viewmodel could not load:","Authored viewmodel playback failed:","Action clip timings:"]),log
  if "Loaded Blender-authored viewmodel:" in log:break
  time.sleep(.2)
 else:raise RuntimeError("No positive authored load within30seconds")
 time.sleep(3);key("Return");time.sleep(2);key("F8")''')
  path=ROOT/(name+"-driver.py");path.write_text(script)
  with (ROOT/(name+"-driver.log")).open("x") as log:
   run_driver(path,log)
  receipt=json.loads((ROOT/name/"receipt.json").read_text())
  sessions=list((work/"telemetry-sessions").glob("*/frames.json"))
  row={"index":i,"variant":variant,"receipt_sha256":sha(ROOT/name/"receipt.json"),"driver_sha256":sha(path),"normal_exit":receipt.get("game_exit"),"passed":False,"retained_outputs":{name:inventory(ROOT/name),name+"-work":inventory(work)}}
  result["runs"].append(row);save()
  assert receipt["passed"] and receipt["game_exit"]==0 and "error" not in receipt,receipt
  assert len(sessions)==1
  primary=json.loads(sessions[0].read_text())
  row.update(session=str(sessions[0].parent.relative_to(ROOT)),primary_sha256=sha(sessions[0]),summary=primary["summary"],status=primary["status"])
  assert primary["status"]=={"error":None,"state":"complete"} and primary["summary"]["interval_count"]>=100,primary["status"]
  log=(ROOT/name/"game.log").read_text()
  assert "Loaded Blender-authored viewmodel:" in log
  assert not any(e in log for e in ["Authored viewmodel could not load:","Authored viewmodel playback failed:","Action clip timings:"])
  for p,h in public_inputs.items():assert sha(work/p)==h,p
  verify_inputs();verify_outputs();row["passed"]=True;save();print("AUTHORED_RUN",json.dumps(row),flush=True)
 result["passed"]=True
except BaseException as e:result["error"]=repr(e)
finally:
 try:verify_inputs();verify_outputs();result["final_inputs_verified"]=True;result["final_outputs_verified"]=True
 except BaseException as e:result["final_input_error"]=repr(e);result["passed"]=False
 result["finished"]=time.time();save();print("AUTHORED_PAIR_FINISHED",json.dumps(result),flush=True)

