# Same-part resident coalescing A100 comparison

Source identity and exact bytes are pinned in bundle-receipt.json and source-bundle.json. Local equivalent: 760187c5dac88e407a1ac68414b6b05e7a624bbb.

One release Cargo invocation builds the game and the resident_coalesced_authored_contract example from the same exact source using the unchanged original Rust 1.99 toolchain and 77 public assets. The example embeds the source manifest SHA. No private assets, download, installation, or extra GPU probe is included.

Before any timed game leg, the controller executes the example once on actual A100 Vulkan with a 600-second owned-process limit. Its separate strict reader checks all 22 actual-loader pairs: original part boundaries, complete ordered immutable vertex/weight/texture records, pose/material state, CPU-reference transformed corners, and exact full-RGBA images. Historical CPU/resident equality and 4998-index gates remain unchanged; their known strict RGB failure is separate. Any native failure stops before benchmarking and retains all partial evidence.

Only after that native gate passes, exact stationary draw counts are taken from its manifest-0/12/24 cases. Legacy must be 86 draws (75 rigid, 11 skin); coalesced counts must reduce these and stay exactly fixed on every measured frame. The same game ELF is run legacy, coalesced, coalesced, legacy, with direct main target and visible authored rendering fixed. Warm cache, zero resident vertex/index uploads, world/HUD, simulation, A100 fingerprint, 1920x1080, Immediate presentation, timestamps, 30-second Record and post-Record screenshots are checked using the unchanged raw readers. No gain is assumed.

Fresh roots use the remote commit prefix from bundle-receipt.json:
/content/rust-duty-coalesced-viewmodel-package-332e389a-r1
/content/rust-duty-coalesced-viewmodel-build-332e389a-r1
/content/rust-duty-coalesced-viewmodel-pair-332e389a-r1

Reuse only assets_dir and cargo.path from the prior verified direct build pair-pins.json after receipt/hash verification. Build: python3 PACKAGE/build-viewmodel-isolation.py --build-root BUILD --source-bundle PACKAGE/source-bundle.zip --assets ASSETS --cargo CARGO. Require passed=true, final_inputs_verified=true, build_exit_code=0 and both pinned ELF hashes. Then: python3 PACKAGE/run-a100-viewmodel-pair.py --pins BUILD/pair-pins.json --run-root RUN.

No export or other workload overlaps native execution or performance recording. Secure compact report, 44 PNGs, build/driver/process receipts and performance summaries first after completion, then the lossless complete raw streams/archive. Preserve failures and partial outputs. No weakened assertions or silent retry.
