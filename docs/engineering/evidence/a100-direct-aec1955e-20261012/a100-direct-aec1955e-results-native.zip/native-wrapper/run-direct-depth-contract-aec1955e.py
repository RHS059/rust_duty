#!/usr/bin/env python3
"""Bounded follow-on native correctness test; no performance recording or export."""
import argparse, hashlib, importlib.util, json, os, re, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode=True
SOURCE='aec1955e93867fb88df7b0d51526e338b8375761'
TREE='a64256619f1f880ec9aa726ca6e2131e149d3efe'
GAME='4c8253a25d518a6e8605fe5691bcb900d377edc26374a8269737cb8e46f50665'
MANIFEST='4a30d2bdbf0f9c23d389e38bc504439178da59ad3387bdd5c56482a20e4a336b'
BUNDLE='d4a07bc66c3a5f9534894887ed29e6988a49d5784fc80b4330c84a0e82d84859'
TEST='render::frame::tests::native_depth_slices_preserve_clip_planes_and_ordered_fades'
PACKAGE_HASHES={'owned_process.py':'2b28991806d8d0541ca69ae115ef68486f487074177717bba2abd145921b0773','run-a100-viewmodel-pair.py':'db2a4fe04ab7a49deb4198895e2cff2b66660c1748760fa806766fa53052439f','original-assets.json':'756ad13125e39d67d669493a82d4f2959273dd9902c3752ef3ccde6744a9fa9b','original-preparation.json':'4c91ae198e8747379c29b81a245393165f255af69b89644d75efb917b81752c1','original-nvidia-vulkan.json':'3a24e06eee4d71613991833ea6ff0bd6ef4ed71c631af5440abfaca8d064b6b2','original-nvidia-egl.json':'4779640fbe3b520e5556675b0c9a13adae338f63ff05288d8b23cacc202fa207'}
CASES={'opaque-first':[255,0,0,255],'resident-first':[255,0,0,255],'near-clipped':[0,255,0,255],'far-clipped':[0,255,0,255],'ordered-fade':[128,127,0,255]}
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def select_test_artifact(text,source,build):
 records=[json.loads(line) for line in text.splitlines() if line.strip()]
 candidates=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('kind')==['lib'] and r['target'].get('name')=='vector_range' and r['target'].get('src_path')==str(source/'src/lib.rs') and r.get('profile',{}).get('test') is True and r.get('executable') and re.search(r'(^|[#/])vector-range(@|$)',r.get('package_id',''))]
 require(len(candidates)==1,'exactly one admitted library-test artifact required')
 artifact=candidates[0];path=Path(artifact['executable']);require(path.is_absolute() and path.parent==build/'target/release/deps','test executable outside retained release target')
 return artifact,path
def validate_native_output(stdout,stderr,images):
 require(re.search(r'(?m)^running 1 test\s*$',stdout) is not None,'exactly one test must run')
 require(re.search(r'(?m)^test result: ok\. 1 passed; 0 failed; 0 ignored;',stdout) is not None,'exactly one native test must pass')
 lines=[s for s in stderr.splitlines() if s.startswith('direct viewport-depth actual adapter: ')]
 require(len(lines)==1,'exactly one actual adapter receipt required')
 for token in ('name: "NVIDIA A100-SXM4-40GB"','vendor: 4318,','device: 8368,','device_type: DiscreteGpu,','driver: "NVIDIA"','driver_info: "580.82.07"','backend: Vulkan'):
  require(token in lines[0],'native actual adapter differs: '+token)
 require(images.is_dir() and not images.is_symlink(),'native image directory missing/unsafe')
 require({p.name for p in images.iterdir()}=={n+'.png' for n in CASES}|{'depth-slice-report.json'},'native output inventory differs')
 require(all(p.is_file() and not p.is_symlink() for p in images.iterdir()),'unsafe native output')
 records=json.loads((images/'depth-slice-report.json').read_text());require(isinstance(records,list) and len(records)==5,'five native case records required')
 require([r['case'] for r in records]==list(CASES),'native case order differs')
 from PIL import Image
 for r in records:
  require(r=={'case':r['case'],'center_rgba':CASES[r['case']],'world_and_hud_verified':True,'one_3d_draw_pass':True},'native case receipt differs')
  with Image.open(images/(r['case']+'.png')) as image:
   require(image.format=='PNG' and image.size==(64,64),'native PNG format/extent differs');rgba=image.convert('RGBA')
   require(list(rgba.getpixel((32,32)))==CASES[r['case']] and rgba.getpixel((8,32))==(0,255,0,255) and rgba.getpixel((2,2))==(255,255,255,255),'independent native pixel check failed')
 return {'actual_adapter':lines[0],'cases':records}
def main():
 p=argparse.ArgumentParser();p.add_argument('--package',type=Path,required=True);p.add_argument('--pins',type=Path,required=True);p.add_argument('--performance-root',type=Path,required=True);p.add_argument('--run-root',type=Path,required=True);p.add_argument('--images-root',type=Path,required=True);a=p.parse_args()
 package=a.package.resolve();pins_path=a.pins.resolve();performance=a.performance_root.resolve();root=a.run_root.absolute();images=a.images_root.absolute()
 require(sys.platform=='linux','Linux native contract required')
 for n,h in PACKAGE_HASHES.items():require(sha(package/n)==h,'reviewed package file changed: '+n)
 sys.path.insert(0,str(package));from owned_process import write,inventory,owned
 spec=importlib.util.spec_from_file_location('direct_pair',package/'run-a100-viewmodel-pair.py');controller=importlib.util.module_from_spec(spec);spec.loader.exec_module(controller)
 pins=json.loads(pins_path.read_text());source=Path(pins['source_dir']);build=source.parent;assets=Path(pins['assets_dir']);game=Path(pins['executable']['path']);cargo=Path(pins['cargo']['path']);rustc=Path(pins['compiler']['path'])
 require(pins['schema']=='rust-duty-viewmodel-isolation-pins/v1' and pins['source_commit']==SOURCE and pins['source_tree']==TREE and pins['executable']['sha256']==GAME,'source/tree/game pins differ')
 require(all(x.is_absolute() for x in (source,assets,game,cargo,rustc)) and source.name=='build-source' and game.parent==build and pins_path.parent==build,'build paths differ')
 require(pins['source_manifest']['sha256']==MANIFEST and pins['source_bundle']['sha256']==BUNDLE,'source bundle/manifest pins differ')
 perf=json.loads((performance/'result.json').read_text());require(perf['source']==SOURCE and perf['tree']==TREE and perf['executable_sha256']==GAME and perf['order']==['offscreen','direct','direct','offscreen'] and isinstance(perf.get('finished'),(int,float)) and perf['final_inputs_and_outputs_verified'] is True,'performance run must be terminal with matching preserved inputs')
 require(perf.get('passed') is True and perf.get('capture_protocol_passed') is True and perf.get('errors')==[] and len(perf.get('runs',[]))==4 and all(r.get('passed') is True and r.get('normal_exit')==0 for r in perf['runs']),'successful four-leg performance cleanup required before native launch')
 build_receipt=json.loads(Path(pins['build_receipt']['path']).read_text());controller.validate_build_receipt(build_receipt,pins)
 require(build_receipt['toolchain_hashes']=={'cargo':sha(cargo),'rustc':sha(rustc)},'native compiler binary differs from game build')
 require(not root.exists() and not root.is_symlink() and not images.exists() and not images.is_symlink(),'fresh exclusive native output paths required');root.mkdir(parents=False)
 result={'schema':'rust-duty-direct-native-contract/v1','source_commit':SOURCE,'source_tree':TREE,'game_executable_sha256':GAME,'test_name':TEST,'passed':False,'errors':[],'compile_timeout_seconds':600,'test_timeout_seconds':120}
 expected_source=None;expected_assets=None;test_exe=None;test_sha=None;retained={};outputs={};guard=None;env=None
 def check():
  for f,h in retained.items():require(sha(f)==h,'retained input changed: '+str(f))
  for f,record in outputs.items():require(inventory(f)==record,'retained output changed: '+str(f))
  require(sha(game)==GAME,'performance ELF changed')
  if expected_source is not None:require(inventory(source)==expected_source,'source changed')
  if expected_assets is not None:require(inventory(assets)==expected_assets,'assets changed')
  if test_exe is not None:require(sha(test_exe)==test_sha,'test ELF changed')
  if guard is not None:guard.check_environment(os.environ);guard.check_cargo_configuration(source,env)
  for label,path in (('cargo',cargo),('compiler',rustc)):
   require(subprocess.check_output([str(path),'-Vv'],cwd=source,env=env,text=True,timeout=30)==pins[label]['version'],'original toolchain changed: '+label)
 try:
  retained={Path(__file__).resolve():sha(__file__),pins_path:sha(pins_path),performance/'result.json':sha(performance/'result.json'),cargo:sha(cargo),rustc:sha(rustc)}
  for n,h in PACKAGE_HASHES.items():retained[package/n]=h
  for key in ('source_manifest','source_bundle','build_receipt'):
   f=Path(pins[key]['path']);require(f.is_absolute() and sha(f)==pins[key]['sha256'],'retained '+key+' differs');retained[f]=pins[key]['sha256']
  original=json.loads((package/'original-preparation.json').read_text());require(pins['compiler']['version']==original['compiler'] and pins['cargo']['version']==original['cargo'],'original toolchain required')
  manifest=json.loads(Path(pins['source_manifest']['path']).read_text());require(manifest['source_commit']==SOURCE and manifest['source_tree']==TREE,'source manifest identity differs')
  expected_source=inventory(source);require(expected_source['files']=={n:r['sha256'] for n,r in manifest['files'].items()},'source manifest inventory differs')
  expected_assets=inventory(assets);require(len(expected_assets['files'])==77 and expected_assets['files']==json.loads((package/'original-assets.json').read_text())['files'],'original asset inventory differs')
  sys.path.insert(0,str(source/'tools'));import run_cpu_image_preservation as guard
  xdg=root/'xdg';xdg.mkdir(mode=0o700)
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',CARGO_TARGET_DIR=str(build/'target'),LD_LIBRARY_PATH='/usr/lib64-nvidia',VK_ICD_FILENAMES=str(package/'original-nvidia-vulkan.json'),__EGL_VENDOR_LIBRARY_FILENAMES=str(package/'original-nvidia-egl.json'),XDG_RUNTIME_DIR=str(xdg),RUST_DUTY_DIRECT_TEST_OUTPUT=str(images));env['PATH']=str(cargo.parent)+':'+env['PATH']
  require(subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True,timeout=30).strip()=='NVIDIA A100-SXM4-40GB, 580.82.07','actual NVIDIA device/driver differs')
  check();result['runtime_env']={k:env[k] for k in ('CARGO_TARGET_DIR','LD_LIBRARY_PATH','VK_ICD_FILENAMES','__EGL_VENDOR_LIBRARY_FILENAMES','XDG_RUNTIME_DIR','RUST_DUTY_DIRECT_TEST_OUTPUT')}
  compile=owned([str(cargo),'test','--offline','--locked','--no-default-features','--features','wgpu-runtime','--release','--lib','--no-run','--message-format=json'],source,env,root/'compile-process',600)
  outputs[root/'compile-process']=inventory(root/'compile-process');require(compile.get('exit_code')==0,'native library-test compilation failed');check()
  artifact,test_exe=select_test_artifact((root/'compile-process/stdout.log').read_text(),source,build);require(test_exe.is_file() and not test_exe.is_symlink() and test_exe.read_bytes()[:4]==b'\x7fELF','native test ELF missing/unsafe');test_sha=sha(test_exe);result.update(compiler_artifact=artifact,test_executable_sha256=test_sha)
  native=owned([str(test_exe),'--exact',TEST,'--ignored','--nocapture','--test-threads=1'],source,env,root/'native-process',120)
  outputs[root/'native-process']=inventory(root/'native-process');require(native.get('exit_code')==0,'native pixel/depth/fade test failed')
  result.update(validate_native_output((root/'native-process/stdout.log').read_text(),(root/'native-process/stderr.log').read_text(),images));outputs[images]=inventory(images);check();result['passed']=True
 except BaseException as error:result['errors'].append(repr(error))
 finally:
  try:check();result['final_inputs_and_outputs_verified']=True
  except BaseException as error:result['errors'].append('final-check: '+repr(error));result['passed']=False;result['final_inputs_and_outputs_verified']=False
  result['retained_inputs']={str(f):h for f,h in retained.items()};result['retained_outputs']={str(f):r for f,r in outputs.items()}
  result['partial_outputs']={str(f):inventory(f) for f in (root/'compile-process',root/'native-process',images) if f.is_dir()}
  write(root/'result.json',result);print('DIRECT_NATIVE_FINISHED',result['passed'],result['errors'],flush=True)
 return 0 if result['passed'] else 1
if __name__=='__main__':sys.exit(main())
