#!/usr/bin/env python3
"""One isolated source-bound A100 authored correctness/probe run; no timing run."""
import argparse, hashlib, json, os, signal, shutil, stat, struct, subprocess, sys, time, zipfile
from pathlib import Path
sys.dont_write_bytecode = True
SOURCE = '047699250fdcd98700caff66cbc86c4adf585b87'
TREE = '576e98bf29ca56acdabaab26c37279f3695198d5'
BUNDLE_SHA = '12ac9afdbc294d210d126144064a4cd31e1172bf8f1f7ad315d86487d071c7dc'
MANIFEST_SHA = '2d1c00b40e9b895365dcf3236b7b0915d6b4fcfc632de99e1a34bc7f357e7a13'
def require(value, message):
    if not value: raise RuntimeError(message)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path, value): Path(path).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def inventory(root):
    require(root.is_dir() and not root.is_symlink(), 'unsafe directory')
    entries = list(root.rglob('*'))
    require(not any(p.is_symlink() for p in entries), 'symlink in inventory')
    return {'files': {str(p.relative_to(root)):sha(p) for p in sorted(entries) if p.is_file()},
            'directories': sorted(str(p.relative_to(root)) for p in entries if p.is_dir())}
def process_rows():
    rows={}
    for p in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields=p.read_text().rsplit(') ',1)[1].split()
            rows[int(p.parent.name)]=(int(fields[1]),int(fields[19]),fields[0])
        except (OSError,ValueError,IndexError): pass
    return rows
def track(pid, known):
    rows=process_rows()
    selected={p for p,start in known.items() if p in rows and rows[p][1]==start}
    while True:
        children={p for p,(parent,_,_) in rows.items() if parent in selected}
        if children <= selected: break
        selected |= children
    known.update({p:rows[p][1] for p in selected})
    return {p for p in selected if rows[p][2]!='Z'}
def owned(command, cwd, env, output, timeout):
    output.mkdir(); record={'command':list(map(str,command)), 'cwd':str(cwd),'timeout_seconds':timeout,'started':time.time()}
    proc=None; known={}
    try:
        with (output/'stdout.log').open('xb') as stdout, (output/'stderr.log').open('xb') as stderr:
            proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,start_new_session=True)
            row=process_rows().get(proc.pid)
            record['initial_process_identity_verified']=row is not None
            require(row is not None,'could not establish owned process start identity; no unverified PID will be signaled')
            known={proc.pid:row[1]}
            record['pid']=proc.pid; write(output/'process.json',record)
            deadline=time.monotonic()+timeout
            while proc.poll() is None:
                track(proc.pid,known)
                if time.monotonic()>deadline: raise TimeoutError('owned process deadline')
                time.sleep(.1)
            record['exit_code']=proc.returncode
            require(not track(proc.pid,known),'owned process left live descendants')
    except BaseException as error:
        record['error']=repr(error)
        if proc:
            cleanup={'signals':[]}
            for sig in (signal.SIGTERM,signal.SIGKILL):
                for pid in sorted(track(proc.pid,known),key=lambda p:p==proc.pid):
                    row=process_rows().get(pid)
                    if row and row[1]==known.get(pid):
                        try: os.kill(pid,sig); cleanup['signals'].append([pid,int(sig)])
                        except ProcessLookupError: pass
                until=time.monotonic()+5
                while time.monotonic()<until and track(proc.pid,known): time.sleep(.1)
            cleanup['remaining']=sorted(track(proc.pid,known))
            try: proc.wait(timeout=2)
            except subprocess.TimeoutExpired: cleanup['wait_timeout']=True
            record['cleanup']=cleanup
        raise
    finally:
        record['finished']=time.time();write(output/'process.json',record)
    return record


def unorm_shader(source, fixture):
    shader=fixture.vertex_probe_shader(source,'current','rigid',264)
    call='let actual = original_vs_rigid(input);'
    require(shader.count(call)==1,'conversion shader entry differs')
    return shader.replace(call,'let actual = byte_probe(input);') + (
        '\nfn byte_probe(input: RigidInput) -> VertexOutput {\n'
        'var output: VertexOutput;\n'
        'let exact = unorm8_exact(u32(input.position.x));\n'
        'output.position = vec4<f32>(0.0,0.0,0.0,1.0);\n'
        'output.uv = vec2<f32>(0.0);\n'
        'output.color = vec4<f32>(exact,color_byte(input.position.y),exact,exact);\n'
        'return output;\n}\n')

def validate_conversion(output, source, fixture, matrix):
    require(inventory(output)['directories']==[] and set(inventory(output)['files'])=={'unorm-byte-report.json'},'conversion output inventory differs')
    report=matrix.json_read(output/'unorm-byte-report.json',limit=256*1024)
    require(set(report)=={'schema','production_shader_sha256','probe_shader_sha256','byte_count','boundary_count','rows'},'conversion report fields differ')
    require(report['schema']=='rust-duty-exact-unorm-byte-contract/v1','conversion schema differs')
    require(type(report['byte_count']) is int and report['byte_count']==256 and type(report['boundary_count']) is int and report['boundary_count']==8,'conversion counts differ')
    require(report['production_shader_sha256']==sha(source/'src/render/resident.wgsl'),'conversion production shader differs')
    require(report['probe_shader_sha256']==hashlib.sha256(unorm_shader(source,fixture).encode()).hexdigest(),'conversion generated shader differs')
    bits=lambda value:struct.unpack('<I',struct.pack('<f',value))[0]
    inputs=[(byte,bits((byte+.25)/255.)) for byte in range(256)]
    inputs += [(0,bits(-1.)),(0,0xff800000),(0,0x7fc00000),(0,0x80000000),(0,1),(255,bits(1.)),(255,0x7f800000),(255,bits(2.))]
    require(type(report['rows']) is list and len(report['rows'])==264,'conversion row count differs')
    for row,(byte,input_bits) in zip(report['rows'],inputs):
        require(type(row) is dict and set(row)=={'byte','input_bits','expected_bits','cpu_unorm8x4_bits','shader_bits'},'conversion row fields differ')
        for key in ('byte','input_bits','expected_bits'):
            require(type(row[key]) is int and 0<=row[key]<=0xffffffff,'conversion word type/range differs')
        expected=bits(byte/255.)
        require(row['byte']==byte and row['input_bits']==input_bits and row['expected_bits']==expected,'conversion input/oracle differs')
        for key in ('cpu_unorm8x4_bits','shader_bits'):
            require(type(row[key]) is list and len(row[key])==4 and all(type(v) is int and 0<=v<=0xffffffff for v in row[key]),'conversion vector differs')
            require(row[key]==[expected]*4,'conversion actual words differ from independent oracle')
    return {'schema':report['schema'],'byte_count':256,'boundary_count':8,'report_sha256':sha(output/'unorm-byte-report.json'),'passed':True}

def strict_device(log, matrix, detail):
    prefix='renderer graphics_device_evidence='
    lines=[v[len(prefix):] for v in log.read_text().splitlines() if v.startswith(prefix)]
    require(len(lines)==1,'exactly one device record required')
    device=json.loads(lines[0],object_pairs_hook=matrix.frames._unique,parse_constant=matrix.frames._constant)
    matrix.frames._finite_tree(device)
    detail.validate_instance_descriptor({'identity':{'runtime_observed':{'actual_adapter':device}}})
    require(device['backend']=='Vulkan' and device['device_type']=='DiscreteGpu' and type(device['vendor_id']) is int and device['vendor_id']==4318 and type(device['device_id']) is int and device['device_id']==8368,'actual Vulkan hardware differs')
    require(device['actual_fingerprint']=={'backend':'vulkan','name':'NVIDIA A100-SXM4-40GB','vendor_id':4318,'device_id':8368,'device_type':'DiscreteGpu'},'actual device fingerprint differs')
    require(device['force_fallback_requested'] is False and device['gpu_timestamp_features_enabled'] is False and device['requested_fingerprint'] is None and device['selection_mode']=='automatic','headless adapter selection differs')
    require(device['name']=='NVIDIA A100-SXM4-40GB' and device['driver']=='NVIDIA' and device['driver_info']=='580.82.07','actual Vulkan driver differs')
    require(device['instance_descriptor']['flags_bits']==32 and device['instance_descriptor']['application_debug_assertions'] is False,'release descriptor differs')
    require(device['present_mode'] is None and device['present_policy'] is None and device['gpu_timestamps_requested'] is False,'original headless fixture policy differs')
    return device

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--run-root',type=Path,required=True)
    parser.add_argument('--source-bundle',type=Path,required=True)
    parser.add_argument('--assets',type=Path,required=True)
    parser.add_argument('--cargo',type=Path,required=True)
    args=parser.parse_args()
    require(sys.platform=='linux','Linux host required')
    root=args.run_root.absolute(); assets=args.assets.resolve(); bundle=args.source_bundle.resolve();cargo=args.cargo.resolve()
    require(not root.exists() and not root.is_symlink(),'run directory must be a fresh exclusive leaf')
    require(sha(bundle)==BUNDLE_SHA,'source bundle digest differs')
    root.mkdir(parents=False)
    result={'schema':'rust-duty-a100-exact-color-probe-run/v1','source':SOURCE,'tree':TREE,
            'passed':False,'conversion_gate_passed':False,'image_gate_passed':False,'probe_completed':False,'started':time.time(),
            'scope':'isolated exhaustive UNORM conversion plus fixed authored correctness and diagnostic readback; no frame-rate measurement',
            'controller_sha256':sha(__file__),'source_bundle_sha256':BUNDLE_SHA,'errors':[]}
    retained={}; retained_dirs={}; expected_source=None; expected_assets=None; exe=None;exe_hash=None;env=None
    def freeze(path):
        retained_dirs[path]=inventory(path)
    def check():
        require(sha(__file__)==result['controller_sha256'] and sha(bundle)==BUNDLE_SHA,'controller/bundle changed')
        if expected_source is not None:
            require(inventory(source)==expected_source,'source changed')
            pair.check_cargo_configuration(source,env)
            require(subprocess.check_output([str(rustc),'-Vv'],cwd=source,env=env,text=True,timeout=30)==compiler,'compiler changed')
            require(subprocess.check_output([str(cargo),'-Vv'],cwd=source,env=env,text=True,timeout=30)==cargo_version,'Cargo changed')
        if expected_assets is not None: require(inventory(assets)==expected_assets,'runtime assets changed')
        for p,h in retained.items(): require(sha(p)==h,'retained input changed: '+str(p))
        for p,h in retained_dirs.items(): require(inventory(p)==h,'retained outputs changed: '+str(p))
        if exe_hash is not None: require(sha(exe)==exe_hash,'executable changed')
    try:
        with zipfile.ZipFile(bundle) as archive:
            names=archive.namelist(); require(len(names)==len(set(names)),'duplicate source entry')
            manifest=json.loads(archive.read('source-bundle.json'))
            require(hashlib.sha256(archive.read('source-bundle.json')).hexdigest()==MANIFEST_SHA,'source manifest differs')
            expected={'source-bundle.json','original-assets.json','original-resident-inputs.json','original-nvidia-vulkan.json','original-nvidia-egl.json'} | {'build-source/'+n for n in manifest['files']}
            require(set(names)==expected and archive.testzip() is None,'source archive inventory/CRC differs')
            require(manifest['source_commit']==SOURCE and manifest['source_tree']==TREE,'source identity differs')
            for name in names:
                relative=Path(name);require(not relative.is_absolute() and '..' not in relative.parts,'unsafe source path')
                destination=root/relative;destination.parent.mkdir(parents=True,exist_ok=True)
                raw=archive.read(name)
                if name.startswith('build-source/'):
                    bound=manifest['files'][name[len('build-source/'):]]
                    require(len(raw)==bound['bytes'] and hashlib.sha256(raw).hexdigest()==bound['sha256'],'source bytes differ')
                    require(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==bound['git_blob_sha1'],'Git blob differs')
                destination.write_bytes(raw)
                if name.startswith('build-source/'): destination.chmod(int(bound['git_mode'],8)&0o777)
        source=root/'build-source'; require(not (source/'assets').exists(),'build must not load implicit assets')
        sys.path.insert(0,str(source/'tools'))
        import run_cpu_image_preservation as pair
        import run_resident_authored_contract as fixture
        import summarize_cpu_encode_detail as detail
        import performance_matrix as matrix
        pair.check_environment(os.environ)
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',CARGO_TARGET_DIR=str(root/'target'))
        require(cargo.is_file() and cargo.name=='cargo','direct Cargo binary required')
        rustc=cargo.with_name('rustc');require(rustc.is_file(),'same-directory compiler missing')
        env['PATH']=str(cargo.parent)+':'+env['PATH']
        pair.check_cargo_configuration(source,env)
        original=json.loads((root/'original-resident-inputs.json').read_text())
        compiler=subprocess.check_output([str(rustc),'-Vv'],cwd=source,env=env,text=True,timeout=30)
        cargo_version=subprocess.check_output([str(cargo),'-Vv'],cwd=source,env=env,text=True,timeout=30)
        require(compiler==original['compiler'],'exact original Rust 1.99 Linux compiler required')
        require(cargo_version.startswith('cargo 1.99.0 (5f94df478 2026-08-27)\n') and '\nhost: x86_64-unknown-linux-gnu\n' in cargo_version,'exact Cargo version/host required')
        expected_source=inventory(source)
        expected_assets=inventory(assets)
        asset_receipt=json.loads((root/'original-assets.json').read_text())
        require(expected_assets['files']==asset_receipt['files'],'original 77-file public asset inventory required')
        require(not (assets/'assets/weapons').exists(),'private weapon assets excluded')
        gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True,timeout=30).strip()
        require(gpu=='NVIDIA A100-SXM4-40GB, 580.82.07','actual NVIDIA adapter/driver changed')
        env.update(LD_LIBRARY_PATH='/usr/lib64-nvidia',VK_ICD_FILENAMES=str(root/'original-nvidia-vulkan.json'),__EGL_VENDOR_LIBRARY_FILENAMES=str(root/'original-nvidia-egl.json'))
        receipt={'source':SOURCE,'tree':TREE,'source_manifest_sha256':MANIFEST_SHA,'files':expected_source['files'],
                 'compiler':compiler,'cargo':cargo_version,'profile':'release','default_features':False,'features':['wgpu-runtime'],
                 'gpu':gpu,'asset_receipt_sha256':sha(root/'original-assets.json'),'assets':expected_assets,
                 'source_bundle_sha256':BUNDLE_SHA,'controller_sha256':result['controller_sha256'],
                 'configuration_files':{p.name:sha(p) for p in root.glob('original-*.json')}}
        write(root/'inputs.json',receipt); receipt_hash=sha(root/'inputs.json')
        retained={p:sha(p) for p in root.glob('*.json')};env['PASS_SUBMISSION_SOURCE_SHA256']=receipt_hash
        check()
        build=owned([str(cargo),'build','--locked','--no-default-features','--features','wgpu-runtime','--release','--example','resident_authored_contract'],source,env,root/'build',1200)
        freeze(root/'build');require(build.get('exit_code')==0,'fixture build failed')
        built=root/'target/release/examples/resident_authored_contract'
        exe=root/'resident_authored_contract';shutil.copyfile(built,exe);exe.chmod(0o755);exe_hash=sha(exe)
        require(exe_hash==sha(built),'retained executable copy differs')
        write(root/'executable.json',{'sha256':exe_hash,'path':str(exe),'source_receipt_sha256':receipt_hash})
        retained[root/'executable.json']=sha(root/'executable.json');check()
        native_build=owned([str(cargo),'test','--locked','--no-default-features','--features','wgpu-runtime','--release','--lib','--no-run','--message-format=json'],source,env,root/'conversion-build',1200)
        freeze(root/'conversion-build');require(native_build.get('exit_code')==0,'native conversion build failed')
        messages=[json.loads(line,object_pairs_hook=matrix.frames._unique,parse_constant=matrix.frames._constant) for line in (root/'conversion-build/stdout.log').read_text().splitlines() if line.strip()]
        native_artifacts=[v for v in messages if v.get('reason')=='compiler-artifact' and v.get('profile',{}).get('test') is True and v.get('executable')]
        require(len(native_artifacts)==1,'expected one fresh library test executable')
        native_built=Path(native_artifacts[0]['executable']).resolve()
        require(native_built.is_relative_to(root/'target') and native_built.is_file(),'native conversion executable escapes target')
        native_exe=root/'native_conversion_contract';shutil.copyfile(native_built,native_exe);native_exe.chmod(0o755)
        native_hash=sha(native_exe);require(native_hash==sha(native_built),'native retained executable differs')
        retained[native_exe]=native_hash
        write(root/'conversion-executable.json',{'sha256':native_hash,'path':str(native_exe),'source_receipt_sha256':receipt_hash,'cargo_artifact':native_artifacts[0]})
        retained[root/'conversion-executable.json']=sha(root/'conversion-executable.json');check()
        conversion_output=root/'conversion-output'
        require(not conversion_output.exists(),'stale conversion output')
        conversion_env=dict(env,RUST_DUTY_RESIDENT_TEST_OUTPUT=str(conversion_output))
        try:
            conversion=owned([str(native_exe),'render::resident_tests::native_exact_unorm_byte_conversion','--exact','--ignored','--nocapture','--test-threads=1'],source,conversion_env,root/'conversion-process',300)
            result['conversion_process_exit_code']=conversion['exit_code']
            for directory in (root/'conversion-process',conversion_output):
                if directory.is_dir():freeze(directory)
            result['conversion_device']=strict_device(root/'conversion-process/stderr.log',matrix,detail)
            result['conversion_summary']=validate_conversion(conversion_output,source,fixture,matrix)
            require(conversion['exit_code']==0,'native conversion process failed')
            require('test result: ok. 1 passed; 0 failed; 0 ignored;' in (root/'conversion-process/stdout.log').read_text(),'exactly one native conversion test did not pass')
            result['conversion_gate_passed']=True
        except Exception as error:
            result['errors'].append({'stage':'conversion','error':repr(error)})
        finally:
            for directory in (root/'conversion-process',conversion_output):
                if directory.is_dir() and directory not in retained_dirs:freeze(directory)
        # A conversion failure does not suppress the original image/probe evidence.
        check()
        # Both leaves must remain absent: the Rust fixture creates them exclusively.
        captures=root/'captures'; probe=root/'vertex-probe'
        require(not captures.exists() and not probe.exists(),'stale fixture output')
        process=owned([str(exe),'--manifest',str(assets/'assets/animations.cfg'),'--output-dir',str(captures),'--vertex-probe-dir',str(probe)],source,env,root/'process',900)
        freeze(root/'process')
        for directory in (captures,probe):
            if directory.is_dir(): freeze(directory)
        report=fixture.read_report(captures/'report.json')
        result['process_exit_code']=process['exit_code']; result['parent_report_sha256']=sha(captures/'report.json')
        result['producer_report_passed']=report.get('passed')
        try:
            result['strict_image_summary']=fixture.validate_outputs(captures,report,receipt_hash)
            result['image_gate_passed']=True
        except Exception as error: result['errors'].append({'stage':'strict-image','error':repr(error)})
        try:
            result['probe_summary']=fixture.validate_vertex_probe(probe,report,receipt_hash,source)
            result['probe_completed']=result['probe_summary']['diagnostic_completed']
        except Exception as error: result['errors'].append({'stage':'vertex-probe','error':repr(error)})
        try:
            device=fixture.device_evidence(root/'process/stderr.log',report)
            require(strict_device(root/'process/stderr.log',matrix,detail)==device,'strict device record differs')
            result['actual_device']=device
        except Exception as error: result['errors'].append({'stage':'actual-device','error':repr(error)})
        result['passed']=process['exit_code']==0 and result['conversion_gate_passed'] and result['image_gate_passed'] and result['probe_completed'] and not result['errors']
    except BaseException as error:
        result['errors'].append({'stage':'run','type':type(error).__name__,'error':repr(error)})
    finally:
        try: check();result['final_inputs_and_outputs_verified']=True
        except BaseException as error:
            result['final_inputs_and_outputs_verified']=False;result['errors'].append({'stage':'final-check','error':repr(error)});result['passed']=False
        result['finished']=time.time()
        result['retained_outputs']={str(p.relative_to(root)):v for p,v in retained_dirs.items()}
        write(root/'result.json',result)
        # All raw outputs remain on disk, including 44 corner streams on failure.
        files={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and 'target' not in p.relative_to(root).parts}
        write(root/'output-manifest.json',{'files':files,'excluded_build_cache':'target/','executable':None if exe_hash is None else {'path':str(exe),'sha256':exe_hash}})
        print(json.dumps({'run_root':str(root),'passed':result['passed'],'conversion_gate_passed':result['conversion_gate_passed'],'image_gate_passed':result['image_gate_passed'],'probe_completed':result['probe_completed'],'errors':result['errors']}),flush=True)
    return 0 if result['passed'] else 1
if __name__=='__main__': sys.exit(main())
