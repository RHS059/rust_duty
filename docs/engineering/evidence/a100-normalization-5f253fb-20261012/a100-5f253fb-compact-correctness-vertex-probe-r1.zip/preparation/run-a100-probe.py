#!/usr/bin/env python3
"""One isolated source-bound A100 authored correctness/probe run; no timing run."""
import argparse, hashlib, json, os, signal, shutil, stat, subprocess, sys, time, zipfile
from pathlib import Path
sys.dont_write_bytecode = True
SOURCE = '5f253fb0f60ec328d56cdd7fb19dbdca09c67b57'
TREE = 'ec47266ebda27aad447647aadf8aee61adefbc6d'
BUNDLE_SHA = '834f564e0c26f117081a7185c64c31818ecdcdd2457f613fabb2171e7c320444'
MANIFEST_SHA = 'b21fc7cd80dfc28b1892ad236ada24160414733cdea0563d456de3428ad1ef44'
def require(value, message):
    if not value: raise RuntimeError(message)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path, value): Path(path).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def inventory(root):
    require(root.is_dir() and not root.is_symlink(), 'unsafe directory')
    entries = list(root.rglob('*'))
    require(not any(p.is_symlink() for p in entries), 'symlink in inventory')
    return {'files': {str(p.relative_to(root)):sha(p) for p in sorted(entries) if p.is_file()},
            'directories': sorted(str(p.relative_to(root)) for p in entries if p.is_dir())}
def process_rows():
    rows={}
    for p in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields=p.read_text().rsplit(') ',1)[1].split()
            rows[int(p.parent.name)]=(int(fields[1]),int(fields[19]),fields[0])
        except (OSError,ValueError,IndexError): pass
    return rows
def track(pid, known):
    rows=process_rows()
    selected={p for p,start in known.items() if p in rows and rows[p][1]==start}
    while True:
        children={p for p,(parent,_,_) in rows.items() if parent in selected}
        if children <= selected: break
        selected |= children
    known.update({p:rows[p][1] for p in selected})
    return {p for p in selected if rows[p][2]!='Z'}
def owned(command, cwd, env, output, timeout):
    output.mkdir(); record={'command':list(map(str,command)), 'cwd':str(cwd),'timeout_seconds':timeout,'started':time.time()}
    proc=None; known={}
    try:
        with (output/'stdout.log').open('xb') as stdout, (output/'stderr.log').open('xb') as stderr:
            proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,start_new_session=True)
            row=process_rows().get(proc.pid)
            record['initial_process_identity_verified']=row is not None
            require(row is not None,'could not establish owned process start identity; no unverified PID will be signaled')
            known={proc.pid:row[1]}
            record['pid']=proc.pid; write(output/'process.json',record)
            deadline=time.monotonic()+timeout
            while proc.poll() is None:
                track(proc.pid,known)
                if time.monotonic()>deadline: raise TimeoutError('owned process deadline')
                time.sleep(.1)
            record['exit_code']=proc.returncode
            require(not track(proc.pid,known),'owned process left live descendants')
    except BaseException as error:
        record['error']=repr(error)
        if proc:
            cleanup={'signals':[]}
            for sig in (signal.SIGTERM,signal.SIGKILL):
                for pid in sorted(track(proc.pid,known),key=lambda p:p==proc.pid):
                    row=process_rows().get(pid)
                    if row and row[1]==known.get(pid):
                        try: os.kill(pid,sig); cleanup['signals'].append([pid,int(sig)])
                        except ProcessLookupError: pass
                until=time.monotonic()+5
                while time.monotonic()<until and track(proc.pid,known): time.sleep(.1)
            cleanup['remaining']=sorted(track(proc.pid,known))
            try: proc.wait(timeout=2)
            except subprocess.TimeoutExpired: cleanup['wait_timeout']=True
            record['cleanup']=cleanup
        raise
    finally:
        record['finished']=time.time();write(output/'process.json',record)
    return record

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--run-root',type=Path,required=True)
    parser.add_argument('--source-bundle',type=Path,required=True)
    parser.add_argument('--assets',type=Path,required=True)
    parser.add_argument('--cargo',type=Path,required=True)
    args=parser.parse_args()
    require(sys.platform=='linux','Linux host required')
    root=args.run_root.absolute(); assets=args.assets.resolve(); bundle=args.source_bundle.resolve();cargo=args.cargo.resolve()
    require(not root.exists() and not root.is_symlink(),'run directory must be a fresh exclusive leaf')
    require(sha(bundle)==BUNDLE_SHA,'source bundle digest differs')
    root.mkdir(parents=False)
    result={'schema':'rust-duty-a100-arithmetic-probe-run/v1','source':SOURCE,'tree':TREE,
            'passed':False,'image_gate_passed':False,'probe_completed':False,'started':time.time(),
            'scope':'single fixed authored correctness and diagnostic readback; no frame-rate measurement',
            'controller_sha256':sha(__file__),'source_bundle_sha256':BUNDLE_SHA,'errors':[]}
    retained={}; retained_dirs={}; expected_source=None; expected_assets=None; exe=None;exe_hash=None;env=None
    def freeze(path):
        retained_dirs[path]=inventory(path)
    def check():
        require(sha(__file__)==result['controller_sha256'] and sha(bundle)==BUNDLE_SHA,'controller/bundle changed')
        if expected_source is not None:
            require(inventory(source)==expected_source,'source changed')
            pair.check_cargo_configuration(source,env)
            require(subprocess.check_output([str(rustc),'-Vv'],cwd=source,env=env,text=True,timeout=30)==compiler,'compiler changed')
            require(subprocess.check_output([str(cargo),'-Vv'],cwd=source,env=env,text=True,timeout=30)==cargo_version,'Cargo changed')
        if expected_assets is not None: require(inventory(assets)==expected_assets,'runtime assets changed')
        for p,h in retained.items(): require(sha(p)==h,'retained input changed: '+str(p))
        for p,h in retained_dirs.items(): require(inventory(p)==h,'retained outputs changed: '+str(p))
        if exe_hash is not None: require(sha(exe)==exe_hash,'executable changed')
    try:
        with zipfile.ZipFile(bundle) as archive:
            names=archive.namelist(); require(len(names)==len(set(names)),'duplicate source entry')
            manifest=json.loads(archive.read('source-bundle.json'))
            require(hashlib.sha256(archive.read('source-bundle.json')).hexdigest()==MANIFEST_SHA,'source manifest differs')
            expected={'source-bundle.json','original-assets.json','original-resident-inputs.json','original-nvidia-vulkan.json','original-nvidia-egl.json'} | {'build-source/'+n for n in manifest['files']}
            require(set(names)==expected and archive.testzip() is None,'source archive inventory/CRC differs')
            require(manifest['source_commit']==SOURCE and manifest['source_tree']==TREE,'source identity differs')
            for name in names:
                relative=Path(name);require(not relative.is_absolute() and '..' not in relative.parts,'unsafe source path')
                destination=root/relative;destination.parent.mkdir(parents=True,exist_ok=True)
                raw=archive.read(name)
                if name.startswith('build-source/'):
                    bound=manifest['files'][name[len('build-source/'):]]
                    require(len(raw)==bound['bytes'] and hashlib.sha256(raw).hexdigest()==bound['sha256'],'source bytes differ')
                    require(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==bound['git_blob_sha1'],'Git blob differs')
                destination.write_bytes(raw)
                if name.startswith('build-source/'): destination.chmod(int(bound['git_mode'],8)&0o777)
        source=root/'build-source'; require(not (source/'assets').exists(),'build must not load implicit assets')
        sys.path.insert(0,str(source/'tools'))
        import run_cpu_image_preservation as pair
        import run_resident_authored_contract as fixture
        import summarize_cpu_encode_detail as detail
        import performance_matrix as matrix
        pair.check_environment(os.environ)
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',CARGO_TARGET_DIR=str(root/'target'))
        require(cargo.is_file() and cargo.name=='cargo','direct Cargo binary required')
        rustc=cargo.with_name('rustc');require(rustc.is_file(),'same-directory compiler missing')
        env['PATH']=str(cargo.parent)+':'+env['PATH']
        pair.check_cargo_configuration(source,env)
        original=json.loads((root/'original-resident-inputs.json').read_text())
        compiler=subprocess.check_output([str(rustc),'-Vv'],cwd=source,env=env,text=True,timeout=30)
        cargo_version=subprocess.check_output([str(cargo),'-Vv'],cwd=source,env=env,text=True,timeout=30)
        require(compiler==original['compiler'],'exact original Rust 1.99 Linux compiler required')
        require(cargo_version.startswith('cargo 1.99.0 (5f94df478 2026-08-27)\n') and '\nhost: x86_64-unknown-linux-gnu\n' in cargo_version,'exact Cargo version/host required')
        expected_source=inventory(source)
        expected_assets=inventory(assets)
        asset_receipt=json.loads((root/'original-assets.json').read_text())
        require(expected_assets['files']==asset_receipt['files'],'original 77-file public asset inventory required')
        require(not (assets/'assets/weapons').exists(),'private weapon assets excluded')
        gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True,timeout=30).strip()
        require(gpu=='NVIDIA A100-SXM4-40GB, 580.82.07','actual NVIDIA adapter/driver changed')
        env.update(LD_LIBRARY_PATH='/usr/lib64-nvidia',VK_ICD_FILENAMES=str(root/'original-nvidia-vulkan.json'),__EGL_VENDOR_LIBRARY_FILENAMES=str(root/'original-nvidia-egl.json'))
        receipt={'source':SOURCE,'tree':TREE,'source_manifest_sha256':MANIFEST_SHA,'files':expected_source['files'],
                 'compiler':compiler,'cargo':cargo_version,'profile':'release','default_features':False,'features':['wgpu-runtime'],
                 'gpu':gpu,'asset_receipt_sha256':sha(root/'original-assets.json'),'assets':expected_assets,
                 'source_bundle_sha256':BUNDLE_SHA,'controller_sha256':result['controller_sha256'],
                 'configuration_files':{p.name:sha(p) for p in root.glob('original-*.json')}}
        write(root/'inputs.json',receipt); receipt_hash=sha(root/'inputs.json')
        retained={p:sha(p) for p in root.glob('*.json')};env['PASS_SUBMISSION_SOURCE_SHA256']=receipt_hash
        check()
        build=owned([str(cargo),'build','--locked','--no-default-features','--features','wgpu-runtime','--release','--example','resident_authored_contract'],source,env,root/'build',1200)
        freeze(root/'build');require(build.get('exit_code')==0,'fixture build failed')
        built=root/'target/release/examples/resident_authored_contract'
        exe=root/'resident_authored_contract';shutil.copyfile(built,exe);exe.chmod(0o755);exe_hash=sha(exe)
        require(exe_hash==sha(built),'retained executable copy differs')
        write(root/'executable.json',{'sha256':exe_hash,'path':str(exe),'source_receipt_sha256':receipt_hash})
        retained[root/'executable.json']=sha(root/'executable.json');check()
        # Both leaves must remain absent: the Rust fixture creates them exclusively.
        captures=root/'captures'; probe=root/'vertex-probe'
        require(not captures.exists() and not probe.exists(),'stale fixture output')
        process=owned([str(exe),'--manifest',str(assets/'assets/animations.cfg'),'--output-dir',str(captures),'--vertex-probe-dir',str(probe)],source,env,root/'process',900)
        freeze(root/'process')
        for directory in (captures,probe):
            if directory.is_dir(): freeze(directory)
        report=fixture.read_report(captures/'report.json')
        result['process_exit_code']=process['exit_code']; result['parent_report_sha256']=sha(captures/'report.json')
        result['producer_report_passed']=report.get('passed')
        try:
            result['strict_image_summary']=fixture.validate_outputs(captures,report,receipt_hash)
            result['image_gate_passed']=True
        except Exception as error: result['errors'].append({'stage':'strict-image','error':repr(error)})
        try:
            result['probe_summary']=fixture.validate_vertex_probe(probe,report,receipt_hash,source)
            result['probe_completed']=result['probe_summary']['diagnostic_completed']
        except Exception as error: result['errors'].append({'stage':'vertex-probe','error':repr(error)})
        try:
            device=fixture.device_evidence(root/'process/stderr.log',report)
            prefix='renderer graphics_device_evidence='
            lines=[v[len(prefix):] for v in (root/'process/stderr.log').read_text().splitlines() if v.startswith(prefix)]
            require(len(lines)==1,'exactly one device record required')
            strict_device=json.loads(lines[0],object_pairs_hook=matrix.frames._unique,parse_constant=matrix.frames._constant)
            require(strict_device==device,'strict device record differs')
            # Validate closed descriptor types/flags separately from the legacy log subset.
            detail.validate_instance_descriptor({'identity':{'runtime_observed':{'actual_adapter':device}}})
            require(device['driver']=='NVIDIA' and device['driver_info']=='580.82.07','actual Vulkan driver differs')
            require(device['instance_descriptor']['flags_bits']==32 and device['instance_descriptor']['application_debug_assertions'] is False,'release descriptor differs')
            require(device['present_mode'] is None and device['present_policy'] is None and device['gpu_timestamps_requested'] is False,'original headless fixture policy differs')
            result['actual_device']=device
        except Exception as error: result['errors'].append({'stage':'actual-device','error':repr(error)})
        result['passed']=process['exit_code']==0 and result['image_gate_passed'] and result['probe_completed'] and not result['errors']
    except BaseException as error:
        result['errors'].append({'stage':'run','type':type(error).__name__,'error':repr(error)})
    finally:
        try: check();result['final_inputs_and_outputs_verified']=True
        except BaseException as error:
            result['final_inputs_and_outputs_verified']=False;result['errors'].append({'stage':'final-check','error':repr(error)});result['passed']=False
        result['finished']=time.time()
        result['retained_outputs']={str(p.relative_to(root)):v for p,v in retained_dirs.items()}
        write(root/'result.json',result)
        # All raw outputs remain on disk, including 44 corner streams on failure.
        files={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and 'target' not in p.relative_to(root).parts}
        write(root/'output-manifest.json',{'files':files,'excluded_build_cache':'target/','executable':None if exe_hash is None else {'path':str(exe),'sha256':exe_hash}})
        print(json.dumps({'run_root':str(root),'passed':result['passed'],'image_gate_passed':result['image_gate_passed'],'probe_completed':result['probe_completed'],'errors':result['errors']}),flush=True)
    return 0 if result['passed'] else 1
if __name__=='__main__': sys.exit(main())
