#!/usr/bin/env python3
"""Recover original source-bound manifest and exact77 assets; no install/build/run."""
import argparse,base64,hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path
sys.dont_write_bytecode=True
MANIFEST_RAW=base64.b64decode('IyBTdGFibGUgZ2FtZXBsYXkgc2xvdHMuIFBhdGhzIGFyZSByZWxhdGl2ZSB0byB0aGlzIG1hbmlmZXN0LCBub3QgdGhlIHdvcmtpbmcgZGlyZWN0b3J5LgpzY2hlbWE9cnVzdC1kdXR5LWFuaW1hdGlvbi1zbG90cy92MQpsb2NvbW90aW9uLmFzc2V0PWxvY29tb3Rpb24vYXNzZXQudnJhCmxheWVycy5hbmNob3JfYWN0b3I9aGs0MTZfd2VhcG9uCnJlYWR5LmNsaXA9bm9ybWFsX3JlYWR5CnJlZ3VsYXJfd2Fsay5hc3NldD1kaXJlY3Rpb25hbC9hc3NldC52cmEKcmVndWxhcl93YWxrLmNsaXA9bm9ybWFsX3dhbGtfcjEKcmVndWxhcl93YWxrLmFuY2hvcl9hY3Rvcj1oazQxNl93ZWFwb24Kc3ByaW50LmVudHJ5LmNsaXA9bm9ybWFsX2VudHJ5X2Nvbm5lY3RlZApzcHJpbnQubG9vcC5jbGlwPW5vcm1hbF9sb29wCnNwcmludC5icmlkZ2VzPW5vcm1hbF9leGl0X2JyaWRnZV8wMDAsbm9ybWFsX2V4aXRfYnJpZGdlXzAwMSxub3JtYWxfZXhpdF9icmlkZ2VfMDAyLG5vcm1hbF9leGl0X2JyaWRnZV8wMDMsbm9ybWFsX2V4aXRfYnJpZGdlXzAwNCxub3JtYWxfZXhpdF9icmlkZ2VfMDA1LG5vcm1hbF9leGl0X2JyaWRnZV8wMDYsbm9ybWFsX2V4aXRfYnJpZGdlXzAwNyxub3JtYWxfZXhpdF9icmlkZ2VfMDA4LG5vcm1hbF9leGl0X2JyaWRnZV8wMDksbm9ybWFsX2V4aXRfYnJpZGdlXzAxMCxub3JtYWxfZXhpdF9icmlkZ2VfMDExLG5vcm1hbF9leGl0X2JyaWRnZV8wMTIsbm9ybWFsX2V4aXRfYnJpZGdlXzAxMyxub3JtYWxfZXhpdF9icmlkZ2VfMDE0LG5vcm1hbF9leGl0X2JyaWRnZV8wMTUsbm9ybWFsX2V4aXRfYnJpZGdlXzAxNixub3JtYWxfZXhpdF9icmlkZ2VfMDE3LG5vcm1hbF9leGl0X2JyaWRnZV8wMTgsbm9ybWFsX2V4aXRfYnJpZGdlXzAxOSxub3JtYWxfZXhpdF9icmlkZ2VfMDIwLG5vcm1hbF9leGl0X2JyaWRnZV8wMjEsbm9ybWFsX2V4aXRfYnJpZGdlXzAyMixub3JtYWxfZXhpdF9icmlkZ2VfMDIzLG5vcm1hbF9leGl0X2JyaWRnZV8wMjQsbm9ybWFsX2V4aXRfYnJpZGdlXzAyNSxub3JtYWxfZXhpdF9icmlkZ2VfMDI2LG5vcm1hbF9leGl0X2JyaWRnZV8wMjcsbm9ybWFsX2V4aXRfYnJpZGdlXzAyOCxub3JtYWxfZXhpdF9icmlkZ2VfMDI5LG5vcm1hbF9leGl0X2JyaWRnZV8wMzAsbm9ybWFsX2V4aXRfYnJpZGdlXzAzMSxub3JtYWxfZXhpdF9icmlkZ2VfMDMyLG5vcm1hbF9leGl0X2JyaWRnZV8wMzMsbm9ybWFsX2V4aXRfYnJpZGdlXzAzNApzcHJpbnQuZXhpdC5jbGlwPW5vcm1hbF9leGl0CnNwcmludC5zZXR0bGUuY2xpcD1ub3JtYWxfc2V0dGxlCnNwcmludC5yZXNwb25zZV9zZWNvbmRzPTAuMDUKc3ByaW50LnJlc2lkdWFsX3NlY29uZHM9MC4wMwojIENvbXBsZXRlIG5hdGl2ZSBhdXRob3JlZCBXSVAsIGluY2x1ZGluZyB1bmZpbmlzaGVkIHNvdXJjZSBmcmFtZXMgMzAtNDguCnJlbG9hZC50YWN0aWNhbC5hc3NldD1yZWxvYWQvYXNzZXQudnJhCnJlbG9hZC50YWN0aWNhbC5jbGlwPXJlbG9hZF9jdXJyZW50X3dpcApyZWxvYWQuZW1wdHk9dW5hdmFpbGFibGUKcmVsb2FkLnJvdXRlPWFuY2hvcmVkX2Nyb3NzZmFkZQpyZWxvYWQuY2xvY2s9bmF0aXZlX2NvbXBsZXRlCmFkcy5hc3NldD1hZHMvYXNzZXQudnJhCmFkcy5lbnRyeS5jbGlwPWFkc19lbnRyeV9yMQphZHMuaG9sZC5jbGlwPWFkc19ob2xkX3IxCmFkcy5leGl0LmNsaXA9YWRzX2V4aXRfcjEKYWRzLmNsb2NrPW5hdGl2ZV9yZXZlcnNpYmxlCmZpcmU9dW5hdmFpbGFibGUKbWFudGxlPXVuYXZhaWxhYmxlCgojIHI1IEhJUCBwbHVzIGZvcndhcmQgQURTIHY5IFdJUDsgb3RoZXIgQURTIGRpcmVjdGlvbnMgcmV0YWluIHRoZSB2NCBmYWxsYmFjay4KcmVndWxhcl93YWxrLmRpcmVjdGlvbi5mb3J3YXJkPWhpcF93YWxrX2ZvcndhcmRfcjEKcmVndWxhcl93YWxrLmRpcmVjdGlvbi5iYWNrd2FyZD1oaXBfd2Fsa19iYWNrd2FyZF9yMQpyZWd1bGFyX3dhbGsuZGlyZWN0aW9uLmxlZnQ9aGlwX3N0cmFmZV9sZWZ0X3IxCnJlZ3VsYXJfd2Fsay5kaXJlY3Rpb24ucmlnaHQ9aGlwX3N0cmFmZV9yaWdodF9yMQpsYXllcnMuYWRzX3dhbGs9cmVjZWl2ZXJfdjlfZm9yd2FyZF93aXAKYWRzLnZpc3VhbF90cmFuc2l0aW9uX3NlY29uZHM9MC4zMAoKIyBDb21tb24gSnVtcCByNyBzb3VyY2UtYXV0aG9yZWQgV0lQOyBmaXhlZC12aWV3IHF1YWxpdGF0aXZlIHBhc3MsIEVsYXJhIHJldmlldyBwZW5kaW5nLgpqdW1wLmFzc2V0PWp1bXAvYXNzZXQudnJhCmp1bXAuY2xvY2s9bmF0aXZlX2dyb3VuZF9jb250YWN0CgojIFRyYXZlcnNhbCBhbmQgd2VhcG9uLWFjdGlvbiBzbG90cyAoZG9jcy9UUkFWRVJTQUwubWQpLiBQbGFjZWhvbGRlciB0aW1pbmcgaXMKIyB1c2VkIHdoaWxlIGEgc2xvdCBpcyB1bmF2YWlsYWJsZS4gVG8gYmluZCBhbiBhdXRob3JlZCBjbGlwLCByZXBsYWNlIHRoZSBsaW5lCiMgd2l0aCBhY3Rpb24uPHNsb3Q+LmFzc2V0PS4uLiwgYWN0aW9uLjxzbG90Pi5jbGlwPS4uLiwgYW5kIG9wdGlvbmFsbHkKIyBhY3Rpb24uPHNsb3Q+LmV2ZW50cz1uYW1lOjAuNCxvdGhlcjoxIChub3JtYWxpemVkIGNsaXAgdGltZSkuCmFjdGlvbi50YWNfc3ByaW50X2VudGVyPXVuYXZhaWxhYmxlCmFjdGlvbi50YWNfc3ByaW50X2xvb3A9dW5hdmFpbGFibGUKYWN0aW9uLnRhY19zcHJpbnRfZXhpdD11bmF2YWlsYWJsZQphY3Rpb24uc2xpZGVfZW50ZXI9dW5hdmFpbGFibGUKYWN0aW9uLnNsaWRlX2xvb3A9dW5hdmFpbGFibGUKYWN0aW9uLnNsaWRlX3JlY292ZXI9dW5hdmFpbGFibGUKYWN0aW9uLnNsaWRlX2ludGVycnVwdD11bmF2YWlsYWJsZQphY3Rpb24uZGl2ZV9sYXVuY2g9dW5hdmFpbGFibGUKYWN0aW9uLmRpdmVfYWlyPXVuYXZhaWxhYmxlCmFjdGlvbi5kaXZlX2ltcGFjdD11bmF2YWlsYWJsZQphY3Rpb24uZGl2ZV9yZWNvdmVyPXVuYXZhaWxhYmxlCmFjdGlvbi5tb3VudF9lbnRlcj11bmF2YWlsYWJsZQphY3Rpb24ubW91bnRfaG9sZD11bmF2YWlsYWJsZQphY3Rpb24ubW91bnRfZXhpdD11bmF2YWlsYWJsZQphY3Rpb24ubGVkZ2VfY2F0Y2g9dW5hdmFpbGFibGUKYWN0aW9uLmxlZGdlX2hvbGQ9dW5hdmFpbGFibGUKYWN0aW9uLmxlZGdlX2xvc3Q9dW5hdmFpbGFibGUKYWN0aW9uLnBpc3RvbF9kcmF3PXVuYXZhaWxhYmxlCmFjdGlvbi5waXN0b2xfcmVhZHk9dW5hdmFpbGFibGUKYWN0aW9uLnBpc3RvbF9haW09dW5hdmFpbGFibGUKYWN0aW9uLnBpc3RvbF9maXJlPXVuYXZhaWxhYmxlCmFjdGlvbi5waXN0b2xfc3Rvdz11bmF2YWlsYWJsZQphY3Rpb24ucHVsbF91cD11bmF2YWlsYWJsZQphY3Rpb24uaGFuZ19kcm9wPXVuYXZhaWxhYmxlCg==')
EXPECTED_RUSTC='rustc 1.99.0 (b940084d7 2026-09-28)\nbinary: rustc\ncommit-hash: b940084d7eb6a299eb4bfeb8e34901bc051e7ac4\ncommit-date: 2026-09-28\nhost: x86_64-unknown-linux-gnu\nrelease: 1.99.0\nLLVM version: 23.1.1\n'
MANIFEST_SHA='7ab3a60c5c271163de3a7349e69d0d07db85aa759737be0264cb29e6134e84ee'
MANIFEST_GIT_BLOB='e19190f6575675202d8c0d7f15d740472a349e4d'
ASSET_RECEIPT_SHA='756ad13125e39d67d669493a82d4f2959273dd9902c3752ef3ccde6744a9fa9b'
ARCHIVE_SHA='b4978796abf0b3301649ae885bf5cce1c0043036ee5297cfc6220ec933b3a5d0'
def require(value,message):
    if not value:raise RuntimeError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def inventory(root):
    paths=list(root.rglob('*'));require(root.is_dir() and not root.is_symlink() and not any(p.is_symlink() for p in paths),'unsafe inventory root')
    return {str(p.relative_to(root)):sha(p) for p in sorted(paths) if p.is_file()}
def main():
    p=argparse.ArgumentParser();p.add_argument('--setup-root',type=Path,required=True);p.add_argument('--repair-root',type=Path,required=True);args=p.parse_args()
    setup=args.setup_root.resolve();root=args.repair_root.absolute()
    require(setup.is_dir() and not root.exists() and not root.is_symlink(),'existing setup and exclusive repair root required');root.mkdir(parents=False)
    result={'schema':'rust-duty-original-a100-assets-repair/v1','passed':False,'started':time.time(),'controller_sha256':sha(__file__),
      'scope':'recover exact original source manifest plus original76 release asset files; no install/build/fixture launch',
      'manifest_source':{'commit':'1ef12e3f5840e1411c131e2859b133737f4ec565','tree':'18d01cae913011f577f2d34802806693c95cc75d','path':'assets/animations.cfg','git_blob':MANIFEST_GIT_BLOB,'sha256':MANIFEST_SHA,'recovery':'byte-identical original build-source and baseline-source entries'}}
    retained={};expected_assets=None
    try:
        prior_path=setup/'setup-result.json';prior=json.loads(prior_path.read_text());retained[prior_path]=sha(prior_path)
        require(prior.get('passed') is False and prior.get('final_inputs_verified') is True,'failed setup receipt differs')
        require(prior.get('error',{}).get('message')=='selected public asset hash differs: assets/animations.cfg','unexpected setup failure')
        require(prior['controller_sha256']=='5234ced5410b6c267dc5c18ad004a28afa1c924768cb4dde5ae30c9dc12e754e','unreviewed setup source')
        require(prior['compiler']==EXPECTED_RUSTC and prior['reader_versions']=={'Pillow':'11.3.0','PyYAML':'6.0.3'},'installed compiler/readers differ')
        for name,expected in prior['retained_file_sha256'].items():
            relative=Path(name);require(not relative.is_absolute() and '..' not in relative.parts,'unsafe retained setup path')
            path=setup/relative;require(path.is_file() and not path.is_symlink() and sha(path)==expected,'retained setup input changed: '+name);retained[path]=expected
        require(inventory(setup/'python-readers')==prior['reader_files'],'installed readers changed')
        receipt_path=setup/'assets.json';require(sha(receipt_path)==ASSET_RECEIPT_SHA,'original asset receipt differs')
        expected=json.loads(receipt_path.read_text());require(len(expected['files'])==77 and expected['files']['assets/animations.cfg']==MANIFEST_SHA,'original asset inventory differs')
        archive=setup/'original-public-release.zip';require(sha(archive)==ARCHIVE_SHA==expected['archive_sha256'],'original release archive differs')
        require(hashlib.sha256(MANIFEST_RAW).hexdigest()==MANIFEST_SHA and hashlib.sha1(b'blob '+str(len(MANIFEST_RAW)).encode()+b'\0'+MANIFEST_RAW).hexdigest()==MANIFEST_GIT_BLOB,'recovered source manifest bytes differ')
        assets=root/'authored-assets';assets.mkdir();members={};archive_checks={}
        with zipfile.ZipFile(archive) as z:
            entries=z.infolist();names=[entry.filename for entry in entries];require(len(names)==len(set(names)),'duplicate archive names')
            for name,digest in expected['files'].items():
                relative=Path(name);require(not relative.is_absolute() and '..' not in relative.parts and name.startswith('assets/') and not name.startswith('assets/weapons/'),'unsafe asset path')
                matches=[entry for entry in entries if entry.filename==name or entry.filename.endswith('/'+name)];require(len(matches)==1,'missing/ambiguous release member: '+name)
                entry=matches[0];require(not entry.is_dir() and ((entry.external_attr>>16)&0o170000) in (0,0o100000) and entry.file_size<=256*1024*1024,'nonregular/oversized release member')
                release_raw=z.read(entry);release_sha=hashlib.sha256(release_raw).hexdigest();archive_checks[name]={'member':entry.filename,'sha256':release_sha,'expected_sha256':digest,'matches':release_sha==digest}
                if name=='assets/animations.cfg':require(len(release_raw)==2254 and release_sha=='e9f52d241b7ebc5de56b88dddc1f9c9c891e91b9f2506853532f72945e02eb9d','observed release manifest differs')
                raw=MANIFEST_RAW if name=='assets/animations.cfg' else release_raw
                require(hashlib.sha256(raw).hexdigest()==digest,'exact original asset still differs: '+name)
                target=assets/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);members[name]='original Git-bound manifest' if name=='assets/animations.cfg' else entry.filename
        require(inventory(assets)==expected['files'],'repaired77 inventory differs');expected_assets=expected['files']
        result['archive_member_checks']=archive_checks;result['asset_sources']=members;result['files']=expected_assets
        require([n for n,r in archive_checks.items() if not r['matches']]==['assets/animations.cfg'],'release/source divergence is not the isolated original manifest')
        env={'CARGO_HOME':str(setup/'cargo'),'RUSTUP_HOME':str(setup/'rustup'),'PYTHONPATH':str(setup/'python-readers'),'PYTHONDONTWRITEBYTECODE':'1'}
        cargo=Path(prior['direct_cargo']);require(cargo.is_relative_to(setup) and cargo.is_file(),'direct compiler outside retained setup')
        require(subprocess.check_output([str(cargo.with_name('rustc')),'-Vv'],env=dict(os.environ,**env),text=True,timeout=30)==EXPECTED_RUSTC,'installed compiler changed')
        result['launch_parameters']={'assets':str(assets),'cargo':str(cargo),'environment':env}
        result['original_failed_setup_sha256']=retained[prior_path];result['passed']=True
    except BaseException as error:result['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        try:
            require(sha(__file__)==result['controller_sha256'] and all(sha(p)==h for p,h in retained.items()),'retained setup/controller changed')
            if expected_assets is not None:require(inventory(root/'authored-assets')==expected_assets,'repaired assets changed')
            if 'reader_files' in locals().get('prior',{}):require(inventory(setup/'python-readers')==prior['reader_files'],'retained reader files changed')
            result['final_inputs_verified']=True
        except BaseException as error:result['final_inputs_verified']=False;result['final_check_error']=repr(error);result['passed']=False
        result['finished']=time.time();(root/'repair-result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        print(json.dumps({'passed':result['passed'],'repair_root':str(root),'error':result.get('error'),'launch_parameters':result.get('launch_parameters')}),flush=True)
    return 0 if result['passed'] else 1
if __name__=='__main__':sys.exit(main())
