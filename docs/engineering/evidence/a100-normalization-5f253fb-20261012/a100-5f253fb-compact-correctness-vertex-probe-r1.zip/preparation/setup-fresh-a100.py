#!/usr/bin/env python3
"""Fresh Colab dependencies/assets only. Never builds or launches the game."""
import argparse,base64,ctypes,ctypes.util,hashlib,importlib.metadata,json,os,platform,re,shutil,signal,ssl,subprocess,sys,time,urllib.request,zipfile
from pathlib import Path
sys.dont_write_bytecode=True
ASSET_RECEIPT_RAW=base64.b64decode('ewogICJ1cmwiOiAiaHR0cHM6Ly9naXRodWIuY29tL1JIUzA1OS9ydXN0X2R1dHkvcmVsZWFzZXMvZG93bmxvYWQvdjAuMS45L1J1c3QtRHV0eS0wLjEuOS1MaW51eC14NjQuemlwIiwKICAiYXJjaGl2ZV9zaGEyNTYiOiAiYjQ5Nzg3OTZhYmYwYjMzMDE2NDlhZTg4NWJmNWNjZTFjMDA0MzAzNmVlNTI5N2NmYzYyMjBlYzkzM2IzYTVkMCIsCiAgImZpbGVzIjogewogICAgImFzc2V0cy9hbmltYXRpb25zLmNmZyI6ICI3YWIzYTYwYzVjMjcxMTYzZGUzYTczNDllNjlkMGQwN2RiODVhYTc1OTczN2JlMDI2NGNiMjllNjEzNGU4NGVlIiwKICAgICJhc3NldHMvcmVsb2FkL2V4cG9ydC1tYW5pZmVzdC5qc29uIjogIjM5ODkzYzZlNzc2YWZmOGU3ODlmNmFmMTNlODVkYmY1ODIyZDgzYTRlYTE5MWU3Y2JmYmViN2U5Nzg2M2RlMWQiLAogICAgImFzc2V0cy9yZWxvYWQvbWFuaWZlc3QuanNvbiI6ICJkOTVmY2UzYmEyZTM3Y2ViMWVmODU5ODcyZWQ3MjdmYTRmODcxZDEwMzEwZWExNDliNDYwMjA4YzUwZDM2MzY0IiwKICAgICJhc3NldHMvcmVsb2FkL2Fzc2V0LnZycyI6ICJjMmI1ODVjYjhkY2M2ODY1MmZiNTIzYmFkOTc2NzMwZDJkM2RiODhmNjQ0MmM1ZWZjNjlmMDA5Y2ViMmIyMGQ3IiwKICAgICJhc3NldHMvcmVsb2FkL2Fzc2V0LnZybSI6ICI3MjE5ODYzNTcyMjg5NTFhMzNjYmEzMmNiZTA4OGFjZWI3NjE2OWZhOWMwYzk3NDgyMzU1Nzc1YWFkODUwMjZhIiwKICAgICJhc3NldHMvcmVsb2FkL3NvdXJjZS5qc29uIjogImMzYWY0MzBiZTllMzBhM2U0YWNmOGZkMGY5OGEwMzc3Njc3OTJkZGFhZjhjZWViMTliZDBmNWJkYzc1OTMwZDYiLAogICAgImFzc2V0cy9yZWxvYWQvcGFyaXR5Lmpzb24iOiAiNTU0MDUxZjMzZmU2ZTkyMDEwNDllNDZmNTlhMWIxZjYxMWE2ZmZmMDI1MGVmZjU3YjRlMTAxMTZmODUzMDI3OSIsCiAgICAiYXNzZXRzL3JlbG9hZC9hc3NldC52cmEiOiAiMDlkMzljOWM1ZDJjNzU0NDhkODcxNTQ4Y2FlM2VjYWRlMDFlYjdlMzZjMjJkZTZmMDU5ZTQxNzNhNTRlNGE5YSIsCiAgICAiYXNzZXRzL2RpcmVjdGlvbmFsL3Bhcml0eS1oaXBfd2Fsa19mb3J3YXJkX3IxLmpzb24iOiAiYzRmOTEyMmUxNzhmMjU1NDM5MmI0MGE0YjQ2ZDI2ZGExNTg0YzhmYmI3ZDMwNjVmYzZjMzgwMGI5ZDczNjQ1NCIsCiAgICAiYXNzZXRzL2RpcmVjdGlvbmFsL21hbmlmZXN0Lmpzb24iOiAiMzdjY2RmZDZjNTJlMjNkNjJhOTNkZDEyMWU3MTYyMTg1OGI3MGZjMWJkYTc3NWYzYTBlZGRkOTlkMTFiNzZiNCIsCiAgICAiYXNzZXRzL2RpcmVjdGlvbmFsL2NvbnZlcnNpb24taGlwX3dhbGtfYmFja3dhcmRfcjEuanNvbiI6ICJiZTljYjJiMGExMThiM2I0ZjcxOTM0ZTdjYWQwMmE1ZTg2NDVjNjkwN2UyZjdiNmQyNjdhZTc4ZDU1YmU2OTM0IiwKICAgICJhc3NldHMvZGlyZWN0aW9uYWwvY29udmVyc2lvbi1oaXBfd2Fsa19mb3J3YXJkX3IxLmpzb24iOiAiYTcyYjc1Y2IwMDE3MTg2YzhjZmE0MmFjMTZiMjMyZWRhYzQyNjQxOGI4MTFhN2Y2ODAzOTA0NDM4YTVkY2I3NCIsCiAgICAiYXNzZXRzL2RpcmVjdGlvbmFsL2NvbnZlcnNpb24taGlwX3N0cmFmZV9sZWZ0X3IxLmpzb24iOiAiOWUwMDAxNDhlMjM1MjJiZTMxYWUwOTQzYjg2NzdmYzZiZWE1YThjMjExNzc2YTY2YTZjOGU1N2UxNWJlZWNmOSIsCiAgICAiYXNzZXRzL2RpcmVjdGlvbmFsL2NvbnZlcnNpb24taGlwX3N0cmFmZV9yaWdodF9yMS5qc29uIjogImUwMDg3NzA0OGQ3NTE2MjcxYjRiN2I4MGJiNGVmNTM3NDNkNmM5NTVlNDhhOTY5NTU3NDYzZDA5ZjI4NjZjNjMiLAogICAgImFzc2V0cy9kaXJlY3Rpb25hbC9wYXJpdHktaGlwX3N0cmFmZV9yaWdodF9yMS5qc29uIjogIjUwM2RkNGNmMzExN2IxZjhlYjkwMjk3YzVlZmI0MGJjYjVmYTg1ODdiZGEzMTc5YzE2ZjI4ZDEyMWFkMjA1ZWMiLAogICAgImFzc2V0cy9kaXJlY3Rpb25hbC9hc3NldC52cnMiOiAiYjM4YjdmODIzZGRmN2JkNmYwMzJlZDk4ZDMzZjA1NWNkNDQ0Y2FmNTE1NTgxNDY5MTFiN2E2NzhjNmUzY2U5MiIsCiAgICAiYXNzZXRzL2RpcmVjdGlvbmFsL3Bhcml0eS1oaXBfd2Fsa19iYWNrd2FyZF9yMS5qc29uIjogIjJjMjlhZDEwZTM5MTJlOGMxNWNhMDcwM2I1NjRhODU4N2IyMWQ0NWFmNjEzZTZmYTMxMGJkZDI2NzBlYmM1ZjciLAogICAgImFzc2V0cy9kaXJlY3Rpb25hbC9wYXJpdHktaGlwX3N0cmFmZV9sZWZ0X3IxLmpzb24iOiAiMGFlYmQ3ZmE3YWUxZWNlOGE0MWFhOWM5M2NjZGY1YWI4Nzk4ZDRiMzFjMmQ1ZTViMjVmYmRiMzg1YjEzYTAzOCIsCiAgICAiYXNzZXRzL2RpcmVjdGlvbmFsL2Fzc2V0LnZybSI6ICJkMTE3MzYxNjJiMmNkYTk5M2RiM2NkZDVkNDAxNWFmZjJiMTUxZWE2Mzc3YjhiOTU0MzcwYjU0MDA2ZTAyZDY3IiwKICAgICJhc3NldHMvZGlyZWN0aW9uYWwvYXNzZXQudnJhIjogImVkZmNlNzA3YTBiN2FlYmM3OTVlMzEwMGU0YTJkMTJiNWM1ODViMTA2OTg2MzE4ZDRiYTgzMjM4Mzg0YmEyZDkiLAogICAgImFzc2V0cy9kaXJlY3Rpb25hbC9SRUFETUUubWQiOiAiNzM2MjUyMzQxZmEwMjgyNzZkMmE1MTQ0MDQyZTQ2MjU3MWYxODY5YWVmNjlmM2M0ZGQwYjg4YWEwYmE2MDNkMCIsCiAgICAiYXNzZXRzL3dhbGsvY29udmVyc2lvbi5qc29uIjogIjVkZjljZWM5YjYzYzFhZjkyNDY2MDc4OTY1M2UzZWY1MDViZmYxZWFhOGZlN2VlNTZkZDA4MjYxNGQwNDEwMGMiLAogICAgImFzc2V0cy93YWxrL21hbmlmZXN0Lmpzb24iOiAiYmE1MjE0NDA0NzFmYmY1ZjNjN2VmY2FkODNlOWZmNGZiMTUyMjY0OWE4NjIxMTNmMzdlMDEzMzgxZTIzYTJmNCIsCiAgICAiYXNzZXRzL3dhbGsvYXNzZXQudnJzIjogImIzOGI3ZjgyM2RkZjdiZDZmMDMyZWQ5OGQzM2YwNTVjZDQ0NGNhZjUxNTU4MTQ2OTExYjdhNjc4YzZlM2NlOTIiLAogICAgImFzc2V0cy93YWxrL2Fzc2V0LnZybSI6ICJkMTE3MzYxNjJiMmNkYTk5M2RiM2NkZDVkNDAxNWFmZjJiMTUxZWE2Mzc3YjhiOTU0MzcwYjU0MDA2ZTAyZDY3IiwKICAgICJhc3NldHMvd2Fsay9wYXJpdHkuanNvbiI6ICJhNTBlNzRjODhlNTg0M2Q1YzlmMWQyNjVkZTkxYTU2MzdkYWRmNmMyYmU2NDM4NzllYThjOWUwYjBkYWZhOTk0IiwKICAgICJhc3NldHMvd2Fsay9hc3NldC52cmEiOiAiYTIxN2YzZGQ2MjJjZmNlOTYwMDFmNmYyM2U4NDQzZDMwZGUxMDlhMzI1OGNmOTVlMzRkMjdkZDIwNTc5Njk1MiIsCiAgICAiYXNzZXRzL3dhbGsvUkVBRE1FLm1kIjogIjFkYzcxNjExNTFmODYwNGZlZmM0ZWQxMzJlNDgzYWU2YzEyNWYzZTY5Nzg2NDI3ZjYwZTkzZTliYzA1MmQ2NzYiLAogICAgImFzc2V0cy9hZHMvY29udmVyc2lvbi1hZHNfZXhpdF9yMS5qc29uIjogImJiZmY4MjE5YTc5M2Y3YWQ2MThiMTNiM2Q4OWEwZjljMzExOGQ0ZDU1YmNhOTAzYjhhMmY4MzY5NzNiNjNhYmMiLAogICAgImFzc2V0cy9hZHMvbWFuaWZlc3QuanNvbiI6ICJhNzgzMjE0N2QwMDQxMDIzZmJjOTQ2MWQ3MzkyYjZjYmZlMjEyN2ZkMDE2NTI2OTkyYjlhNzgyMWUzMDcxMzkxIiwKICAgICJhc3NldHMvYWRzL2Fzc2V0LnZycyI6ICJiMzhiN2Y4MjNkZGY3YmQ2ZjAzMmVkOThkMzNmMDU1Y2Q0NDRjYWY1MTU1ODE0NjkxMWI3YTY3OGM2ZTNjZTkyIiwKICAgICJhc3NldHMvYWRzL2NvbnZlcnNpb24tYWRzX2VudHJ5X3IxLmpzb24iOiAiM2ZmZmQ5MWMzNDQ4MTlhMmU0ZTdlZTZkODJjZDgyM2NkOGEyMjc5ODhkMWIxMTY3ZjhlYmFkZjU3ODY5NDhkNCIsCiAgICAiYXNzZXRzL2Fkcy9wYXJpdHktYWRzX2hvbGRfcjEuanNvbiI6ICJmNzg4MzViN2NiMTgwMmY1NzU0NDQwZmRjODQyYjI4ZWZlMjFkMzBkOGVlNjQ3N2QxZWY4ZWI0ZDFlNTdhMjY2IiwKICAgICJhc3NldHMvYWRzL3Bhcml0eS1hZHNfZXhpdF9yMS5qc29uIjogImFkYWEyYTVlYTkzOTE3MWVjYTg2YTIwMTAwNjU1ODYzMTM5Mzc1ZThlNTNkOTAzOTBjNDhjNmUzOGQ2MjQ4ZmUiLAogICAgImFzc2V0cy9hZHMvYXNzZXQudnJtIjogImQxMTczNjE2MmIyY2RhOTkzZGIzY2RkNWQ0MDE1YWZmMmIxNTFlYTYzNzdiOGI5NTQzNzBiNTQwMDZlMDJkNjciLAogICAgImFzc2V0cy9hZHMvY29udmVyc2lvbi1hZHNfaG9sZF9yMS5qc29uIjogIjJjNDQ0OTIwMDgwNGE1MGZmMWRiNmFiMjFhODc2NWVjMDUzNWY4YWQ0YzBmZDg3NDRkYWI3YWU4ODEzN2RkYjMiLAogICAgImFzc2V0cy9hZHMvcGFyaXR5LWFkc19lbnRyeV9yMS5qc29uIjogImFhZmI5OTM5OWQwNzkxMDNhZTRiNjAyMzg2NjA2NTk2MzNmNzgyMWViY2JkZTk1MTFkYmU3MzU2ZWFiMTViYjMiLAogICAgImFzc2V0cy9hZHMvYXNzZXQudnJhIjogIjMyNDRlZGUwNzI2ZTc2N2ZjM2YzMGQwNGZiYjgwZDRlMzFiNDFhMTJhOTE4NWJhYWJkNzA3YWQ2Y2U5MWEwMmEiLAogICAgImFzc2V0cy9hZHMvUkVBRE1FLm1kIjogImM0NGQ0NzRjNDQzZGIyYjg4MWQ0NmQ3NDRkNWM5NzhhMjFkNWUzZWQwOGUyODc4ZmMwNzI2NTdlZjM2OGVkYWEiLAogICAgImFzc2V0cy9sb2NvbW90aW9uL21hbmlmZXN0Lmpzb24iOiAiOWQ4ZGU5ZjMzMzA0Y2UxOTBhNmVhYmNiNGFjNjk2Y2Q5OTUxNDVkNGJjYmUxM2UwNWVjM2ZkODkxYjYyODYzOSIsCiAgICAiYXNzZXRzL2xvY29tb3Rpb24vYXNzZXQudnJzIjogImIzOGI3ZjgyM2RkZjdiZDZmMDMyZWQ5OGQzM2YwNTVjZDQ0NGNhZjUxNTU4MTQ2OTExYjdhNjc4YzZlM2NlOTIiLAogICAgImFzc2V0cy9sb2NvbW90aW9uL2Fzc2V0LnZybSI6ICJkMTE3MzYxNjJiMmNkYTk5M2RiM2NkZDVkNDAxNWFmZjJiMTUxZWE2Mzc3YjhiOTU0MzcwYjU0MDA2ZTAyZDY3IiwKICAgICJhc3NldHMvbG9jb21vdGlvbi9hc3NldC52cmEiOiAiZDAyZDA0ZDRhZGI0MjliNjQ5M2JmMzM0N2IzMDJkYzAwN2JiN2I5OWY0NzYxZGEzYzJiMzE0ZTZkMzEzYzZhYiIsCiAgICAiYXNzZXRzL2xvY29tb3Rpb24vUkVBRE1FLm1kIjogImI3Nzc0ZmJlZjczNTVlNWUwZTY0N2E4ODdlZTMzYmIzZjlhMGJmZWVmMmExMjc3MzM1ODhhMmRhY2EzM2YyOGIiLAogICAgImFzc2V0cy9qdW1wL21hbmlmZXN0Lmpzb24iOiAiMThlYTBlZjFlM2E4NzI3MTVjNGU4MGViNjNhNWM0YTY3MzQ1ZTg2YWY0MTI2Yjk2NmMxZWE1MWY0YzUzNWIyMCIsCiAgICAiYXNzZXRzL2p1bXAvYXNzZXQudnJzIjogImIzOGI3ZjgyM2RkZjdiZDZmMDMyZWQ5OGQzM2YwNTVjZDQ0NGNhZjUxNTU4MTQ2OTExYjdhNjc4YzZlM2NlOTIiLAogICAgImFzc2V0cy9qdW1wL3J1bnRpbWUtc2VhbXMuanNvbiI6ICI1ZTNjYTgxZjZmMGYwZDZjZmFjN2JhNjQwODNhNWJiYWQ3OGQxMjJiZTRiZWExNTM2Nzk5OGI3ODgxMzgyOWEwIiwKICAgICJhc3NldHMvanVtcC9jb252ZXJzaW9uLWp1bXBfbGFuZC5qc29uIjogImU0MTRjNzM0NjFhY2EyOGFhY2ExYTNmNGUyNzM5ODlhNzllNjVlMjRlZmI4MThiNWM3ZmZlN2NiMzdmNWRmMGIiLAogICAgImFzc2V0cy9qdW1wL2Fzc2V0LnZybSI6ICJkMTE3MzYxNjJiMmNkYTk5M2RiM2NkZDVkNDAxNWFmZjJiMTUxZWE2Mzc3YjhiOTU0MzcwYjU0MDA2ZTAyZDY3IiwKICAgICJhc3NldHMvanVtcC9wYXJpdHktanVtcF90YWtlb2ZmLmpzb24iOiAiMmM3NzRhYWVhNGM2M2U2MzIzZjA5M2E1MTRhNjNiMzNmMWEzYjI0NGFlZDhiMzkxMzViMjQxN2FhN2Q0YmM4NCIsCiAgICAiYXNzZXRzL2p1bXAvY29udmVyc2lvbi1qdW1wX3Rha2VvZmYuanNvbiI6ICI2ODUwNTVjNjQwMzBlZGYyZWFjNjgwOGE2NWVlMTc3MWEyZmZkYTQyNWQzNzRmMDJmYzdiMTc2Nzg5MTQwOTIwIiwKICAgICJhc3NldHMvanVtcC9jb252ZXJzaW9uLWp1bXBfYWlyLmpzb24iOiAiYzMxMjZkMmI4OWZjYmVlNDU4YjQyMjgyNzA4MTU4OTkxMGUzMzNhMTdjNjUzYWFiNGQ3ZWY2ZDQ4NDVhZTQ4ZCIsCiAgICAiYXNzZXRzL2p1bXAvcGFyaXR5LWp1bXBfYWlyLmpzb24iOiAiMDRlMTg2YTI5OTQwNjgxNWQ1ZjVmMzA3YzhmYTlmMTdjZjUzZDYwZTZiMDFkOGJlZjMwMWM2NDljNjAwMTdlNyIsCiAgICAiYXNzZXRzL2p1bXAvYXNzZXQudnJhIjogIjg1NWQ5MDlkYmYyNDMzZmVlNTlhYzU0NzNkM2Q5ODhhYjcyY2YyNzU2YjljNDYyZTY0N2YwZTg5OWQyMDk2ZTkiLAogICAgImFzc2V0cy9qdW1wL3Bhcml0eS1qdW1wX2xhbmQuanNvbiI6ICI1OTE0MzdiYjVhODM3NDIyMDE2NTBmOGZiYjkzZmQ2NGY4OTk4ZGY1MjVmNWEzOTdkN2FjMjZjMTg3YzVkYjVkIiwKICAgICJhc3NldHMvanVtcC9SRUFETUUubWQiOiAiMzYyN2ZhZTZmNWUxYjY2YmJjNWZmNDA1OWQ4NjE5MGJmM2RlY2I3MTY4Y2Q4YmMzNWM2NTQ5NTczMDFiYzcxMCIsCiAgICAiYXNzZXRzL3JlbG9hZC9hbHRlcm5hdGVzL29wZW5pbmcvZXhwb3J0LW1hbmlmZXN0Lmpzb24iOiAiZjdkNTRiYTUwZjFjOWZjNzZmZGMzODVhMjhmNWY4MmMzZjBhYmU2NmNmMmVmNDkyYjc2MjcwYmI2ZDVjNzY3OSIsCiAgICAiYXNzZXRzL3JlbG9hZC9hbHRlcm5hdGVzL29wZW5pbmcvbWFuaWZlc3QuanNvbiI6ICI3MmUwMzE2NGY2Njc0YTdhYjE1MTNiOWJkOWQxNmZmNGYzNmVmNzdlNjk1MjhiYjZjMmI4NzFiMzlkMDcwNDliIiwKICAgICJhc3NldHMvcmVsb2FkL2FsdGVybmF0ZXMvb3BlbmluZy9hc3NldC52cnMiOiAiYzJiNTg1Y2I4ZGNjNjg2NTJmYjUyM2JhZDk3NjczMGQyZDNkYjg4ZjY0NDJjNWVmYzY5ZjAwOWNlYjJiMjBkNyIsCiAgICAiYXNzZXRzL3JlbG9hZC9hbHRlcm5hdGVzL29wZW5pbmcvYXNzZXQudnJtIjogIjcyMTk4NjM1NzIyODk1MWEzM2NiYTMyY2JlMDg4YWNlYjc2MTY5ZmE5YzBjOTc0ODIzNTU3NzVhYWQ4NTAyNmEiLAogICAgImFzc2V0cy9yZWxvYWQvYWx0ZXJuYXRlcy9vcGVuaW5nL3NvdXJjZS5qc29uIjogIjYyNzMzYjJmMjZkMTFjNzhiZjMzMDBlZDYyMGU1YjEyMTVmNDBlM2MwOTc3MDFjOTY4NGUyMmJmYjY3OTIzN2EiLAogICAgImFzc2V0cy9yZWxvYWQvYWx0ZXJuYXRlcy9vcGVuaW5nL3Bhcml0eS5qc29uIjogIjg3OTUzMDEyMWRlZDU4YmMxYWZmZTRlMGMyZTBkYWI5YjJiNDQ2ODA4YzVmODUwMzc0NDVjZjQ2N2UyYTBlZjIiLAogICAgImFzc2V0cy9yZWxvYWQvYWx0ZXJuYXRlcy9vcGVuaW5nL2Fzc2V0LnZyYSI6ICIyMDMzZTc4ZTJhNDNkNWM3YTJmYmNmMDk5ZjgxY2IzMWY1YjNiZGVhMGZmYzlhYWZjZTFhYTc4OTVjODQzMjU1IiwKICAgICJhc3NldHMvcmVsb2FkL2FsdGVybmF0ZXMvcGlja3VwL2V4cG9ydC1tYW5pZmVzdC5qc29uIjogIjY1NTY2YWY1NTU0MzgyZjRkYjBhZjVjZmNiYzY0MmQ2MWJjMDBiZDJiYzY2ZmVlMWY5MTRmMzM0OWU2OTUzMWEiLAogICAgImFzc2V0cy9yZWxvYWQvYWx0ZXJuYXRlcy9waWNrdXAvbWFuaWZlc3QuanNvbiI6ICJiNjJhMGEwYjI2MTQ5NTQwNGMzYmJiMTk0MTg5ODIzMzY2MWI3YjNiNjEyMmZiODFhZDc4ZmFmMjEwMjI5NTYzIiwKICAgICJhc3NldHMvcmVsb2FkL2FsdGVybmF0ZXMvcGlja3VwL2Fzc2V0LnZycyI6ICJjMmI1ODVjYjhkY2M2ODY1MmZiNTIzYmFkOTc2NzMwZDJkM2RiODhmNjQ0MmM1ZWZjNjlmMDA5Y2ViMmIyMGQ3IiwKICAgICJhc3NldHMvcmVsb2FkL2FsdGVybmF0ZXMvcGlja3VwL2Fzc2V0LnZybSI6ICI3MjE5ODYzNTcyMjg5NTFhMzNjYmEzMmNiZTA4OGFjZWI3NjE2OWZhOWMwYzk3NDgyMzU1Nzc1YWFkODUwMjZhIiwKICAgICJhc3NldHMvcmVsb2FkL2FsdGVybmF0ZXMvcGlja3VwL3NvdXJjZS5qc29uIjogIjFmZmVmN2ZiNzIxMTFhNmY5Mzc1MjhlYjFlNWNjNTZhODYyZDFlNGUwNjk0OTJiYzdkMGM1YzNmYTc1Njk2MjciLAogICAgImFzc2V0cy9yZWxvYWQvYWx0ZXJuYXRlcy9waWNrdXAvcGFyaXR5Lmpzb24iOiAiZmNkY2E5ZjNlODMzMzg1NGI3ZWI1Njc1MzcwMWRjNTVhNDA2MGRmYjAzNmE1ZjUyMmVhZTk1OWU2MDRmNjZhOCIsCiAgICAiYXNzZXRzL3JlbG9hZC9hbHRlcm5hdGVzL3BpY2t1cC9hc3NldC52cmEiOiAiNDhjMTUzOTllN2Y1ZTg5MWQ2OWY2Mzg3YTdhMjc5YTJlMWRkZGUyYWUyZjE5MzBlNGRhZGVmNjcyNjg5MGY5YSIsCiAgICAiYXNzZXRzL3JlbG9hZC9hbHRlcm5hdGVzL3Jlc2V0L2V4cG9ydC1tYW5pZmVzdC5qc29uIjogIjkxNjg3NzQ0NGU0ODcxMmE1MDY1NDg3ZGYzYTFiZmQyNjRmMTIzNjg3ZWUyYzhiYjcxYWFkNjM1YjQ2NmE0MmMiLAogICAgImFzc2V0cy9yZWxvYWQvYWx0ZXJuYXRlcy9yZXNldC9tYW5pZmVzdC5qc29uIjogIjU4MWJkMWQ4ZDMwNDJhMzkyODM2NDU3ZDk2NzUyMGViM2FhMzIzNWZhZDYxYjE4M2E4YTIxM2Q1Njk1YmQ5ZDQiLAogICAgImFzc2V0cy9yZWxvYWQvYWx0ZXJuYXRlcy9yZXNldC9hc3NldC52cnMiOiAiYzJiNTg1Y2I4ZGNjNjg2NTJmYjUyM2JhZDk3NjczMGQyZDNkYjg4ZjY0NDJjNWVmYzY5ZjAwOWNlYjJiMjBkNyIsCiAgICAiYXNzZXRzL3JlbG9hZC9hbHRlcm5hdGVzL3Jlc2V0L2Fzc2V0LnZybSI6ICI3MjE5ODYzNTcyMjg5NTFhMzNjYmEzMmNiZTA4OGFjZWI3NjE2OWZhOWMwYzk3NDgyMzU1Nzc1YWFkODUwMjZhIiwKICAgICJhc3NldHMvcmVsb2FkL2FsdGVybmF0ZXMvcmVzZXQvc291cmNlLmpzb24iOiAiY2IwOTIwOGE1NWFmZTE3MWRlMjllNDA5OWEyNjY2OTUyMjk1MjZjMmMyM2ZlZGQzOTc3MTllOWJlMDQ1Y2M2YiIsCiAgICAiYXNzZXRzL3JlbG9hZC9hbHRlcm5hdGVzL3Jlc2V0L3Bhcml0eS5qc29uIjogIjA5MzMyOTQ3NjFlZmI1ODZlNGVlYzZhNDc1ZmViYWI1Y2ZiYzJjZWJhMzc4MzZjZWFjYzJmNThkNjFjMWIxY2MiLAogICAgImFzc2V0cy9yZWxvYWQvYWx0ZXJuYXRlcy9yZXNldC9hc3NldC52cmEiOiAiYjZjYmFmYzNjODc1ZTkwNmU1ZDJmZDZhZDIwZjMwY2ViYmE4OTEwZTlkYTJiMDk3YjExYzJmZTExNjJhNTRiNCIKICB9Cn0K')
EXPECTED_ASSET_RECEIPT_SHA="756ad13125e39d67d669493a82d4f2959273dd9902c3752ef3ccde6744a9fa9b"
EXPECTED_RUSTC='rustc 1.99.0 (b940084d7 2026-09-28)\nbinary: rustc\ncommit-hash: b940084d7eb6a299eb4bfeb8e34901bc051e7ac4\ncommit-date: 2026-09-28\nhost: x86_64-unknown-linux-gnu\nrelease: 1.99.0\nLLVM version: 23.1.1\n'
ICD_RECEIPTS={'nvidia-vulkan.json': '{"file_format_version": "1.0.0", "ICD": {"library_path": "/usr/lib64-nvidia/libGLX_nvidia.so.0", "api_version": "1.3.0"}}', 'nvidia-egl.json': '{"file_format_version": "1.0.0", "ICD": {"library_path": "/usr/lib64-nvidia/libEGL_nvidia.so.0"}}'}
def require(value, message):
    if not value: raise RuntimeError(message)

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value): Path(path).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def process_rows():
    rows={}
    for p in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields=p.read_text().rsplit(') ',1)[1].split()
            rows[int(p.parent.name)]=(int(fields[1]),int(fields[19]),fields[0])
        except (OSError,ValueError,IndexError): pass
    return rows

def track(pid, known):
    rows=process_rows()
    selected={p for p,start in known.items() if p in rows and rows[p][1]==start}
    while True:
        children={p for p,(parent,_,_) in rows.items() if parent in selected}
        if children <= selected: break
        selected |= children
    known.update({p:rows[p][1] for p in selected})
    return {p for p in selected if rows[p][2]!='Z'}

def owned(command, cwd, env, output, timeout):
    output.mkdir(); record={'command':list(map(str,command)), 'cwd':str(cwd),'timeout_seconds':timeout,'started':time.time()}
    proc=None; known={}
    try:
        with (output/'stdout.log').open('xb') as stdout, (output/'stderr.log').open('xb') as stderr:
            proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,start_new_session=True)
            row=process_rows().get(proc.pid)
            record['initial_process_identity_verified']=row is not None
            require(row is not None,'could not establish owned process start identity; no unverified PID will be signaled')
            known={proc.pid:row[1]}
            record['pid']=proc.pid; write(output/'process.json',record)
            deadline=time.monotonic()+timeout
            while proc.poll() is None:
                track(proc.pid,known)
                if time.monotonic()>deadline: raise TimeoutError('owned process deadline')
                time.sleep(.1)
            record['exit_code']=proc.returncode
            require(not track(proc.pid,known),'owned process left live descendants')
    except BaseException as error:
        record['error']=repr(error)
        if proc:
            cleanup={'signals':[]}
            for sig in (signal.SIGTERM,signal.SIGKILL):
                for pid in sorted(track(proc.pid,known),key=lambda p:p==proc.pid):
                    row=process_rows().get(pid)
                    if row and row[1]==known.get(pid):
                        try: os.kill(pid,sig); cleanup['signals'].append([pid,int(sig)])
                        except ProcessLookupError: pass
                until=time.monotonic()+5
                while time.monotonic()<until and track(proc.pid,known): time.sleep(.1)
            cleanup['remaining']=sorted(track(proc.pid,known))
            try: proc.wait(timeout=2)
            except subprocess.TimeoutExpired: cleanup['wait_timeout']=True
            record['cleanup']=cleanup
        raise
    finally:
        record['finished']=time.time();write(output/'process.json',record)
    return record

def download(url,path,maximum):
    require(url.startswith('https://'),'HTTPS download required')
    digest=hashlib.sha256();size=0;started=time.time()
    with urllib.request.urlopen(url,timeout=45,context=ssl.create_default_context()) as response, path.open('xb') as stream:
        final=response.geturl();require(final.startswith('https://'),'insecure download redirect')
        while True:
            require(time.time()-started<600,'download overall deadline')
            chunk=response.read(1024*1024)
            if not chunk:break
            size+=len(chunk);require(size<=maximum,'download size bound exceeded')
            stream.write(chunk);digest.update(chunk)
    return {'url':url,'final_url':final,'bytes':size,'sha256':digest.hexdigest()}

def regular_inventory(root):
    paths=list(root.rglob('*'));require(not any(p.is_symlink() for p in paths),'asset symlink')
    return {str(p.relative_to(root)):sha(p) for p in sorted(paths) if p.is_file()}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--setup-root',type=Path,required=True);args=parser.parse_args()
    root=args.setup_root.absolute();require(not root.exists() and not root.is_symlink(),'fresh exclusive setup root required')
    root.mkdir(parents=False)
    result={'schema':'rust-duty-a100-fresh-setup/v1','passed':False,'started':time.time(),'controller_sha256':sha(__file__),'commands':[],
            'scope':'official compiler, isolated Python readers and exact original public assets only; no fixture build or GPU render'}
    def save():write(root/'setup-result.json',result)
    original_env=dict(os.environ);required_files={}
    try:
        require(sys.platform=='linux' and platform.machine()=='x86_64','Linux x86_64 required')
        forbidden={'RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_ENCODED_RUSTDOCFLAGS','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC_BOOTSTRAP','RUSTDOC','RUSTUP_TOOLCHAIN','RUSTUP_DIST_SERVER','RUSTUP_UPDATE_ROOT','VR_WEAPON_ASSET'}
        bad=forbidden.intersection(original_env)|{k for k in original_env if k.startswith(('CARGO_BUILD_','CARGO_TARGET_','CARGO_PROFILE_','CARGO_SOURCE_','CARGO_PATCH_'))}
        require(not bad,'inherited compiler/profile/asset override: '+','.join(sorted(bad)))
        result['os_release']=Path('/etc/os-release').read_text();result['libc']=platform.libc_ver()
        require(result['libc']==('glibc','2.39'),'original GLIBC2.39 required')
        gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True,timeout=30).strip()
        require(gpu=='NVIDIA A100-SXM4-40GB, 580.82.07','original hardware/driver required');result['gpu']=gpu
        missing=[name for name in ('cc','pkg-config') if shutil.which(name) is None]
        require(not missing,'missing standard build prerequisite: '+','.join(missing))
        result['build_tools']={name:shutil.which(name) for name in ('cc','pkg-config')}
        require(Path('/usr/lib64-nvidia/libGLX_nvidia.so.0').is_file(),'original NVIDIA graphics library absent')
        ctypes.CDLL('libvulkan.so.1');ctypes.CDLL('/usr/lib64-nvidia/libGLX_nvidia.so.0')
        result['existing_graphics_libraries_load']=True
        for name,raw in ICD_RECEIPTS.items():
            (root/name).write_text(raw);required_files[root/name]=sha(root/name)
        require(hashlib.sha256(ASSET_RECEIPT_RAW).hexdigest()==EXPECTED_ASSET_RECEIPT_SHA,'embedded original asset receipt differs')
        (root/'assets.json').write_bytes(ASSET_RECEIPT_RAW);required_files[root/'assets.json']=EXPECTED_ASSET_RECEIPT_SHA
        asset_receipt=json.loads(ASSET_RECEIPT_RAW);require(len(asset_receipt['files'])==77,'original 77-file inventory required')
        installer=root/'rustup-init'
        result['rustup_download']=download('https://static.rust-lang.org/rustup/dist/x86_64-unknown-linux-gnu/rustup-init',installer,64*1024*1024)
        checksum=root/'rustup-init.sha256'
        result['rustup_checksum_download']=download('https://static.rust-lang.org/rustup/dist/x86_64-unknown-linux-gnu/rustup-init.sha256',checksum,1024)
        expected=checksum.read_text().split()[0];require(re.fullmatch('[0-9a-f]{64}',expected) and sha(installer)==expected,'official installer checksum differs')
        required_files[installer]=expected;required_files[checksum]=sha(checksum);installer.chmod(0o755)
        env=dict(original_env,RUSTUP_HOME=str(root/'rustup'),CARGO_HOME=str(root/'cargo'),PYTHONDONTWRITEBYTECODE='1')
        env['PATH']=str(root/'cargo/bin')+':'+env['PATH']
        command=[str(installer),'-y','--no-modify-path','--profile','minimal','--default-toolchain','1.99.0','--default-host','x86_64-unknown-linux-gnu']
        record=owned(command,root,env,root/'install-rust',900);result['commands'].append(record);save();require(record['exit_code']==0,'official Rust installation failed')
        direct=root/'rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin';cargo=direct/'cargo';rustc=direct/'rustc'
        require(cargo.is_file() and rustc.is_file(),'selected direct compiler missing')
        compiler=subprocess.check_output([str(rustc),'-Vv'],cwd=root,env=env,text=True,timeout=30)
        cargo_version=subprocess.check_output([str(cargo),'-Vv'],cwd=root,env=env,text=True,timeout=30)
        require(compiler==EXPECTED_RUSTC,'exact original compiler differs')
        require(cargo_version.startswith('cargo 1.99.0 (5f94df478 2026-08-27)\n') and '\nhost: x86_64-unknown-linux-gnu\n' in cargo_version,'exact original Cargo release/host differs')
        result.update(compiler=compiler,cargo=cargo_version,direct_cargo=str(cargo))
        required_files[cargo]=sha(cargo);required_files[rustc]=sha(rustc)
        # An isolated package directory changes no installed system packages.
        readers=root/'python-readers'
        pip_env={k:v for k,v in env.items() if not k.startswith('PIP_') and k!='PYTHONPATH'}
        pip_env['PIP_CONFIG_FILE']=os.devnull
        result['ignored_pip_environment_names']=sorted(k for k in env if k.startswith('PIP_'))
        record=owned([sys.executable,'-I','-m','pip','--isolated','install','--disable-pip-version-check','--no-input','--no-cache-dir','--only-binary=:all:','--no-deps','--index-url','https://pypi.org/simple','--report',str(root/'reader-install-report.json'),'--target',str(readers),'Pillow==11.3.0','PyYAML==6.0.3'],root,pip_env,root/'install-readers',300)
        result['commands'].append(record);save();require(record['exit_code']==0,'reader package installation failed')
        package_env=dict(env,PYTHONPATH=str(readers))
        versions=subprocess.check_output([sys.executable,'-c','import PIL,yaml,json;print(json.dumps({"Pillow":PIL.__version__,"PyYAML":yaml.__version__}))'],cwd=root,env=package_env,text=True,timeout=30)
        require(json.loads(versions)=={'Pillow':'11.3.0','PyYAML':'6.0.3'},'reader versions differ');result['reader_versions']=json.loads(versions)
        result['reader_files']=regular_inventory(readers)
        required_files[root/'reader-install-report.json']=sha(root/'reader-install-report.json')
        archive=root/'original-public-release.zip'
        result['asset_download']=download(asset_receipt['url'],archive,512*1024*1024);save()
        require(sha(archive)==asset_receipt['archive_sha256'],'original public release archive differs');required_files[archive]=asset_receipt['archive_sha256']
        assets=root/'authored-assets';assets.mkdir();members={}
        with zipfile.ZipFile(archive) as z:
            entries=z.infolist();names=[info.filename for info in entries]
            require(len(names)==len(set(names)),'duplicate archive names')
            for name,expected in asset_receipt['files'].items():
                relative=Path(name);require(not relative.is_absolute() and '..' not in relative.parts and name.startswith('assets/') and not name.startswith('assets/weapons/'),'unsafe or private asset requested')
                matches=[info for info in entries if info.filename==name or info.filename.endswith('/'+name)]
                require(len(matches)==1,'missing/ambiguous asset: '+name);info=matches[0]
                require(not info.is_dir() and ((info.external_attr>>16)&0o170000) in (0,0o100000) and info.file_size<=256*1024*1024,'nonregular/oversized asset entry')
                raw=z.read(info);require(hashlib.sha256(raw).hexdigest()==expected,'selected public asset hash differs: '+name)
                target=assets/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);members[name]=info.filename
        require(regular_inventory(assets)==asset_receipt['files'],'materialized original asset inventory differs')
        result['asset_members']=members;result['asset_files']=regular_inventory(assets)
        require(not (assets/'assets/weapons').exists(),'private assets unexpectedly materialized')
        # The frozen run controller rejects any Cargo config; enforce it now.
        for ancestor in (root,*root.parents,root/'cargo'):
            candidates=[ancestor/'.cargo/config',ancestor/'.cargo/config.toml'] if ancestor!=root/'cargo' else [ancestor/'config',ancestor/'config.toml']
            require(not any(p.exists() or p.is_symlink() for p in candidates),'unbound Cargo config exists')
        result['launch_parameters']={'assets':str(assets),'cargo':str(cargo),'environment':{'CARGO_HOME':str(root/'cargo'),'RUSTUP_HOME':str(root/'rustup'),'PYTHONPATH':str(readers),'PYTHONDONTWRITEBYTECODE':'1'}}
        result['passed']=True
    except BaseException as error:
        result['error']={'type':type(error).__name__,'message':str(error)}
    finally:
        try:
            require(sha(__file__)==result['controller_sha256'],'setup controller changed')
            require(all(sha(path)==expected for path,expected in required_files.items()),'retained setup input changed')
            if 'reader_files' in result:require(regular_inventory(root/'python-readers')==result['reader_files'],'retained reader package files changed')
            if 'asset_files' in result:require(regular_inventory(root/'authored-assets')==result['asset_files'],'retained runtime assets changed')
            result['final_inputs_verified']=True
        except BaseException as error:result['final_inputs_verified']=False;result['final_check_error']=repr(error);result['passed']=False
        result['retained_file_sha256']={str(path.relative_to(root)):expected for path,expected in required_files.items()}
        result['finished']=time.time();save();print(json.dumps({'passed':result['passed'],'setup_root':str(root),'error':result.get('error'),'launch_parameters':result.get('launch_parameters')}),flush=True)
    return 0 if result['passed'] else 1
if __name__=='__main__':sys.exit(main())
