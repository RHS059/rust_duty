#!/usr/bin/env python3
"""Prepare, run sequential desktop game instances, and analyze real present traces.

Preparation/analysis never launch the game. Run is opt-in and needs an existing
dedicated desktop and packaged native-runtime game. No GPU is provisioned here.
"""
import argparse
import contextlib
import csv
import hashlib
import json
import math
import os
from pathlib import Path, PureWindowsPath
import platform
import re
import statistics
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace

from exclusive_output import write_bytes_exclusive, write_text_exclusive
import summarize_frame_performance as frames
import summarize_cpu_substages as cpu_substages
import summarize_gpu_timing as gpu_timing
from performance_matrix_driver import DriverError, create_driver, exit_snapshot, replay, tap, wait_until

PLAN_SCHEMA = 'rust-duty-real-game-performance-matrix/v1'
# Inventory audited at 49c3bf9. A new support surface needs review, not a guessed
# mapping of settings merely because two familiar source tokens still exist.
AUDITED_RUNTIME_MANIFEST = 'abdd0c3dff03f4d0f5b8b823d2274938946fe4b424d3468091d745035039ac7e'
SOURCE_PATHS = ('src/main.rs', 'src/app.rs', 'src/settings.rs', 'src/world_draw.rs',
                'src/viewmodel_draw.rs', 'src/platform/launch.rs', 'src/platform/window.rs',
                'src/render/device.rs', 'src/render/mesh.rs', 'src/render/target.rs',
                'src/render/runtime.rs', 'src/frame_performance.rs',
                'src/frame_performance_session.rs', 'src/graphics_device.rs',
                'src/telemetry_export.rs', 'src/control.rs', 'src/asset_path.rs')
# Additional exact inventory for optional CPU substage sidecars. Keep the
# historical 17-file binding for pinned packages; never accept arbitrary edits.
SUBSTAGE_SOURCE_PATHS = (*SOURCE_PATHS, 'src/frame_cpu_substages.rs',
                        'src/render/frame.rs', 'src/lib.rs')
AUDITED_SUBSTAGE_RUNTIME_MANIFEST = '9e95260bd852422caecb57b23abb3fb60ceeaae3f4d77bb7e1d2d57d36dc4ac7'
# Reviewed allocation-only CPU changes are also part of the candidate's exact
# source witness. A live checkout must never fall back to the narrower inventory
# when one of these files changes. Historical artifact witnesses remain valid.
CPU_SOURCE_PATHS = ('src/draw/mod.rs', 'src/render/lines.rs',
                    'src/render/text.rs', 'src/render/plan.rs')
CPU_BASELINE_MANIFEST = '66a130aeeaeaa6ce80cfc3525d1e46388f7cd5b1c0755da2e1e302d9b055ee22'
CPU_CANDIDATE_SOURCE_PATHS = (*SUBSTAGE_SOURCE_PATHS, *CPU_SOURCE_PATHS)
AUDITED_CPU_CANDIDATE_MANIFEST = '0a904c635739b3365ff99569466098e71b3d81e8e456939163421aad311fe4c5'
PRESENT_SOURCE_PATHS = ('src/render/present_policy.rs', 'src/render/mod.rs', 'src/render/backend.rs')
PRESENT_BASELINE_MANIFEST = '71695b3988c2fae2652a9b14ce923ddb135004b14fe084e90e81772214fa657e'
PRESENT_CANDIDATE_SOURCE_PATHS = (*CPU_CANDIDATE_SOURCE_PATHS, *PRESENT_SOURCE_PATHS)
AUDITED_PRESENT_CANDIDATE_MANIFEST = 'a6af645f2e1b5c4c71b9a65964a963a1ad1217a75efff7b0cf8f9c39280880a6'
GPU_SOURCE_PATHS = ('src/frame_gpu_capture.rs', 'src/render/gpu_timing.rs')
GPU_CANDIDATE_SOURCE_PATHS = (*PRESENT_CANDIDATE_SOURCE_PATHS, *GPU_SOURCE_PATHS)
# Preserve the first published 29-file WIP witness after formatting/fixes.
AUDITED_GPU_INITIAL_MANIFEST = '445974fef81cb3f1d97ce7a21a0ebabc48e8fab92794f0898ad89dec89e7db2e'
AUDITED_GPU_CANDIDATE_MANIFEST = '9b7ae93be3a4d4aed9b662d0c27ff18d0b1e12e99c4dc916422c98e0c5eae3c6'
# Same instrumented production tree with exactly the four image-validated CPU
# files restored from 70ff2933; never an alias for another historical build.
AUDITED_GPU_CPU_BASELINE_MANIFEST = 'dbabe2822dd73410a7f05c0f03807aa80d5720351c4a9c13ebdee1276fecc195'
# Closed compile identity for that historical timing pair, independent of later image candidates.
AUDITED_GPU_PRODUCTION_MANIFEST = 'd74a901c91ffd6746826e7e9c7f0ff447157774d3ea8d661d4912caf84e4a33c'
# Separate detail-enabled inventory. Historical GPU/CPU pins and the immutable
# source-pair builder remain unchanged; no old artifact is relabeled.
ENCODE_DETAIL_SOURCE_PATHS = (*GPU_CANDIDATE_SOURCE_PATHS, 'src/frame_encode_detail.rs',
                             'src/render/arena.rs', 'Cargo.toml', 'Cargo.lock')
AUDITED_ENCODE_DETAIL_INITIAL_MANIFEST = 'bd33a722405c3ec0073ebd28dc390c7cddffcf84ab48b2ba1833d9b97ed862e4'
AUDITED_ENCODE_DETAIL_FORMATTED_MANIFEST = '480e05173ad3ad42879fc1620e01fd4e9035148fadebbb2acb5b1b0cc21c8bf7'
# Combined physical-window and formatted producer; historical Hal bytes retain their own pin.
AUDITED_ENCODE_DETAIL_MANIFEST = 'b673d91755f8e733ee075d79ae97f8c2afff7df5488e38cf5c3e8030b7c763c0'
# New upload experiment: keep every older inventory and digest unchanged.
UPLOAD_REUSE_SOURCE_PATHS = (*ENCODE_DETAIL_SOURCE_PATHS, 'src/frame_upload_policy.rs',
                             'src/render/upload_cache.rs')
AUDITED_UPLOAD_REUSE_INITIAL_MANIFEST = '30034419d16eaf4cfa336e5bde862dd660a54ff3736dbc30cfd1f47b0d896460'
AUDITED_UPLOAD_IMMUTABLE_INITIAL_CONTROL_MANIFEST = 'dd7325d511b76829660abe3cd8d0bb4a5c17ae970a68025d888eafe8e74fcfcc'
AUDITED_UPLOAD_REUSE_MANIFEST = '2dbfe6bbab145c675e2517eee8c2ec2476e467e32ec66b8c8938c05d55434493'
AUDITED_UPLOAD_IMMUTABLE_CONTROL_MANIFEST = 'd80012eb4d1d4a5e669b98aae8910fc24302f1fc38bd92ed8a3593a0fae70dd7'
# Exact arena-only serialization experiment; all upload history remains unchanged.
AUDITED_ARENA_SERIALIZATION_MANIFEST = '3a995ea0fb0e8d4173921c7fadd0689eab6c67fc9c5fe8339173129527acae43'
# The two loader modules were unchanged throughout the historical inventories.
# Verify them even for a narrow live witness, or CPU-only loader edits could hide.
LOADER_BASELINE = {
    'src/authored_viewmodel.rs': 'c87f0a15241d8a03ec3426eef3b6c3809b257789e4d533c9006e80c3807fdaf5',
    'src/weapon_model.rs': 'b6496c9409485023d97cc8e08e43ccbecacef35c72611e2b1f7fa594a1237071',
}
LOADER_SOURCE_PATHS = (*UPLOAD_REUSE_SOURCE_PATHS, *LOADER_BASELINE)
AUDITED_AUTHORED_DEDUP_MANIFEST = 'fff66052fe41e445d50eaf2ae689a29cc68b7d3c3d4502d21d147424c60d3e06'
# Resident geometry/shader is a distinct expanded source class. The explicit
# compile-time CPU reference control changes only its policy constant.
RESIDENT_BASELINE = {
    'src/draw/facade.rs': '18ce443544975ef4bac82f2c599a9f0c60f8a8b709a731437f6fa1083e7ca5b6',
    'src/legacy_macroquad/mod.rs': 'f8aff43030d1e2e826fc296b4bcb716c0b13c685e1733b838bc5db09f41bf90c',
}
RESIDENT_NEW_PATHS = ('src/draw/resident.rs', 'src/render/resident.rs',
                      'src/render/resident.wgsl', 'src/frame_resident_policy.rs')
RESIDENT_SOURCE_PATHS = (*LOADER_SOURCE_PATHS, *RESIDENT_NEW_PATHS,
                         'src/draw/facade.rs', 'src/legacy_macroquad/mod.rs')
AUDITED_RESIDENT_CANDIDATE_MANIFEST = 'c754f89052fc3812dbbdc9675a452b056a881696d3cf9fbd7398fc580bcbfe6f'
AUDITED_RESIDENT_CONTROL_MANIFEST = '4eeea34f29b7d20a24060af152e7cd2170322674a3d2c0abaad8603497a6ac6b'
# The staging source pool has its own expanded class and one-line control.
STAGING_NEW_PATHS = ('src/frame_staging_policy.rs', 'src/render/upload_staging.rs', 'src/render/upload_staging_layout.rs')
STAGING_SOURCE_PATHS = (*RESIDENT_SOURCE_PATHS, *STAGING_NEW_PATHS)
AUDITED_STAGING_CANDIDATE_MANIFEST = 'fc6c5bc8b09562dea007388988dc610b8f3b91c479be4eb4ba1cedb3d0953402'
AUDITED_STAGING_CONTROL_MANIFEST = 'f91a20a9445b96ca3e0ddbc13449ea574470ce9ec0700b3a79984be694dd54aa'
# Separate resident on/off pair with staging enabled identically on both sides.
AUDITED_STAGING_RESIDENT_CPU_CONTROL_MANIFEST = '7a3524dceb1fa8042fb5c3060047e4ed64fc7cc0a8dcf15c5c9c832d01c7c06c'
ARITHMETIC_NEW_PATHS = ('src/render/resident_vertex_probe.rs', 'src/render/resident_vertex_probe.wgsl')
ARITHMETIC_SOURCE_PATHS = (*STAGING_SOURCE_PATHS, *ARITHMETIC_NEW_PATHS)
AUDITED_ARITHMETIC_CANDIDATE_MANIFEST = 'b5120632999e1c599f89740ec8550432da06575b9175d3ba937f9474a5a707d0'
AUDITED_ARITHMETIC_STAGING_CONTROL_MANIFEST = '90ff8383a7a028a0860630f8b4d9eb8425110288e8597b7e3d3df5bab4ea9de2'
AUDITED_ARITHMETIC_RESIDENT_CPU_CONTROL_MANIFEST = 'a20487a0640d940f1fdda9da7419345f5b46f4cd3a58c25df7806eae3417f82e'



BACKENDS = {'dx12': 'Dx12', 'vulkan': 'Vulkan', 'metal': 'Metal', 'gl-harness': 'Gl'}
UNAVAILABLE = {
    'fps_cap': 'No application FPS limiter or CLI selector. Fifo may pace at display refresh; it is not a 60 FPS cap.',
    'vsync_choices': 'Native surface configuration hard-codes Fifo; no supported off/mailbox/immediate selector.',
    'antialiasing_choices': 'Native targets/pipelines are single-sample. No AA selector. Legacy requests 4x window MSAA with single-sample viewmodel target.',
    'lod': 'No LOD selector or runtime LOD implementation in this inventory.',
    'offscreen_mesh_hiding': 'No user-selectable visibility/frustum/occlusion-culling mode; native mesh cull_mode is None.',
    'record_off_overhead': 'F8 couples CPU trace to CSV/GPU-counter recording. Record-off emits no frame trace; an independent observer is needed to measure its overhead.',
    'hud_off': 'F1 controls the debug panel only. The main HUD and recording indicator remain on.',
    'gpu_frame_duration': 'No GPU timestamp queries. GPU occupancy/memory counters are not frame duration.',
    'draw_pass_triangle_counts': 'Not emitted by actual-game frame telemetry. Synthetic example counts are not substituted.',
    'legacy_end_to_end': '--renderer=gl selects legacy Macroquad, whose Record export has no present-return trace.',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def json_read(path, limit=2 * 1024 * 1024):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Expected regular nonsymlink JSON: ' + str(path))
    with path.open('rb') as stream:
        data = stream.read(limit + 1)
    require(len(data) <= limit, 'JSON exceeds bound: ' + path.name)
    result = json.loads(data.decode('utf-8'), object_pairs_hook=frames._unique,
                        parse_constant=frames._constant)
    frames._finite_tree(result)
    require(isinstance(result, dict), 'Expected JSON object: ' + path.name)
    return result


def write_json(path, value):
    write_text_exclusive(path, json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def sha256(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Expected regular nonsymlink file: ' + str(path))
    result = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(1024 * 1024):
            result.update(data)
    return result.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def audited_inventory(digest):
    if digest in (AUDITED_ARITHMETIC_CANDIDATE_MANIFEST, AUDITED_ARITHMETIC_STAGING_CONTROL_MANIFEST,
                  AUDITED_ARITHMETIC_RESIDENT_CPU_CONTROL_MANIFEST):
        return ARITHMETIC_SOURCE_PATHS
    if digest in (AUDITED_STAGING_CANDIDATE_MANIFEST, AUDITED_STAGING_CONTROL_MANIFEST,
                  AUDITED_STAGING_RESIDENT_CPU_CONTROL_MANIFEST):
        return STAGING_SOURCE_PATHS
    if digest in (AUDITED_RESIDENT_CANDIDATE_MANIFEST, AUDITED_RESIDENT_CONTROL_MANIFEST):
        return RESIDENT_SOURCE_PATHS
    if digest == AUDITED_AUTHORED_DEDUP_MANIFEST:
        return LOADER_SOURCE_PATHS
    if digest in (AUDITED_ARENA_SERIALIZATION_MANIFEST, AUDITED_UPLOAD_REUSE_INITIAL_MANIFEST, AUDITED_UPLOAD_IMMUTABLE_INITIAL_CONTROL_MANIFEST,
                  AUDITED_UPLOAD_REUSE_MANIFEST, AUDITED_UPLOAD_IMMUTABLE_CONTROL_MANIFEST):
        return UPLOAD_REUSE_SOURCE_PATHS
    if digest in (AUDITED_ENCODE_DETAIL_INITIAL_MANIFEST, AUDITED_ENCODE_DETAIL_FORMATTED_MANIFEST, AUDITED_ENCODE_DETAIL_MANIFEST):
        return ENCODE_DETAIL_SOURCE_PATHS
    if digest == AUDITED_RUNTIME_MANIFEST:
        return SOURCE_PATHS
    if digest == AUDITED_SUBSTAGE_RUNTIME_MANIFEST:
        return SUBSTAGE_SOURCE_PATHS
    if digest == AUDITED_CPU_CANDIDATE_MANIFEST:
        return CPU_CANDIDATE_SOURCE_PATHS
    if digest == AUDITED_PRESENT_CANDIDATE_MANIFEST:
        return PRESENT_CANDIDATE_SOURCE_PATHS
    if digest in (AUDITED_GPU_INITIAL_MANIFEST, AUDITED_GPU_CANDIDATE_MANIFEST, AUDITED_GPU_CPU_BASELINE_MANIFEST):
        return GPU_CANDIDATE_SOURCE_PATHS
    return None


def source_identity(repository):
    repository = Path(repository)
    commit = subprocess.check_output(['git', '-C', str(repository), 'rev-parse', 'HEAD'], text=True).strip()
    if any((repository / name).exists() or (repository / name).is_symlink() for name in ARITHMETIC_NEW_PATHS):
        result = {}
        for name in ARITHMETIC_SOURCE_PATHS:
            path = repository / name
            require(path.is_file() and not path.is_symlink(),
                    'Arithmetic inventory is missing; cannot fall back to a historical witness: ' + name)
            data = path.read_bytes()
            committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
            require(data == committed, 'Uncommitted arithmetic source: ' + name)
            result[name] = hashlib.sha256(data).hexdigest()
        require(canonical_hash(result) in (AUDITED_ARITHMETIC_CANDIDATE_MANIFEST,
                  AUDITED_ARITHMETIC_STAGING_CONTROL_MANIFEST, AUDITED_ARITHMETIC_RESIDENT_CPU_CONTROL_MANIFEST),
                'Arithmetic source changed; cannot fall back to a narrower historical witness')
        return {'commit': commit, 'runtime_files_sha256': result}
    if any((repository / name).exists() or (repository / name).is_symlink() for name in STAGING_NEW_PATHS):
        result = {}
        for name in STAGING_SOURCE_PATHS:
            path = repository / name
            require(path.is_file() and not path.is_symlink(),
                    'Staging inventory is missing; cannot fall back to a historical witness: ' + name)
            data = path.read_bytes()
            committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
            require(data == committed, 'Uncommitted staging source: ' + name)
            result[name] = hashlib.sha256(data).hexdigest()
        require(canonical_hash(result) in (AUDITED_STAGING_CANDIDATE_MANIFEST, AUDITED_STAGING_CONTROL_MANIFEST,
                  AUDITED_STAGING_RESIDENT_CPU_CONTROL_MANIFEST),
                'Staging source changed; cannot fall back to a narrower historical witness')
        return {'commit': commit, 'runtime_files_sha256': result}
    if any((repository / name).exists() or (repository / name).is_symlink() for name in RESIDENT_NEW_PATHS):
        result = {}
        for name in RESIDENT_SOURCE_PATHS:
            path = repository / name
            require(path.is_file() and not path.is_symlink(),
                    'Resident inventory is missing; cannot fall back to a historical witness: ' + name)
            data = path.read_bytes()
            committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
            require(data == committed, 'Uncommitted resident source: ' + name)
            result[name] = hashlib.sha256(data).hexdigest()
        require(canonical_hash(result) in (AUDITED_RESIDENT_CANDIDATE_MANIFEST, AUDITED_RESIDENT_CONTROL_MANIFEST),
                'Resident source changed; cannot fall back to a narrower historical witness')
        return {'commit': commit, 'runtime_files_sha256': result}
    for name, expected in RESIDENT_BASELINE.items():
        path = repository / name
        require(path.is_file() and not path.is_symlink(), 'Missing/unsafe historical resident support: ' + name)
        data = path.read_bytes()
        committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
        require(data == committed, 'Uncommitted resident support: ' + name)
        require(hashlib.sha256(data).hexdigest() == expected,
                'Resident support changed; cannot fall back to a narrower historical witness: ' + name)
    result = {}
    for name in SOURCE_PATHS:
        data = (repository / name).read_bytes()
        committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
        require(data == committed, 'Uncommitted runtime source: ' + name)
        result[name] = hashlib.sha256(data).hexdigest()
    if canonical_hash(result) != AUDITED_RUNTIME_MANIFEST:
        for name in SUBSTAGE_SOURCE_PATHS[len(SOURCE_PATHS):]:
            path = repository / name
            require(path.is_file() and not path.is_symlink(),
                    'Audited runtime support changed; missing sidecar inventory: ' + name)
            data = path.read_bytes()
            committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
            require(data == committed, 'Uncommitted runtime source: ' + name)
            result[name] = hashlib.sha256(data).hexdigest()
    cpu_sources = {}
    for name in CPU_SOURCE_PATHS:
        path = repository / name
        require(path.is_file() and not path.is_symlink(),
                'Audited runtime support changed; missing CPU inventory: ' + name)
        data = path.read_bytes()
        committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
        require(data == committed, 'Uncommitted runtime source: ' + name)
        cpu_sources[name] = hashlib.sha256(data).hexdigest()
    candidate = {**result, **cpu_sources}
    present_sources = {}
    for name in PRESENT_SOURCE_PATHS[1:]:
        path = repository / name
        require(path.is_file() and not path.is_symlink(),
                'Audited runtime support changed; missing present inventory: ' + name)
        data = path.read_bytes()
        committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
        require(data == committed, 'Uncommitted runtime source: ' + name)
        present_sources[name] = hashlib.sha256(data).hexdigest()
    present_policy = repository / PRESENT_SOURCE_PATHS[0]
    gpu_present = any((repository / name).exists() or (repository / name).is_symlink()
                      for name in GPU_SOURCE_PATHS)
    require(not gpu_present or present_policy.exists(),
            'GPU runtime source cannot fall back to a narrower source inventory')
    if present_policy.exists() or present_policy.is_symlink():
        for name in PRESENT_SOURCE_PATHS:
            path = repository / name
            require(path.is_file() and not path.is_symlink(),
                    'Audited runtime support changed; missing present inventory: ' + name)
            data = path.read_bytes()
            committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
            require(data == committed, 'Uncommitted runtime source: ' + name)
            candidate[name] = hashlib.sha256(data).hexdigest()
        if gpu_present:
            for name in GPU_SOURCE_PATHS:
                path = repository / name
                require(path.is_file() and not path.is_symlink(),
                        'Audited runtime support changed; missing GPU inventory: ' + name)
                data = path.read_bytes()
                committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
                require(data == committed, 'Uncommitted runtime source: ' + name)
                candidate[name] = hashlib.sha256(data).hexdigest()
            detail = repository / 'src/frame_encode_detail.rs'
            if detail.exists() or detail.is_symlink():
                for name in ENCODE_DETAIL_SOURCE_PATHS[len(GPU_CANDIDATE_SOURCE_PATHS):]:
                    path = repository / name
                    require(path.is_file() and not path.is_symlink(),
                            'Audited encode-detail inventory is missing: ' + name)
                    data = path.read_bytes()
                    committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
                    require(data == committed, 'Uncommitted encode-detail source: ' + name)
                    candidate[name] = hashlib.sha256(data).hexdigest()
                reuse_present = any((repository / name).exists() or (repository / name).is_symlink()
                                    for name in UPLOAD_REUSE_SOURCE_PATHS[len(ENCODE_DETAIL_SOURCE_PATHS):])
                if reuse_present:
                    for name in UPLOAD_REUSE_SOURCE_PATHS[len(ENCODE_DETAIL_SOURCE_PATHS):]:
                        path = repository / name
                        require(path.is_file() and not path.is_symlink(),
                                'Audited upload-reuse inventory is missing: ' + name)
                        data = path.read_bytes()
                        committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
                        require(data == committed, 'Uncommitted upload-reuse source: ' + name)
                        candidate[name] = hashlib.sha256(data).hexdigest()
                    require(canonical_hash(candidate) in (AUDITED_ARENA_SERIALIZATION_MANIFEST, AUDITED_UPLOAD_REUSE_INITIAL_MANIFEST, AUDITED_UPLOAD_IMMUTABLE_INITIAL_CONTROL_MANIFEST,
                  AUDITED_UPLOAD_REUSE_MANIFEST, AUDITED_UPLOAD_IMMUTABLE_CONTROL_MANIFEST),
                            'Audited upload-reuse runtime changed; cannot fall back to historical pins')
                else:
                    require(canonical_hash(candidate) in (AUDITED_ENCODE_DETAIL_INITIAL_MANIFEST, AUDITED_ENCODE_DETAIL_FORMATTED_MANIFEST, AUDITED_ENCODE_DETAIL_MANIFEST),
                            'Audited encode-detail runtime changed; cannot fall back to historical pins')
            else:
                require(canonical_hash(candidate) in (AUDITED_GPU_INITIAL_MANIFEST, AUDITED_GPU_CANDIDATE_MANIFEST, AUDITED_GPU_CPU_BASELINE_MANIFEST),
                        'Audited GPU runtime changed; cannot fall back to a narrower source inventory')
        else:
            require(canonical_hash(candidate) == AUDITED_PRESENT_CANDIDATE_MANIFEST,
                    'Audited present runtime changed; cannot fall back to a narrower source inventory')
        result = candidate
    elif canonical_hash(candidate) == AUDITED_CPU_CANDIDATE_MANIFEST:
        require(canonical_hash(present_sources) == PRESENT_BASELINE_MANIFEST,
                'Audited present runtime changed; cannot fall back to a narrower source inventory')
        result = candidate
    else:
        require(canonical_hash(present_sources) == PRESENT_BASELINE_MANIFEST,
                'Audited present runtime changed; cannot fall back to a narrower source inventory')
        require(canonical_hash(cpu_sources) == CPU_BASELINE_MANIFEST,
                'Audited CPU runtime changed; cannot fall back to a narrower source inventory')
    loader = {}
    for name in LOADER_BASELINE:
        path = repository / name
        require(path.is_file() and not path.is_symlink(), 'Missing/unsafe authored loader: ' + name)
        data = path.read_bytes()
        committed = subprocess.check_output(['git', '-C', str(repository), 'show', commit + ':' + name])
        require(data == committed, 'Uncommitted authored loader: ' + name)
        loader[name] = hashlib.sha256(data).hexdigest()
    if loader != LOADER_BASELINE:
        expanded = {**result, **loader}
        require(canonical_hash(expanded) == AUDITED_AUTHORED_DEDUP_MANIFEST,
                'Authored loader changed; cannot fall back to a narrower historical witness')
        result = expanded
    require(audited_inventory(canonical_hash(result)) is not None,
            'Audited runtime support changed; review the matrix inventory before updating its source binding')
    return {'commit': commit, 'runtime_files_sha256': result}


def export_witness(repository, output, harness=None):
    """Export only already verified source bytes, never manufacture a Git tree."""
    source = source_identity(repository)
    output = Path(output)
    output.mkdir()
    for name, digest in source['runtime_files_sha256'].items():
        data = (Path(repository) / name).read_bytes()
        require(hashlib.sha256(data).hexdigest() == digest, 'Source changed during witness export')
        destination = output / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        write_bytes_exclusive(destination, data)
    entrypoint = None
    if harness is not None:
        digest = sha256(harness)
        data = Path(harness).read_bytes()
        require(hashlib.sha256(data).hexdigest() == digest, 'Harness changed during witness export')
        name = 'examples/linux_actual_game_gl.rs'
        (output / 'examples').mkdir()
        write_bytes_exclusive(output / name, data)
        entrypoint = {'source_path': name, 'source_sha256': digest}
    require(source_identity(repository) == source, 'Git/source identity changed during witness export')
    witness = {'schema': 'rust-duty-matrix-source-witness/v1', 'source': source,
               'origin': 'Exported from a live Git checkout; every runtime file matched its committed blob.',
               'audited_runtime_manifest_sha256': canonical_hash(source['runtime_files_sha256']),
               'harness': entrypoint}
    write_json(output / 'SOURCE_WITNESS.json', witness)
    return sha256(output / 'SOURCE_WITNESS.json')


def artifact_source(directory, expected_digest):
    directory = Path(directory)
    require(directory.is_dir() and not directory.is_symlink(), 'Expected real source-witness directory')
    require(isinstance(expected_digest, str) and re.fullmatch('[0-9a-f]{64}', expected_digest),
            'Artifact witness requires a separate expected --witness-sha256')
    path = directory / 'SOURCE_WITNESS.json'
    require(sha256(path) == expected_digest, 'Source witness digest differs from separately supplied value')
    witness = json_read(path)
    require(set(witness) == {'schema', 'source', 'origin', 'audited_runtime_manifest_sha256', 'harness'}
            and witness['schema'] == 'rust-duty-matrix-source-witness/v1'
            and witness['origin'] == 'Exported from a live Git checkout; every runtime file matched its committed blob.'
            and audited_inventory(witness['audited_runtime_manifest_sha256']) is not None,
            'Invalid source witness schema/provenance')
    source = witness['source']
    require(isinstance(source, dict) and set(source) == {'commit', 'runtime_files_sha256'}
            and isinstance(source['commit'], str) and re.fullmatch('[0-9a-f]{40}', source['commit']),
            'Invalid witnessed source identity')
    recorded = source['runtime_files_sha256']
    inventory = audited_inventory(witness['audited_runtime_manifest_sha256'])
    require(isinstance(recorded, dict) and set(recorded) == set(inventory)
            and canonical_hash(recorded) == witness['audited_runtime_manifest_sha256'],
            'Witness does not contain exactly the audited runtime support inventory')
    allowed = {'SOURCE_WITNESS.json', *inventory}
    harness = witness['harness']
    if harness is not None:
        require(isinstance(harness, dict) and set(harness) == {'source_path', 'source_sha256'}
                and harness['source_path'] == 'examples/linux_actual_game_gl.rs', 'Invalid witnessed harness identity')
        allowed.add(harness['source_path'])
    found = set()
    for entry in directory.rglob('*'):
        require(not entry.is_symlink(), 'Witness must not contain symbolic links')
        if entry.is_file():
            found.add(entry.relative_to(directory).as_posix())
    require(found == allowed, 'Unexpected or missing source-witness files')
    # Reject linked ancestor directories before reading any source through them.
    for name, digest in recorded.items():
        require(sha256(directory / name) == digest, 'Witnessed source bytes differ: ' + name)
    if harness is not None:
        require(sha256(directory / harness['source_path']) == harness['source_sha256'], 'Witnessed harness bytes differ')
    return source


def resolve_source(args):
    if args.source_witness is not None:
        require(args.repository is None, 'Choose live Git or artifact witness, not both')
        source = artifact_source(args.source_witness, args.witness_sha256)
        return source, {'mode': 'artifact-witness', 'witness_sha256': args.witness_sha256}, args.source_witness
    require(args.repository is not None and args.witness_sha256 is None,
            '--witness-sha256 is only valid with --source-witness')
    return source_identity(args.repository), {'mode': 'live-git'}, args.repository


def make_plan(source, renderer='dx12', repeats=3, warmup=15, seconds=45, smoke=False, pilot=False, source_origin=None,
              static_diagnostics=False, gpu_timestamps=False, baseline_only=False, procedural_baseline=False):
    require(renderer in BACKENDS, 'Only native runtime exports real present-return intervals')
    require(type(gpu_timestamps) is bool, 'gpu_timestamps must be boolean')
    require(not gpu_timestamps or (renderer == 'dx12' and canonical_hash(source['runtime_files_sha256'])
            in (AUDITED_GPU_CANDIDATE_MANIFEST, AUDITED_GPU_CPU_BASELINE_MANIFEST)),
            'GPU timing requires exact reviewed DX12 candidate or four-file baseline source')
    require(type(baseline_only) is bool and not (baseline_only and (smoke or pilot or static_diagnostics)),
            'Baseline-only cannot be combined with another selection')
    require(type(procedural_baseline) is bool and (not procedural_baseline or baseline_only),
            'Procedural baseline requires baseline-only selection')
    require(type(repeats) is int and 1 <= repeats <= 5, 'repeats must be 1..5')
    require(type(warmup) is int and 10 <= warmup <= 60, 'warmup must be 10..60 seconds')
    require(type(seconds) is int and 10 <= seconds <= 120, 'sample must be 10..120 seconds')
    source_origin = {'mode': 'live-git'} if source_origin is None else source_origin
    require(source_origin == {'mode': 'live-git'} or
            (isinstance(source_origin, dict) and set(source_origin) == {'mode', 'witness_sha256'}
             and source_origin['mode'] == 'artifact-witness' and isinstance(source_origin['witness_sha256'], str)
             and re.fullmatch('[0-9a-f]{64}', source_origin['witness_sha256'])), 'Invalid source origin')
    baseline = {'surface_extent': [1920, 1080], 'action': 'stationary',
                'debug_hud': False, 'presentation': 'procedural' if procedural_baseline else 'packaged', 'record': True}
    cases = []
    def add(name, changes, rationale, kind='one_variable'):
        cases.append({'id': name, 'kind': kind, 'settings': {**baseline, **changes},
                      'changed_axes': sorted(changes), 'rationale': rationale})
    add('baseline', {}, '1080p real-game reference, fixed Fifo, Record on.', 'baseline')
    for name, size in [('720p', [1280, 720]), ('1440p', [2560, 1440]), ('4k', [3840, 2160])]:
        add(name, {'surface_extent': size}, 'World/HUD pixel-load diagnostic; fixed 1440x900 viewmodel target.')
    add('ads', {'action': 'ads'}, 'Held RMB with hold controls; ADS changes presentation and world FOV.')
    add('movement', {'action': 'movement'}, 'Repeat W/S every two wall-clock seconds in the default range.')
    add('debug-hud', {'debug_hud': True}, 'Measure added F1 debug panel while ordinary HUD stays enabled.')
    add('procedural', {'presentation': 'procedural'}, 'Existing procedural weapon path reduces presentation complexity; world unchanged.')
    add('1440p-movement', {'surface_extent': [2560, 1440], 'action': 'movement'},
        'Check whether resolution cost changes with moving presentation.', 'interaction')
    add('1440p-debug-hud', {'surface_extent': [2560, 1440], 'debug_hud': True},
        'Check pixel-load interaction with extra debug text.', 'interaction')
    require(type(smoke) is bool, 'smoke must be boolean')
    require(type(pilot) is bool and not (smoke and pilot), 'Choose at most one of smoke/pilot')
    require(type(static_diagnostics) is bool and not (static_diagnostics and (smoke or pilot)),
            'Static diagnostics cannot be combined with smoke/pilot')
    if smoke or baseline_only:
        cases = cases[:1]
        if smoke:
            repeats = 1
    elif pilot:
        cases = [case for case in cases if case['id'] in ('baseline', '720p', '1440p', 'ads')]
        repeats = 1
    elif static_diagnostics:
        cases = [case for case in cases if case['id'] in ('baseline', '4k', 'debug-hud', 'procedural')]
        repeats = 1
        next(case for case in cases if case['id'] == 'debug-hud')['rationale'] = (
            'Existing F1 debug-panel command trial; current telemetry does not independently observe HUD state.')
    order = []
    varied = [case['id'] for case in cases[1:]]
    for repeat in range(repeats):
        # Rotate the finite order; baseline brackets diagnose clock/thermal drift.
        rotated = varied[repeat:] + varied[:repeat]
        for index, name in enumerate(['baseline'] if smoke or baseline_only else ['baseline', *rotated, 'baseline']):
            order.append({'run_id': f'r{repeat + 1:02d}-{index + 1:02d}-{name}',
                          'repeat': repeat + 1, 'case_id': name})
    unavailable = dict(UNAVAILABLE)
    if canonical_hash(source['runtime_files_sha256']) in (AUDITED_PRESENT_CANDIDATE_MANIFEST, AUDITED_GPU_INITIAL_MANIFEST, AUDITED_GPU_CANDIDATE_MANIFEST, AUDITED_GPU_CPU_BASELINE_MANIFEST):
        unavailable['vsync_choices'] = 'The runtime has an opt-in concrete present-mode selector; this matrix fixes Fifo and does not compare other modes.'
    if canonical_hash(source['runtime_files_sha256']) in (AUDITED_GPU_INITIAL_MANIFEST, AUDITED_GPU_CANDIDATE_MANIFEST, AUDITED_GPU_CPU_BASELINE_MANIFEST):
        unavailable['gpu_frame_duration'] = 'The runtime has opt-in GPU timestamp sidecars; this matrix leaves them disabled and does not compare GPU spans.'
    result = {'schema': PLAN_SCHEMA, 'source': source, 'source_origin': source_origin, 'renderer': renderer,
            'repeats': repeats, 'warmup_seconds': warmup, 'sample_seconds': seconds, 'smoke': smoke, 'pilot': pilot,
            'cases': cases, 'order': order, 'unavailable_axes': unavailable,
            'fixed_runtime': {'present_mode': 'Fifo', 'application_fps_cap': None,
                              'native_sample_count': 1, 'viewmodel_extent': [1440, 900],
                              'reference_viewport': False, 'scene': 'vector_range_default_range',
                              'profile': 'm4a1', 'weapon_id': 'hk416a5',
                              'validation': 'unchanged', 'timed_png_readbacks': 0},
            'goal': {'surface_extent': [1920, 1080], 'present_hz': 60,
                     'requested_gpu': 'RTX 3080 Ti', 'acceptance_proven': False},
            'entrypoint_scope': ('Experimental Linux native-GL harness importing unchanged production application. Not the shipped legacy-GL entrypoint or RTX evidence.'
                                 if renderer == 'gl-harness' else 'Packaged production game native-runtime entrypoint.'),
            'execution': 'Sequential fresh processes on one dedicated desktop. Never concurrent game instances.'}
    if static_diagnostics:
        # Keep historical plans byte/schema-compatible. Only the new selection
        # carries this optional discriminator and its narrower evidence scope.
        result['static_diagnostics'] = True
        result['unavailable_axes'] = {**unavailable,
            'evolving_ads_movement': 'Unproven by this static selection. Prior WARP ADS remained at ADS=0 with no simulation-time progression; movement/ADS require a host where simulation advances.'}
    if baseline_only:
        result['baseline_only'] = True
    if procedural_baseline:
        result['procedural_baseline'] = True
    if gpu_timestamps:
        result['gpu_timestamps'] = True
        result['fixed_runtime']['gpu_timestamps'] = True
        result['unavailable_axes']['gpu_frame_duration'] = (
            'Opt-in timestamp spans cover the main ordered command buffer only; full GPU frame time, '
            'present/scan-out and other submissions remain unavailable.')
    return result


def validate_plan(plan):
    expected = make_plan(plan['source'], plan['renderer'], plan['repeats'],
                         plan['warmup_seconds'], plan['sample_seconds'], plan['smoke'], plan['pilot'], plan['source_origin'],
                         plan.get('static_diagnostics', False), plan.get('gpu_timestamps', False),
                         plan.get('baseline_only', False), plan.get('procedural_baseline', False))
    require(plan == expected, 'Plan changed or contains unsupported settings; regenerate it')


def package_identity(executable, source, renderer=None):
    executable = Path(executable)
    build = json_read(executable.parent / 'BUILD_IDENTITY.json', 16 * 1024)
    require(build.get('schema') == 'rust-duty-build-identity/v1', 'Missing packaged build schema')
    require(build.get('source', {}).get('commit') == source['commit'], 'Package and plan source commits differ')
    digest = sha256(executable)
    require(build.get('executable', {}).get('sha256') == digest, 'Packaged executable digest mismatch')
    files = {}
    for directory in ('assets', 'ui'):
        root = executable.parent / directory
        if root.exists():
            require(root.is_dir() and not root.is_symlink(), 'Unsafe package directory')
            for path in sorted(root.rglob('*')):
                require(not path.is_symlink(), 'Package symlink not supported')
                if path.is_file():
                    files[path.relative_to(executable.parent).as_posix()] = sha256(path)
    require('ui/theme.css' in files, 'Package needs its shipped ui/theme.css')
    result = {'build': build, 'executable_sha256': digest,
              'adjacent_files_sha256': files, 'adjacent_files_digest': canonical_hash(files)}
    entry = build.get('benchmark_entrypoint')
    if renderer == 'gl-harness':
        require(isinstance(entry, dict) and entry.get('kind') == 'linux_native_gl_actual_game_harness'
                and entry.get('source_path') == 'examples/linux_actual_game_gl.rs'
                and entry.get('receipt_file') == 'ACTUAL_GAME_HARNESS_RECEIPT.json', 'Missing isolated native-GL harness identity')
        receipt_path = executable.parent / entry['receipt_file']
        require(sha256(receipt_path) == entry.get('receipt_sha256'), 'Harness receipt hash differs')
        harness = json_read(receipt_path)
        require(harness.get('executable_sha256') == digest, 'Harness receipt executable differs')
        result['harness_receipt'] = harness
    else:
        require(entry is None, 'Harness cannot be presented as a production game entrypoint')
    return result


def validate_graphics(value, renderer):
    require(value.get('schema') == 'rust-duty-graphics-device/v1', 'Invalid graphics preference schema')
    adapter = value.get('adapter')
    require(isinstance(adapter, dict), 'Hardware tests require an exact selected GPU, not Auto')
    require(set(adapter) == {'backend', 'name', 'vendor_id', 'device_id', 'device_type'},
            'GPU fingerprint fields differ')
    require(adapter['backend'] == ('gl' if renderer == 'gl-harness' else renderer), 'Selected GPU backend differs from requested renderer')
    for name in ('name', 'device_type'):
        require(isinstance(adapter[name], str) and adapter[name] and
                not any(ord(c) < 32 for c in adapter[name]), 'Invalid GPU fingerprint ' + name)
    for name in ('vendor_id', 'device_id'):
        require(type(adapter[name]) is int and 0 <= adapter[name] < 2**32, 'Invalid GPU identifier')
    require(adapter['device_type'] != 'Cpu', 'CPU adapters require explicit forced-fallback mode')
    return adapter


@contextlib.contextmanager
def desktop_lock(path):
    # Shared across output folders/backends. A stale lock is never auto-deleted.
    path = Path(path)
    write_json(path, {'pid': os.getpid(), 'purpose': 'exclusive real-game performance desktop'})
    try:
        yield
    finally:
        path.unlink()


def case_command(executable, renderer, folder, case, fallback, *, gpu_timestamps=False):
    command = [str(executable), '--no-update', '--hold-controls', '--renderer=' + ('gl' if renderer == 'gl-harness' else renderer),
               '--settings=' + str(folder / 'settings.cfg'),
               '--graphics-settings=' + str(folder / 'graphics-device.json'),
               '--ui-theme=' + str(executable.parent / 'ui/theme.css'), '--weapon-id=hk416a5']
    if renderer == 'gl-harness':
        require(not fallback, 'Native-GL harness does not support forced fallback')
        command.append('--graphics-device=auto')
    if fallback:
        command.append('--force-fallback-adapter')
    if case['settings']['presentation'] == 'procedural':
        command.append('--procedural-weapon')
    require(type(gpu_timestamps) is bool and (not gpu_timestamps or renderer == 'dx12'),
            'GPU timing command requires explicit DX12 opt-in')
    if gpu_timestamps:
        command.append('--gpu-timestamps')
    return command


def sole_session(folder, complete=False, *, gpu_timestamps=False):
    root = folder / 'telemetry-sessions'
    sessions = list(root.iterdir()) if root.is_dir() else []
    require(len(sessions) <= 1, 'More than one Record session in a fresh process')
    if not sessions:
        return None
    session = sessions[0]
    require(session.is_dir() and not session.is_symlink(), 'Invalid session directory')
    if complete:
        for name in ('frames.json', 'IDENTITY.json', 'CSV_STATUS.json', 'GPU_STATUS.json'):
            if not (session / name).is_file():
                return None
        # A created file can still be being written. Wait for complete JSON before
        # closing the process; semantic validity is checked by analyze_run.
        try:
            for name in ('CSV_STATUS.json', 'GPU_STATUS.json'):
                json_read(session / name)
            frames.read_report(session / 'frames.json')
            if gpu_timestamps:
                for name in ('frames.cpu-substages.json', 'frames.gpu-timing.json'):
                    cpu_substages.read_json(session / name)
        except (OSError, ValueError):
            return None
    return session


def cleanup_owned_process(process):
    """Verify exit using only the Popen handle; never search for or kill a PID."""
    result = {'process_id': process.pid, 'process_exit_verified': False,
              'termination_requested': False, 'kill_requested': False}
    try:
        code = process.poll()
        if code is None:
            result['termination_requested'] = True
            process.terminate()
            try:
                code = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                result['kill_requested'] = True
                process.kill()
                code = process.wait(timeout=5)
        observed = process.poll()
        result.update(returncode=observed,
                      process_exit_verified=type(code) is int and observed == code)
    except (OSError, subprocess.SubprocessError) as error:
        result['error'] = str(error)
    return result


def measurement_file_hashes(session, *, gpu_timestamps=False):
    """Bind every session file consumed by the measurement analyzer."""
    names = ('frames.json', 'IDENTITY.json', 'CSV_STATUS.json', 'gameplay.csv',
             'GPU_STATUS.json', 'GPU_METADATA.json', 'gpu.jsonl')
    if gpu_timestamps:
        names += ('frames.cpu-substages.json', 'frames.gpu-timing.json')
    result = {}
    for name in names:
        path = session / name
        require(path.is_file() and not path.is_symlink(), 'Unsafe or missing measurement file: ' + name)
        result[name] = sha256(path)
    return result


def summarize_diagnostics(frames_path, cpu_path, gpu_path):
    """Use the existing exact-primary readers; retain missing GPU subset statuses."""
    report, digest = cpu_substages.read_json(frames_path)
    cpu, _ = cpu_substages.read_json(cpu_path)
    gpu, _ = cpu_substages.read_json(gpu_path)
    cpu_summary = cpu_substages.summarize(cpu, report, digest)
    gpu_summary = gpu_timing.summarize(gpu, report, digest)
    require(report['status']['state'] == 'complete' and cpu_summary['diagnostic_status'] == 'complete'
            and gpu_summary['state'] == 'complete', 'Incomplete CPU/GPU diagnostic accounting')
    return {'cpu_substages': cpu_summary, 'gpu_timing': gpu_summary,
            'gpu_timing_readiness': {'ready': gpu_summary['measured_eligible_count'] >= 100,
                                     'required_measured_eligible_samples': 100}}


def run_case(plan, item, case, executable, output, settings, graphics, fallback, driver_name,
             *, manifest=None, continue_after_exit_timeout=False):
    require(not continue_after_exit_timeout or manifest is not None,
            'Exit-timeout continuation requires the bound execution manifest')
    folder = output / item['run_id']
    folder.mkdir()
    write_bytes_exclusive(folder / 'settings.cfg', settings)
    write_json(folder / 'graphics-device.json', graphics)
    gpu_enabled = plan.get('gpu_timestamps', False)
    command = case_command(executable, plan['renderer'], folder, case, fallback, gpu_timestamps=gpu_enabled)
    started = time.time_ns()
    receipt = {'schema': 'rust-duty-matrix-run/v1', 'run': item, 'case': case,
               'command': command, 'driver': driver_name, 'started_unix_ns': started,
               'settings_before_sha256': sha256(folder / 'settings.cfg'),
               'graphics_before_sha256': sha256(folder / 'graphics-device.json'),
               'completed': False, 'graceful_shutdown': False}
    if gpu_enabled:
        receipt['working_directory'] = str(folder)
    write_json(folder / 'START.json', receipt)
    driver = create_driver(driver_name)
    env = dict(os.environ)
    if driver_name == 'x11':
        env['WINIT_UNIX_BACKEND'] = 'x11'
    process = None
    recovered_timeout = False
    try:
        with (folder / 'game.log').open('xb') as log:
            process = subprocess.Popen(command, cwd=folder, env=env, stdout=log, stderr=subprocess.STDOUT)
            receipt['process_id'] = process.pid
            driver.bind(process.pid)
            size = case['settings']['surface_extent']
            driver.configure(size)
            # Asset loading is outside measurement. Repeated Enter only resumes;
            # it does not pause already active gameplay (SessionController).
            for _ in range(3):
                time.sleep(1)
                driver.check(size)
                tap(driver, 'Return')
            tap(driver, 'F2')
            if case['settings']['debug_hud']:
                tap(driver, 'F1')
                receipt['debug_hud_command'] = {'key': 'F1', 'issued': True, 'actual_state_verified': False}
            replay(driver, process, size, 'stationary', plan['warmup_seconds'])
            if case['settings']['action'] == 'ads':
                driver.aim(True)
                time.sleep(1)  # Settle ADS before starting the recorder.
            driver.check(size)
            tap(driver, 'F8')
            wait_until(lambda: sole_session(folder), timeout=10, label='Record session creation')
            receipt['replay'] = replay(driver, process, size, case['settings']['action'], plan['sample_seconds'])
            driver.check(size)
            tap(driver, 'F8')
            session = wait_until(lambda: sole_session(folder, complete=True, gpu_timestamps=gpu_enabled), timeout=30,
                                 label='frame, CSV and GPU export completion')
            receipt['session'] = session.name
            if manifest is not None:
                before_validation = measurement_file_hashes(session, gpu_timestamps=gpu_enabled)
                # Validate actual exports before exit. The finished timestamp is
                # provisional here; the persisted receipt includes cleanup time.
                provisional = {**receipt, 'finished_unix_ns': time.time_ns(),
                               'settings_after_sha256': sha256(folder / 'settings.cfg'),
                               'graphics_after_sha256': sha256(folder / 'graphics-device.json')}
                observed = analyze_measurements(folder, manifest, provisional)
                require(measurement_file_hashes(session, gpu_timestamps=gpu_enabled) == before_validation,
                        'Measurement exports changed during pre-exit validation')
                receipt['measurement_files_before_exit'] = before_validation
                receipt['measurement_validated_before_exit'] = True
                receipt['measurement_tail_ready_before_exit'] = observed['sample_quality']['tail_comparison_ready']
            driver.check(size)
            receipt['exit_request'] = 'application_f10'
            receipt['exit_wait_timeout_seconds'] = 15
            if driver_name == 'win32':
                receipt['exit_diagnostics'] = {
                    'schema': 'rust-duty-process-exit-diagnostics/v1',
                    'before_request': exit_snapshot(driver, process)}
            driver.close()
            try:
                receipt['returncode'] = process.wait(timeout=15)
            except subprocess.TimeoutExpired as error:
                receipt['normal_exit_timed_out'] = True
                receipt['error'] = str(error)
                if driver_name == 'win32':
                    receipt['exit_diagnostics']['after_timeout'] = exit_snapshot(
                        driver, process, probe_responsiveness=True)
                if not (continue_after_exit_timeout and receipt.get('measurement_validated_before_exit')
                        and receipt.get('measurement_tail_ready_before_exit')):
                    raise
                recovered_timeout = True
            if not recovered_timeout:
                require(receipt['returncode'] == 0, 'Game exited unsuccessfully')
                receipt['graceful_shutdown'] = True
                receipt['completed'] = True
    except (OSError, ValueError, DriverError, subprocess.SubprocessError) as error:
        receipt['error'] = str(error)
        raise
    finally:
        receipt['input_cleanup_errors'] = driver.release_inputs()
        if receipt['input_cleanup_errors']:
            receipt['completed'] = False
        if process is not None:
            receipt['cleanup'] = cleanup_owned_process(process)
            if not receipt['cleanup']['process_exit_verified']:
                receipt['completed'] = False
        if recovered_timeout and receipt.get('cleanup', {}).get('process_exit_verified') and not receipt['input_cleanup_errors']:
            receipt['outcome'] = 'measurements_valid_shutdown_failed'
        else:
            receipt['outcome'] = 'complete' if receipt['completed'] else 'incomplete'
        receipt['finished_unix_ns'] = time.time_ns()
        receipt['settings_after_sha256'] = sha256(folder / 'settings.cfg')
        receipt['graphics_after_sha256'] = sha256(folder / 'graphics-device.json')
        write_json(folder / 'RESULT.json', receipt)
    require(receipt['settings_before_sha256'] == receipt['settings_after_sha256'], 'Gameplay settings changed during run')
    require(receipt['graphics_before_sha256'] == receipt['graphics_after_sha256'], 'GPU selection changed during run')
    require(not receipt['input_cleanup_errors'], 'Injected input cleanup failed; inspect the dedicated desktop')
    require(receipt.get('cleanup', {}).get('process_exit_verified') is True,
            'Owned game process cleanup was not verified; no further case may start')
    return receipt


def run_matrix(args):
    require(args.execute, 'Execution requires --execute; prepare/analyze do not launch anything')
    plan = json_read(args.plan)
    validate_plan(plan)
    source, origin, source_root = resolve_source(args)
    require(source == plan['source'] and origin == plan['source_origin'], 'Plan source identity/origin changed')
    executable = args.executable.resolve()
    package = package_identity(executable, plan['source'], plan['renderer'])
    if plan['renderer'] == 'gl-harness':
        require(args.driver == 'x11' and not args.force_fallback, 'Native-GL harness requires x11 and exact hardware')
        entry = package['build']['benchmark_entrypoint']
        require(sha256(source_root / entry['source_path']) == entry.get('source_sha256'), 'Harness source hash differs')
    settings = args.settings.read_bytes()
    require(0 < len(settings) <= 64 * 1024, 'Settings file must be 1..65536 bytes')
    if args.force_fallback:
        require(args.graphics_settings is None, 'Do not combine explicit GPU selection and forced fallback')
        graphics = {'schema': 'rust-duty-graphics-device/v1', 'adapter': None}
    else:
        require(args.graphics_settings is not None, 'Supply the exact selected GPU preference, or --force-fallback')
        graphics = json_read(args.graphics_settings, 16 * 1024)
        validate_graphics(graphics, plan['renderer'])
    # Driver preflight before creating output or acquiring the desktop.
    create_driver(args.driver)
    output = args.output.absolute()
    output.mkdir()
    manifest = {'schema': 'rust-duty-matrix-execution/v1', 'plan': plan, 'package': package,
                'continue_after_exit_timeout': getattr(args, 'continue_after_exit_timeout', False),
                'source_origin': origin,
                'settings_sha256': hashlib.sha256(settings).hexdigest(),
                'graphics': graphics, 'force_fallback': args.force_fallback,
                'host_observed': {'system': platform.system(), 'release': platform.release(),
                                  'machine': platform.machine(), 'processor': platform.processor()},
                'operator_hardware': json_read(args.hardware) if args.hardware else None,
                'hardware_identity_scope': 'Runtime adapter fingerprint is observed; CPU/display details are operator claims when supplied.'}
    if plan.get('gpu_timestamps'):
        manifest['executable_path'] = str(executable)
    write_json(output / 'MANIFEST.json', manifest)
    with desktop_lock(args.lock_file):
        cases = {case['id']: case for case in plan['cases']}
        for item in plan['order']:
            print('Running ' + item['run_id'], flush=True)
            run_case(plan, item, cases[item['case_id']], executable, output, settings,
                     graphics, args.force_fallback, args.driver, manifest=manifest,
                     continue_after_exit_timeout=manifest['continue_after_exit_timeout'])
            # Fail on a bad capture before spending a full matrix on invalid setup.
            analyzed = analyze_run(output / item['run_id'], manifest,
                                   allow_forced_cleanup=manifest['continue_after_exit_timeout'])
            if plan.get('gpu_timestamps'):
                require(analyzed['gpu_timing_readiness']['ready'],
                        'GPU measured subset is unavailable or has fewer than 100 eligible samples')
        require(package_identity(executable, plan['source'], plan['renderer']) == package, 'Package changed during matrix')
        after_source, after_origin, _ = resolve_source(args)
        require((after_source, after_origin) == (source, origin), 'Source witness changed during matrix')
    write_json(output / 'SUMMARY.json', analyze_matrix(output))
    return output


def compare_builds(args):
    """Eight fresh single-condition runs, reusing the established desktop runner."""
    require(args.execute, 'Execution requires --execute')
    require(args.driver == 'win32', 'The CPU/GPU comparison requires Windows DX12')
    import run_cpu_image_preservation as pair
    labels = ('baseline', 'candidate')
    sources, packages, variants, builds, build_hashes = {}, {}, {}, {}, {}
    for label, expected in zip(labels, (AUDITED_GPU_CPU_BASELINE_MANIFEST, AUDITED_GPU_CANDIDATE_MANIFEST)):
        witness = Path(getattr(args, label + '_source_witness'))
        witness_sha = getattr(args, label + '_witness_sha256')
        source = artifact_source(witness, witness_sha)
        require(canonical_hash(source['runtime_files_sha256']) == expected,
                'Comparison source is not the exact reviewed ' + label)
        executable = Path(getattr(args, label + '_executable')).resolve()
        sources[label] = source
        packages[label] = package_identity(executable, source, 'dx12')
        variants[label] = (witness, witness_sha, executable)
        receipt_path = Path(getattr(args, label + '_build_receipt'))
        builds[label] = json_read(receipt_path)
        build_hashes[label] = sha256(receipt_path)
        build = builds[label]
        require(build.get('schema') == 'rust-duty-performance-release-build/v1'
                and build.get('source_commit') == source['commit']
                and build.get('executable_sha256') == packages[label]['executable_sha256']
                and build.get('command') == ['cargo', 'build', '--locked', '--release', '--no-default-features',
                                             '--features', 'wgpu-runtime', '--bin', 'vector-range']
                and build.get('build_settings') == {'CARGO_INCREMENTAL': '0', 'CARGO_BUILD_JOBS': '2',
                                                     'CARGO_PROFILE_RELEASE_DEBUG': '0'}
                and build.get('build_result') == {'exit_code': 0},
                'Comparison requires source/executable-bound fixed release build receipt')
        require(all(build.get('production_files_sha256', {}).get(name) == digest
                    for name, digest in source['runtime_files_sha256'].items()),
                'Release receipt runtime bytes differ from the source witness')
    require(canonical_hash(builds['candidate']['production_files_sha256']) == AUDITED_GPU_PRODUCTION_MANIFEST
            and builds['baseline']['production_files_sha256'] ==
                {**builds['candidate']['production_files_sha256'], **pair.CPU_BASELINE},
            'Release pair differs from the closed reviewed production compile inventories')
    compiler = builds['candidate'].get('toolchain', {})
    require(set(compiler) == {'rustc', 'cargo'} and builds['baseline'].get('toolchain') == compiler
            and 'release: 1.99.0\n' in compiler['rustc']
            and 'host: x86_64-pc-windows-msvc\n' in compiler['rustc']
            and compiler['cargo'].startswith('cargo 1.99.0 '),
            'Release pair compiler identities differ from the reviewed Windows toolchain')
    require(sources['baseline']['commit'] != sources['candidate']['commit'],
            'Counterfactual and candidate must retain distinct real source commits')
    require(all(builds[label].get('ci_run_source_commit') == sources['candidate']['commit']
                for label in labels), 'Release receipts belong to a different candidate CI source')
    identities = {}
    for label in labels:
        identity = packages[label].get('build', {})
        require(identity.get('repository') == 'RHS059/rust_duty'
                and identity.get('target') == 'x86_64-pc-windows-msvc'
                and identity.get('source', {}).get('workflow') == '.github/workflows/build.yml',
                'Comparison package lacks the real reviewed build identity')
        identities[label] = {**{key: value for key, value in identity.items() if key != 'executable'},
                             'source': {key: value for key, value in identity['source'].items() if key != 'commit'}}
    require(identities['baseline'] == identities['candidate'],
            'Comparison package labels or CI run identities differ')
    delta = {name for name in sources['candidate']['runtime_files_sha256']
             if sources['baseline']['runtime_files_sha256'][name] != sources['candidate']['runtime_files_sha256'][name]}
    require(delta == set(CPU_SOURCE_PATHS), 'Comparison differs outside the exact four CPU paths')
    require(packages['baseline']['adjacent_files_sha256'] == packages['candidate']['adjacent_files_sha256'],
            'Comparison packages have different adjacent assets or UI bytes')
    settings_sha = sha256(args.settings)
    if args.force_fallback:
        require(args.graphics_settings is None, 'Do not mix fallback and explicit GPU selection')
        graphics = {'schema': 'rust-duty-graphics-device/v1', 'adapter': None}
    else:
        require(args.graphics_settings is not None, 'Comparison requires exact GPU selection')
        graphics = json_read(args.graphics_settings)
        validate_graphics(graphics, 'dx12')
    output = Path(args.output).absolute()
    require(not output.exists() and not output.is_symlink(), 'Refusing stale comparison output')
    plans = {label: make_plan(sources[label], 'dx12', repeats=1, warmup=args.warmup_seconds,
                             seconds=args.sample_seconds, source_origin={'mode': 'artifact-witness',
                             'witness_sha256': variants[label][1]}, baseline_only=True, gpu_timestamps=True,
                             procedural_baseline=args.procedural_baseline) for label in labels}
    output.mkdir(parents=True)
    order = ['baseline', 'candidate', 'candidate', 'baseline'] * 2
    inputs = {'schema': 'rust-duty-cpu-gpu-comparison/v1', 'sources': sources, 'packages': packages,
              'settings_sha256': settings_sha, 'order': order, 'cpu_delta_paths': sorted(delta),
              'force_fallback': args.force_fallback, 'driver': args.driver, 'graphics': graphics,
              'build_receipts': builds, 'build_receipts_sha256': build_hashes,
              'scope': 'Repeated same-host source comparison; no automatic FPS or performance-improvement verdict'}
    write_json(output / 'COMPARE_INPUTS.json', inputs)
    for label, plan in plans.items():
        write_json(output / (label + '-plan.json'), plan)
    retained = {output / 'COMPARE_INPUTS.json': sha256(output / 'COMPARE_INPUTS.json'),
                **{output / (label + '-plan.json'): sha256(output / (label + '-plan.json')) for label in labels}}
    results, run_files = [], {}
    try:
        # Child calls retain their usual lock/cleanup behavior. The outer common
        # desktop lock stays held across the whole pair, including between runs.
        with desktop_lock(args.lock_file):
            for ordinal, label in enumerate(order, 1):
                witness, witness_sha, executable = variants[label]
                child = SimpleNamespace(execute=True, plan=output / (label + '-plan.json'),
                    repository=None, source_witness=witness, witness_sha256=witness_sha,
                    executable=executable, settings=Path(args.settings), graphics_settings=args.graphics_settings,
                    force_fallback=args.force_fallback, hardware=args.hardware, driver=args.driver,
                    output=output / f'r{ordinal:02d}-{label}', lock_file=output / 'owned-child-desktop.lock',
                    continue_after_exit_timeout=False)
                run_matrix(child)
                summary = analyze_matrix(child.output)
                require(summary['state'] == 'complete' and summary['measurement_readiness']['ready']
                        and len(summary['runs']) == 1, 'Comparison run is incomplete or undersampled')
                child_manifest = json_read(child.output / 'MANIFEST.json')
                require(child_manifest['settings_sha256'] == settings_sha and child_manifest['graphics'] == graphics,
                        'Comparison settings or GPU selection changed between runs')
                require(child_manifest['package'] == packages[label] and child_manifest['plan'] == plans[label],
                        'Comparison child package or plan differs from initial pinned inputs')
                row = summary['runs'][0]
                if results:
                    first = results[0]['measurement']['runtime_observed']
                    actual = row['runtime_observed']
                    require(actual['actual_adapter'] == first['actual_adapter']
                            and actual['initial_window'] == first['initial_window']
                            and actual['scene'] == first['scene'],
                            'Adapter, display extent/DPI/mode or scene changed across the source pair')
                    require(results[-1]['measurement']['finished_unix_ns'] <= row['started_unix_ns'],
                            'Comparison game processes overlap')
                results.append({'ordinal': ordinal, 'variant': label, 'folder': child.output.name,
                                'measurement': row})
                run_files[child.output] = pair.controls.source_manifest(child.output)
            for label, (witness, witness_sha, executable) in variants.items():
                require(artifact_source(witness, witness_sha) == sources[label]
                        and package_identity(executable, sources[label], 'dx12') == packages[label],
                        'Comparison package/source changed during execution')
            require(sha256(args.settings) == settings_sha, 'Comparison settings changed')
            for label in labels:
                require(sha256(getattr(args, label + '_build_receipt')) == build_hashes[label],
                        'Comparison build receipt changed')
            require(all(sha256(path) == digest for path, digest in retained.items()),
                    'Comparison input receipt or plan changed')
            for row in results:
                folder = output / row['folder']
                require(pair.controls.source_manifest(folder) == run_files[folder],
                        'Earlier comparison evidence changed after its accepted run')
                replayed = analyze_matrix(folder)
                require(replayed['state'] == 'complete' and replayed['measurement_readiness']['ready']
                        and replayed['runs'] == [row['measurement']],
                        'Retained comparison measurement no longer replays')
                require(pair.controls.source_manifest(folder) == run_files[folder],
                        'Comparison evidence changed during final replay')
        result = {**inputs, 'state': 'complete', 'runs': results, 'performance_improvement': None,
                  'target_1080p60_proven': False,
                  'statistics_scope': 'Per-run nearest-rank distributions and measured GPU subsets; never pooled'}
        write_json(output / 'COMPARE_SUMMARY.json', result)
        return result
    except (OSError, ValueError, KeyError, TypeError, DriverError, subprocess.SubprocessError) as error:
        write_json(output / 'COMPARE_FAILURE.json', {'state': 'incomplete', 'error': str(error),
                                                    'completed_runs': len(results)})
        raise


def gameplay_summary(path):
    require(path.is_file() and not path.is_symlink(), 'Missing gameplay.csv')
    speeds, ads, positions, times = [], [], [], []
    with path.open(encoding='utf-8', newline='') as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == 'time,x,y,z,speed,grounded,crouched,sprinting,ads,recoil_pitch_deg,ammo,shots,hits,kills,render_fps'.split(','),
                'Gameplay CSV header mismatch')
        for index, row in enumerate(reader):
            require(index < 250000 and None not in row and all(value is not None for value in row.values()), 'Malformed or oversized gameplay CSV')
            values = [float(row[key]) for key in ('speed', 'ads', 'x', 'y', 'z', 'time')]
            require(all(math.isfinite(value) for value in values), 'Nonfinite gameplay observation')
            require(values[5] >= 0 and (not times or values[5] >= times[-1]),
                    'Simulation time is negative or regresses within the recording')
            speeds.append(values[0]); ads.append(values[1]); positions.append(values[2:5]); times.append(values[5])
    require(speeds, 'No gameplay rows; startup/menu capture is not a game test')
    advancing = sum(right > left for left, right in zip(times, times[1:]))
    pairs = len(times) - 1
    progression = ('unavailable_single_row' if not pairs else 'stalled' if not advancing
                   else 'advancing' if advancing == pairs else 'intermittent_progress')
    return {'rows': len(speeds), 'speed_min': min(speeds), 'speed_max': max(speeds),
            'moving_fraction': sum(value > 0.1 for value in speeds) / len(speeds),
            'ads_min': min(ads), 'ads_max': max(ads),
            'aimed_fraction': sum(value >= 0.99 for value in ads) / len(ads),
            'first_position': positions[0], 'last_position': positions[-1],
            'simulation_time': {'first_seconds': times[0], 'last_seconds': times[-1],
                                'span_seconds': times[-1] - times[0], 'csv_pair_count': pairs,
                                'advancing_pairs': advancing, 'unchanged_pairs': pairs - advancing,
                                'advancing_pair_fraction': advancing / pairs if pairs else None,
                                'progression': progression,
                                'scope': 'Actual simulation time from CSV rounded to four decimals; not wall-clock or render FPS.'},
            'render_fps_column_used_for_timing': False}


def gpu_export_summary(session):
    status = json_read(session / 'GPU_STATUS.json')
    require(status.get('schema') == 'rust-duty-gpu-status/v1'
            and status.get('state') == 'stopped' and status.get('error') is None
            and status.get('gpu_frame_duration_available') is False,
            'GPU counter export is incomplete or has invalid timing/status metadata')
    written, available = status.get('samples_written'), status.get('samples_with_game_process_utilization')
    require(type(written) is int and type(available) is int and 0 <= available <= written <= 86400,
            'Invalid GPU counter sample counts')
    metadata = json_read(session / 'GPU_METADATA.json')
    duration = metadata.get('gpu_frame_duration_ms', {})
    require(metadata.get('schema') == 'rust-duty-gpu-telemetry/v1' and
            isinstance(duration, dict) and duration.get('value') is None and bool(duration.get('unavailable_reason')),
            'GPU duration must retain its explicit unavailable reason')
    path = session / 'gpu.jsonl'
    require(path.is_file() and not path.is_symlink(), 'Missing GPU counter stream')
    count = observed_available = byte_count = 0
    previous_end = 0
    with path.open('rb') as stream:
        while raw := stream.readline(2 * 1024 * 1024 + 1):
            byte_count += len(raw)
            require(len(raw) <= 2 * 1024 * 1024 and byte_count <= 64 * 1024 * 1024 and count < 86400,
                    'GPU counter stream exceeds matrix bounds')
            row = json.loads(raw, object_pairs_hook=frames._unique, parse_constant=frames._constant)
            frames._finite_tree(row)
            require(isinstance(row, dict), 'GPU counter sample must be an object')
            start, end = row.get('sample_started_ms'), row.get('sample_finished_ms')
            require(type(start) in (int, float) and type(end) in (int, float)
                    and previous_end <= start <= end and row.get('sample') == count,
                    'Invalid GPU counter timeline')
            previous_end = end
            data = row.get('data')
            require(isinstance(data, dict) and isinstance(data.get('adapters'), list), 'Invalid GPU counter data')
            require(all(isinstance(adapter, dict) and isinstance(adapter.get('process_busiest_engine_pct'), dict)
                        for adapter in data['adapters']), 'Malformed GPU counter adapter metric')
            observed_available += any(type(adapter.get('process_busiest_engine_pct', {}).get('value')) in (int, float)
                                      for adapter in data['adapters'])
            count += 1
    require(count == written and observed_available == available, 'GPU counter stream/status counts differ')
    return {'status': status, 'metadata': metadata, 'gpu_jsonl_sha256': sha256(path),
            'metric_scope': 'OS occupancy/memory counters, never GPU frame duration'}


def analyze_run(folder, manifest, *, allow_forced_cleanup=False):
    receipt = json_read(folder / 'RESULT.json')
    cleanup = receipt.get('cleanup', {})
    verified_cleanup = (cleanup.get('process_exit_verified') is True
                        and type(receipt.get('process_id')) is int and receipt['process_id'] > 0
                        and cleanup.get('process_id') == receipt['process_id']
                        and type(cleanup.get('returncode')) is int and not cleanup.get('error'))
    graceful = (receipt.get('completed') is True and receipt.get('returncode') == 0
                and receipt.get('graceful_shutdown', True) is True
                and not receipt.get('normal_exit_timed_out', False)
                and not receipt.get('input_cleanup_errors')
                and ('cleanup' not in receipt or (verified_cleanup and cleanup['returncode'] == 0)))
    recovered = (manifest.get('continue_after_exit_timeout') is True
                 and receipt.get('outcome') == 'measurements_valid_shutdown_failed'
                 and receipt.get('completed') is False and receipt.get('graceful_shutdown') is False
                 and receipt.get('normal_exit_timed_out') is True
                 and receipt.get('exit_wait_timeout_seconds') == 15
                 and receipt.get('measurement_validated_before_exit') is True
                 and receipt.get('measurement_tail_ready_before_exit') is True
                 and receipt.get('input_cleanup_errors') == []
                 and bool(receipt.get('error'))
                 and verified_cleanup)
    require(graceful or (allow_forced_cleanup and recovered),
            'Run did not complete with its requested case and verified process exit')
    if recovered:
        gpu_enabled = manifest['plan'].get('gpu_timestamps', False)
        session = sole_session(folder, complete=True, gpu_timestamps=gpu_enabled)
        require(session is not None and
                receipt.get('measurement_files_before_exit') == measurement_file_hashes(session, gpu_timestamps=gpu_enabled),
                'Measurement exports changed after pre-exit validation')
    result = analyze_measurements(folder, manifest, receipt)
    require(not recovered or result['sample_quality']['tail_comparison_ready'],
            'Exit-timeout continuation requires at least 100 intervals')
    result.update(graceful_shutdown=graceful, process_exit_verified=True,
                  outcome='complete' if graceful else 'measurements_valid_shutdown_failed',
                  shutdown_error=None if graceful else receipt['error'])
    return result


def analyze_measurements(folder, manifest, receipt):
    """Independently validate exports without interpreting process shutdown."""
    plan = manifest['plan']
    item = next((item for item in plan['order'] if item['run_id'] == folder.name), None)
    require(item is not None and receipt.get('run') == item, 'Unexpected run identity')
    case = next(case for case in plan['cases'] if case['id'] == item['case_id'])
    require(receipt.get('case') == case, 'Run requested case differs from its plan')
    require(type(receipt.get('started_unix_ns')) is int and type(receipt.get('finished_unix_ns')) is int
            and 0 < receipt['started_unix_ns'] < receipt['finished_unix_ns'], 'Invalid run wall-clock bounds')
    require(receipt['settings_before_sha256'] == receipt['settings_after_sha256'] == manifest['settings_sha256'] == sha256(folder / 'settings.cfg'),
            'Settings hash mismatch')
    require(receipt['graphics_before_sha256'] == receipt['graphics_after_sha256'] == sha256(folder / 'graphics-device.json'), 'Graphics preference changed')
    require(json_read(folder / 'graphics-device.json') == manifest['graphics'], 'Graphics preference differs from manifest')
    gpu_enabled = plan.get('gpu_timestamps', False)
    session = sole_session(folder, complete=True, gpu_timestamps=gpu_enabled)
    require(session is not None and session.name == receipt.get('session'), 'Missing or ambiguous completed session')
    report = frames.read_report(session / 'frames.json')
    require(report['status']['state'] == 'complete', 'Incomplete frame trace')
    require(report['ineligible_present_count'] == 0, 'Trace includes ineligible gameplay')
    require(not any(row['kind'] == 'boundary' or row['kind'] == 'window_context' for row in report['records']),
            'Trace contains focus/pause/resize/capture or other segment boundary')
    runtime = report['identity']['runtime_observed']
    require(runtime['actual_backend'] == BACKENDS[plan['renderer']], 'Observed backend differs from request')
    adapter = runtime['actual_adapter']
    require(isinstance(adapter, dict) and adapter.get('gpu_timestamps_requested', False) is gpu_enabled,
            'Runtime timestamp opt-in differs from the plan')
    if gpu_enabled:
        path_type = PureWindowsPath if manifest['host_observed']['system'] == 'Windows' else Path
        original_folder = path_type(receipt['working_directory'])
        require(original_folder.is_absolute() and original_folder.name == item['run_id'],
                'Timestamp command working directory differs from its run')
        expected = case_command(path_type(manifest['executable_path']), plan['renderer'], original_folder, case,
                                manifest['force_fallback'], gpu_timestamps=True)
        require(receipt.get('command') == expected, 'Timestamp command differs from the bound plan/package')
    else:
        require(not ((session / 'frames.gpu-timing.json').exists() or (session / 'frames.gpu-timing.json').is_symlink()),
                'Unexpected GPU sidecar in default-off capture')
    require(isinstance(adapter, dict) and adapter.get('present_mode') == 'Fifo', 'Missing actual Fifo evidence')
    require(adapter.get('force_fallback_requested') is manifest['force_fallback'], 'Fallback evidence differs')
    if manifest['force_fallback']:
        require(adapter.get('device_type') == 'Cpu', 'Forced-fallback experiment did not observe a CPU adapter')
    else:
        wanted = validate_graphics(manifest['graphics'], plan['renderer'])
        require(adapter.get('selection_mode') == 'explicit_fingerprint' and
                adapter.get('actual_fingerprint') == wanted and adapter.get('requested_fingerprint') == wanted,
                'Actual/requested selected GPU fingerprints do not match')
        require(all(adapter.get(key) == wanted[key] for key in ('name', 'vendor_id', 'device_id', 'device_type')),
                'Adapter fields contradict its fingerprint')
    require(all(key in adapter for key in ('name', 'backend', 'device_type', 'vendor_id', 'device_id', 'driver', 'driver_info')),
            'Incomplete runtime device identity')
    require(adapter['backend'] == runtime['actual_backend'], 'Adapter backend contradicts runtime')
    window = runtime['initial_window']
    size = case['settings']['surface_extent']
    require([window['physical_width'], window['physical_height']] == size, 'Observed surface extent differs from requested resolution')
    require(window['mode'] == 'windowed', 'Matrix requires windowed presentation')
    stage = report.get('cpu_frame_stages')
    require(stage is not None, 'CPU-stage extension unavailable on this build')
    require(all([row['physical_width'], row['physical_height']] == size for row in stage['samples']), 'CPU-stage sample extent mismatch')
    scene = runtime['scene']
    require(isinstance(scene, dict) and scene.get('name') == 'vector_range_default_range'
            and scene.get('reference_viewport') is False and scene.get('diagnostic_capture') is False
            and scene.get('demo') is False and scene.get('capture_sequence') is None,
            'Diagnostic/demo scene cannot be used as real gameplay')
    require(scene.get('profile_base') == 'm4a1' and scene.get('weapon_id') == 'hk416a5', 'Gameplay identity mismatch')
    if case['settings']['presentation'] == 'procedural':
        require(scene.get('presentation') == 'procedural', 'Procedural case did not use procedural presentation')
    else:
        require(scene.get('presentation') in ('authored_viewmodel', 'static_weapon_model'), 'Packaged presentation unavailable')
    identity = json_read(session / 'IDENTITY.json')
    require(identity.get('schema') == 'rust-duty-local-playtest-session/v1', 'Invalid session identity')
    require(identity.get('executable_sha256') == manifest['package']['executable_sha256'], 'Recorded executable digest differs')
    require(identity.get('source', {}).get('state') == 'bound_to_executable_hash_and_label'
            and identity['source'].get('commit') == plan['source']['commit'], 'Session source identity is not bound')
    require(identity.get('build') == runtime['build'] and runtime['build'].get('label') == manifest['package']['build']['display_version'], 'Recorded build differs')
    require(identity.get('graphics_device') == adapter, 'Session/frame adapter evidence differs')
    status = json_read(session / 'CSV_STATUS.json')
    require(status.get('state') == 'stopped' and status.get('error') is None, 'Gameplay CSV recording is incomplete')
    values = [row['interval_ns'] for row in report['records']
              if row['kind'] == 'successful_present_return' and row['interval_ns'] is not None]
    require(sum(values) >= plan['sample_seconds'] * 0.90 * 1e9, 'Insufficient retained eligible duration')
    tail_ready = len(values) >= 100
    # A setup smoke establishes input/window/export/exit behavior independently
    # of statistical sufficiency. Pilot/full retain their existing sample gate.
    require(plan['smoke'] or tail_ready, 'Fewer than 100 intervals; tail estimate not useful')
    gameplay = gameplay_summary(session / 'gameplay.csv')
    action = case['settings']['action']
    if action in ('ads', 'movement'):
        require(gameplay['simulation_time']['span_seconds'] > 0,
                'Simulation time did not advance; evolving ADS/movement is unproven')
    require((gameplay['moving_fraction'] > 0.50) if action == 'movement' else (gameplay['speed_max'] < 0.1),
            'Observed movement does not match the input case')
    require((gameplay['aimed_fraction'] > 0.90) if action == 'ads' else (gameplay['ads_max'] < 0.01),
            'Observed ADS does not match the input case')
    if plan.get('static_diagnostics') and case['settings']['debug_hud']:
        require(receipt.get('debug_hud_command') == {'key': 'F1', 'issued': True, 'actual_state_verified': False},
                'Static F1 trial needs its issued-command receipt; HUD state is not observable')
    progression = gameplay['simulation_time']['progression']
    long_intervals = sum(value > 250_000_000 for value in values)
    condition = ('static_scene_with_stalled_simulation' if progression == 'stalled'
                 else 'scene_with_intermittent_simulation' if progression == 'intermittent_progress'
                 else 'scene_with_advancing_simulation' if progression == 'advancing'
                 else 'simulation_progression_unavailable')
    summary = report['summary']
    result = {'run': item, 'settings_requested': case['settings'], 'runtime_observed': runtime,
              'started_unix_ns': receipt['started_unix_ns'], 'finished_unix_ns': receipt['finished_unix_ns'],
              'frame_summary_ns': summary, 'effective_present_hz': len(values) * 1e9 / sum(values),
              'sample_quality': {'purpose': ('setup_smoke' if plan['smoke'] else 'static_render_diagnostics'
                                            if plan.get('static_diagnostics') else 'statistical_matrix'),
                                 'observed_intervals': len(values), 'required_intervals_for_tail_comparison': 100,
                                 'tail_comparison_ready': tail_ready,
                                 'percentile_scope': 'Descriptive retained-sample quantiles; fewer than 100 intervals do not establish a useful tail comparison.'},
              'interval_fraction_over_60hz_budget': sum(value * 60 > 1e9 for value in values) / len(values),
              'interval_fraction_over_two_60hz_budgets': sum(value * 30 > 1e9 for value in values) / len(values),
              'cpu_stages': frames._cpu_stage_summary(stage, report['records']),
              'gameplay_observed': gameplay, 'skipped_frames': report['skipped_frame_count'],
              'simulation_condition': {'classification': condition,
                                       'simulation_seconds_per_present_wall_second': gameplay['simulation_time']['span_seconds'] / (sum(values) / 1e9),
                                       'present_intervals_over_250ms': long_intervals,
                                       'present_interval_fraction_over_250ms': long_intervals / len(values),
                                       'evolving_gameplay_acceptance_proven': False,
                                       'scope': 'CSV progression and retained present intervals have different sampling endpoints. At source49, application dt above250ms discards simulation time; long present intervals are supporting hitch evidence, not direct per-frame dt instrumentation.'},
              'gpu_counter_export': gpu_export_summary(session),
              'gpu_frame_duration_ns': None, 'draw_pass_triangle_counts': None,
              'debug_hud_evidence': {'requested_debug_panel': case['settings']['debug_hud'],
                                     'command_receipt': receipt.get('debug_hud_command'),
                                     'actual_state_verified': False,
                                     'scope': 'An issued F1 command is not proof of actual HUD state; older receipts may omit the command field.'},
              'scope': 'Real-game CPU present-return intervals, not GPU time or display scan-out.',
              'acceptance_proven': False}
    if gpu_enabled:
        result.update(summarize_diagnostics(session / 'frames.json', session / 'frames.cpu-substages.json',
                                            session / 'frames.gpu-timing.json'))
        result['diagnostic_files_sha256'] = {name: sha256(session / name) for name in
                                            ('frames.cpu-substages.json', 'frames.gpu-timing.json')}
    result['trace_sha256'] = sha256(session / 'frames.json')
    return result


def analyze_matrix(output):
    output = Path(output)
    manifest = json_read(output / 'MANIFEST.json')
    require(manifest.get('schema') == 'rust-duty-matrix-execution/v1', 'Invalid matrix execution manifest')
    plan = manifest['plan']
    validate_plan(plan)
    require(manifest.get('source_origin') == plan['source_origin'], 'Execution source origin differs from plan')
    runs, failures, measurement_failures = [], [], []
    for item in plan['order']:
        try:
            run = analyze_run(output / item['run_id'], manifest, allow_forced_cleanup=True)
            runs.append(run)
            if not run['graceful_shutdown']:
                failures.append({'run_id': item['run_id'], 'kind': 'graceful_shutdown',
                                 'error': run['shutdown_error']})
        except (OSError, ValueError, KeyError, TypeError) as error:
            failure = {'run_id': item['run_id'], 'error': str(error)}
            failures.append(failure)
            measurement_failures.append(failure)
    if runs:
        first = runs[0]['runtime_observed']
        require(all(left['finished_unix_ns'] <= right['started_unix_ns'] for left, right in zip(runs, runs[1:])),
                'Overlapping or out-of-order game processes cannot be compared')
        for run in runs:
            actual = run['runtime_observed']
            require(actual['actual_adapter'] == first['actual_adapter'] and actual['build'] == first['build'],
                    'Do not pool different adapters/drivers/builds')
            require(actual['initial_window']['scale_factor'] == first['initial_window']['scale_factor'], 'Display DPI changed between cases')
            if run['settings_requested']['presentation'] == 'packaged':
                require(actual['scene']['presentation'] == first['scene']['presentation'], 'Packaged presentation changed')
    groups = []
    for case in plan['cases']:
        selected = [run for run in runs if run['run']['case_id'] == case['id']]
        groups.append({'case_id': case['id'], 'completed_runs': sum(run['graceful_shutdown'] for run in selected),
                       'measured_runs': len(selected),
                       'p50_ms_by_run': [run['frame_summary_ns']['p50_ns'] / 1e6 for run in selected],
                       'p95_ms_by_run': [run['frame_summary_ns']['p95_ns'] / 1e6 for run in selected],
                       'p99_ms_by_run': [run['frame_summary_ns']['p99_ns'] / 1e6 for run in selected],
                       'median_run_p99_ms': statistics.median(run['frame_summary_ns']['p99_ns'] / 1e6 for run in selected) if selected else None})
    pairs = []
    for repeat in range(1, plan['repeats'] + 1):
        selected = [run for run in runs if run['run']['repeat'] == repeat]
        baselines = [run for run in selected if run['run']['case_id'] == 'baseline']
        if len(baselines) == 2:
            reference = statistics.mean(run['frame_summary_ns']['p99_ns'] for run in baselines)
            for run in selected:
                if run['run']['case_id'] != 'baseline':
                    pairs.append({'run_id': run['run']['run_id'],
                                  'p99_delta_ms_from_bracketing_baseline_mean': (run['frame_summary_ns']['p99_ns'] - reference) / 1e6,
                                  'baseline_p99_drift_ms': (baselines[1]['frame_summary_ns']['p99_ns'] - baselines[0]['frame_summary_ns']['p99_ns']) / 1e6})
    diagnostic_ready = not plan.get('gpu_timestamps') or all(run['gpu_timing_readiness']['ready'] for run in runs)
    pilot_ready = bool(runs) and not failures and diagnostic_ready and all(run['sample_quality']['tail_comparison_ready'] for run in runs)
    measurement_ready = (len(runs) == len(plan['order']) and not measurement_failures and diagnostic_ready
                         and all(run['sample_quality']['tail_comparison_ready'] for run in runs))
    return {'schema': 'rust-duty-real-game-matrix-analysis/v1',
            'state': ('setup_complete' if plan['smoke'] else 'complete') if not failures else 'incomplete',
            'analysis_purpose': ('setup_smoke' if plan['smoke'] else 'static_render_diagnostics'
                                 if plan.get('static_diagnostics') else 'statistical_matrix'),
            'graceful_shutdown': bool(runs) and not failures and all(run['graceful_shutdown'] for run in runs),
            'measurement_readiness': {'ready': measurement_ready, 'required_intervals_per_run': 100,
                                      'all_processes_exited': len(runs) == len(plan['order']) and not measurement_failures,
                                      'scope': 'Valid source/device/exports plus verified process cleanup; does not approve graceful shutdown.'},
            'pilot_sample_readiness': {'ready': pilot_ready, 'required_intervals_per_run': 100,
                                       'reason': None if pilot_ready else 'Setup/exports failed or fewer than 100 retained intervals; do not advance to statistical pilot on this evidence.'},
            'acceptance_proven': False,
            'measurement': frames.MEASUREMENT, 'percentile_method': frames.METHOD,
            'goal': plan['goal'], 'package': manifest['package'],
            'source_origin': manifest['source_origin'],
            'entrypoint_scope': plan['entrypoint_scope'],
            'host_observed': manifest['host_observed'], 'operator_hardware': manifest['operator_hardware'],
            'scope': ('Per-run CPU pacing, CPU spans and separately measured eligible GPU command-buffer subsets. '
                      'No pooled percentiles, display-cadence claim or RTX inference from another adapter.'
                      if plan.get('gpu_timestamps') else
                      'Per-run CPU pacing and CPU spans only. No pooled percentiles, GPU-time estimate, display-cadence claim, or RTX inference from another adapter.'),
            'runs': runs, 'failures': failures, 'case_comparisons': [] if plan['smoke'] else groups,
            'paired_baseline_comparisons': [] if plan['smoke'] else pairs, 'unavailable_axes': plan['unavailable_axes']}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    export = sub.add_parser('export-witness', help='Export exact source bytes verified against a live Git checkout')
    export.add_argument('--repository', type=Path, required=True)
    export.add_argument('--harness', type=Path)
    export.add_argument('--output', type=Path, required=True)
    prepare = sub.add_parser('prepare', help='Write a finite plan; never launch the game')
    prepare.add_argument('--renderer', choices=BACKENDS, default='dx12')
    prepare.add_argument('--repeats', type=int, default=3)
    prepare.add_argument('--warmup-seconds', type=int, default=15)
    prepare.add_argument('--sample-seconds', type=int, default=45)
    prepare.add_argument('--smoke', action='store_true', help='One baseline only; gate the desktop before a full matrix')
    prepare.add_argument('--pilot', action='store_true', help='Baseline,720p,1440p,ADS,baseline before the full matrix')
    prepare.add_argument('--static-diagnostics', action='store_true',
                         help='Remaining static cases: baseline,4K,F1 command,procedural,baseline; evolving ADS/movement unproven')
    prepare.add_argument('--gpu-timestamps', action='store_true',
                         help='Opt in to exact-primary CPU/GPU sidecars on reviewed DX12 source')
    prepare.add_argument('--baseline-only', action='store_true',
                         help='One 1080p stationary statistical capture per repeat; no other cases')
    prepare.add_argument('--procedural-baseline', action='store_true',
                         help='Use existing asset-free procedural presentation for baseline-only comparisons')
    prepare.add_argument('--output', type=Path, required=True)
    run = sub.add_parser('run', help='Opt-in sequential real-game desktop execution')
    for name in ('plan', 'executable', 'settings', 'output'):
        run.add_argument('--' + name, type=Path, required=True)
    for command in (prepare, run):
        source = command.add_mutually_exclusive_group(required=True)
        source.add_argument('--repository', type=Path)
        source.add_argument('--source-witness', type=Path)
        command.add_argument('--witness-sha256')
    run.add_argument('--graphics-settings', type=Path)
    run.add_argument('--force-fallback', action='store_true')
    run.add_argument('--hardware', type=Path, help='Optional operator CPU/display/driver notes; retained as claims')
    run.add_argument('--driver', choices=('win32', 'x11'), required=True)
    run.add_argument('--lock-file', type=Path, default=Path(tempfile.gettempdir()) / 'rust-duty-performance-desktop.lock')
    run.add_argument('--execute', action='store_true')
    run.add_argument('--continue-after-exit-timeout', action='store_true',
                     help='Continue measurements after validated exports and verified owned-process cleanup; exit failure stays failed')
    compare = sub.add_parser('compare', help='Eight sequential exact-source 1080p CPU/GPU captures')
    for label in ('baseline', 'candidate'):
        compare.add_argument('--' + label + '-source-witness', type=Path, required=True)
        compare.add_argument('--' + label + '-witness-sha256', required=True)
        compare.add_argument('--' + label + '-executable', type=Path, required=True)
        compare.add_argument('--' + label + '-build-receipt', type=Path, required=True)
    compare.add_argument('--settings', type=Path, required=True)
    compare.add_argument('--graphics-settings', type=Path)
    compare.add_argument('--force-fallback', action='store_true')
    compare.add_argument('--hardware', type=Path)
    compare.add_argument('--driver', choices=('win32',), required=True)
    compare.add_argument('--warmup-seconds', type=int, default=15)
    compare.add_argument('--sample-seconds', type=int, default=45)
    compare.add_argument('--procedural-baseline', action='store_true')
    compare.add_argument('--output', type=Path, required=True)
    compare.add_argument('--lock-file', type=Path, default=Path(tempfile.gettempdir()) / 'rust-duty-performance-desktop.lock')
    compare.add_argument('--execute', action='store_true')
    analyze = sub.add_parser('analyze', help='Read existing runs, preserve missing/incomplete evidence')
    analyze.add_argument('folder', type=Path)
    analyze.add_argument('--output', type=Path)
    analyze.add_argument('--measurement-readiness', action='store_true',
                         help='Return measurement readiness only; overall correctness remains in state/graceful_shutdown')
    args = parser.parse_args(argv)
    try:
        if args.command == 'export-witness':
            print(export_witness(args.repository, args.output, args.harness))
        elif args.command == 'prepare':
            source, origin, _ = resolve_source(args)
            result = make_plan(source, args.renderer, args.repeats,
                               args.warmup_seconds, args.sample_seconds, args.smoke, args.pilot, origin,
                               args.static_diagnostics, args.gpu_timestamps, args.baseline_only, args.procedural_baseline)
            write_json(args.output, result)
            print(f'Prepared {len(result["order"])} sequential runs; no game launched: {args.output}')
        elif args.command == 'compare':
            result = compare_builds(args)
            print(json.dumps(result, indent=2))
        elif args.command == 'run':
            folder = run_matrix(args)
            print(folder)
            result = analyze_matrix(folder)
            if result['state'] == 'incomplete':
                # Code 3 is narrowly reserved for measurement continuation.
                return 3 if result['measurement_readiness']['ready'] else 2
        else:
            result = analyze_matrix(args.folder)
            if args.output:
                write_json(args.output, result)
            print(json.dumps(result, indent=2, allow_nan=False))
            # CI callers already use successful smoke analysis to gate a pilot.
            # A valid low-sample setup therefore stays explicitly setup_complete
            # in JSON while returning nonzero so that pilot is not auto-started.
            if args.measurement_readiness:
                return 0 if result['measurement_readiness']['ready'] else 1
            return 0 if result['state'] in ('complete', 'setup_complete') and result['pilot_sample_readiness']['ready'] else 1
        return 0
    except (OSError, ValueError, DriverError, subprocess.SubprocessError, KeyError, TypeError) as error:
        print('Matrix error: ' + str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
