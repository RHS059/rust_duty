import os,sys,json,time,subprocess,hashlib,signal
from pathlib import Path
root=Path("/content/rust-duty-resident-staging-20261012");out=root/"resident-diag-r01";out.mkdir()
source=root/"resident-diag-r01-work";exe=root/"packages/baseline/vector-range"
assert hashlib.sha256(exe.read_bytes()).hexdigest()=="146193cc4727f3d19859439b3ad3fb8b11e90f21df10aff3448aade47da29bb6"
assert not Path("/tmp/.X97-lock").exists() and not Path("/tmp/.X11-unix/X97").exists()
pref={"schema":"rust-duty-graphics-device/v1","adapter":{"backend":"vulkan","name":"NVIDIA A100-SXM4-40GB","vendor_id":4318,"device_id":8368,"device_type":"DiscreteGpu"}}
(out/"graphics.json").write_text(json.dumps(pref))
runtime=out/"xdg";runtime.mkdir(mode=0o700)
env=dict(os.environ,DISPLAY=":97",XDG_RUNTIME_DIR=str(runtime),LD_LIBRARY_PATH="/usr/lib64-nvidia",VK_ICD_FILENAMES=str(root/"nvidia-vulkan.json"),__EGL_VENDOR_LIBRARY_FILENAMES=str(root/"nvidia-egl.json"),WINIT_UNIX_BACKEND="x11")
receipt={"source":"1ef12e3f5840e1411c131e2859b133737f4ec565","executable_sha256":hashlib.sha256(exe.read_bytes()).hexdigest(),"purpose":"stationary resident-policy comparison on A100 Vulkan","started":time.time(),"passed":False,"events":[]}
children=[];streams=[]
def save():(out/"receipt.json").write_text(json.dumps(receipt,indent=2))
def spawn(args,name,cwd=None):
 f=(out/(name+".log")).open("x");streams.append(f);p=subprocess.Popen(args,cwd=cwd or out,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);children.append(p);return p
def command(args,timeout=10):return subprocess.run(args,env=env,capture_output=True,text=True,timeout=timeout,check=True).stdout
try:
 xv=spawn(["Xvfb",":97","-screen","0","2560x1440x24","-nolisten","tcp","-noreset"],"xvfb")
 for _ in range(50):
  if Path("/tmp/.X11-unix/X97").exists():break
  assert xv.poll() is None;time.sleep(.1)
 wm=spawn(["openbox","--sm-disable"],"openbox");time.sleep(1)
 args=[str(exe),"--renderer=vulkan","--physical-1080p","--present-mode=immediate","--gpu-timestamps","--no-update","--animation-manifest="+str(root/"authored-assets/assets/animations.cfg"),"--graphics-settings="+str(out/"graphics.json")]
 game=spawn(args,"game",source);receipt.update(pid=game.pid,command=args);save()
 win=[]
 for _ in range(150):
  assert game.poll() is None,("early_game_exit",game.returncode)
  q=subprocess.run(["xdotool","search","--onlyvisible","--pid",str(game.pid)],env=env,capture_output=True,text=True,timeout=2)
  if q.returncode==0:
   win=q.stdout.splitlines();break
  time.sleep(.2)
 assert len(win)==1,win
 w=win[0];receipt["window_id"]=w
 def key(k):
  assert command(["xdotool","getwindowpid",w]).strip()==str(game.pid)
  command(["xdotool","windowactivate","--sync",w])
  command(["xdotool","keydown",k]);time.sleep(.15);command(["xdotool","keyup",k])
  receipt["events"].append({"key":k,"at":time.time()});save()
 receipt["geometry"]=command(["xdotool","getwindowgeometry","--shell",w])
 deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  assert game.poll() is None,("early_game_exit",game.returncode)
  log=(out/"game.log").read_text()
  assert not any(e in log for e in ["Authored viewmodel could not load:","Authored viewmodel playback failed:","Action clip timings:"]),log
  if "Loaded Blender-authored viewmodel:" in log:break
  time.sleep(.2)
 else:raise RuntimeError("No positive authored load within30seconds")
 time.sleep(3);key("Return");time.sleep(2);key("F8")
 for i in range(30):
  assert game.poll() is None
  row=command(["nvidia-smi","--query-gpu=utilization.gpu,utilization.memory,memory.used","--format=csv,noheader,nounits"])
  receipt.setdefault("gpu_samples",[]).append({"at":time.time(),"value":row.strip()})
  time.sleep(1)
 try:
  from PIL import ImageGrab
  ImageGrab.grab(xdisplay=":97").save(out/"display.png")
 except Exception as e:receipt["screenshot_error"]=str(e)
 key("F8");time.sleep(3);key("F10")
 receipt["game_exit"]=game.wait(timeout=20)
 log=(out/"game.log").read_text()
 receipt["passed"]=receipt["game_exit"]==0 and "backend=Vulkan adapter=NVIDIA A100-SXM4-40GB" in log and "1920" in receipt["geometry"] and "1080" in receipt["geometry"]
except BaseException as e:receipt["error"]=repr(e)
finally:
 for p in reversed(children):
  if p.poll() is None:
   try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5)
   except Exception:
    try:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
    except Exception as e:receipt.setdefault("cleanup_errors",[]).append(str(e))
 for f in streams:f.close()
 receipt["finished"]=time.time();receipt["files"]={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob("*") if p.is_file() and p.name!="receipt.json"}
 save();print("SMOKE_FINISHED",json.dumps(receipt),flush=True)
