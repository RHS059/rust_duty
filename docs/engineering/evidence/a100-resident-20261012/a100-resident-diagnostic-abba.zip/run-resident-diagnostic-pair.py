"""Bounded source-bound A100 resident correctness then stationary ABBA."""
from pathlib import Path
import os,sys,json,hashlib,time,subprocess,signal,shutil
sys.dont_write_bytecode=True
ROOT=Path('/content/rust-duty-resident-staging-20261012')
preparation=json.loads((ROOT/'preparation.json').read_text())
assert preparation['passed'] and preparation['final_tool_configuration_verified']
assert preparation['source']=='1ef12e3f5840e1411c131e2859b133737f4ec565'
assets=json.loads((ROOT/'assets.json').read_text())
RESULT=ROOT/'resident-diagnostic-result.json';assert not RESULT.exists()
result={'schema':'rust-duty-colab-resident-abba-diagnostic/v1','diagnostic_only':True,'correctness_gate_passed':False,'capture_protocol_passed':False,'staging_policy':'bounded_staging_v1','timing_scope':'GPU timestamps start after staging copies; CPU geometry_upload includes staging preparation and copy recording.','passed':False,'started':time.time(),'runs':[],
 'order':['baseline','candidate','candidate','baseline'],'requested_record_seconds':30,
 'input':'stationary after Enter; no movement or mouse replay','gpu_timestamps_requested':True,
 'source':preparation['source'],'tree':preparation['tree']}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():RESULT.write_text(json.dumps(result,indent=2)+'\n')
def inventory(folder):
 paths=list(folder.rglob('*'));assert not any(p.is_symlink() for p in paths)
 return {str(p.relative_to(folder)):sha(p) for p in paths if p.is_file()}
result['preparation_sha256']=sha(ROOT/'preparation.json')
result['assets_sha256']=sha(ROOT/'assets.json')
result['fixture_input_sha256']=sha(ROOT/'resident-inputs.json')
result['config_hashes']={n:sha(ROOT/n) for n in ('nvidia-vulkan.json','nvidia-egl.json')}
result['controller_sha256']=sha(Path(__file__))
sys.path.insert(0,str(ROOT/'build-source/tools'))
import run_cpu_image_preservation as guard
import run_resident_authored_contract as fixture
import summarize_frame_performance as frames
import summarize_cpu_substages as cpu
import summarize_cpu_encode_detail as detail
import summarize_gpu_timing as gpu
ENV=dict(os.environ,CARGO_HOME=str(ROOT/'cargo'),RUSTUP_HOME=str(ROOT/'rustup'),RUSTUP_TOOLCHAIN='1.99.0',CARGO_TARGET_DIR=str(ROOT/'target'))
ENV['PATH']=str(ROOT/'cargo/bin')+':'+ENV['PATH']
ENV.update(LD_LIBRARY_PATH='/usr/lib64-nvidia',VK_ICD_FILENAMES=str(ROOT/'nvidia-vulkan.json'),__EGL_VENDOR_LIBRARY_FILENAMES=str(ROOT/'nvidia-egl.json'))
def verify_inputs():
 assert sha(Path(__file__))==result['controller_sha256']
 for n,h in result['config_hashes'].items():assert sha(ROOT/n)==h
 assert sha(ROOT/'preparation.json')==result['preparation_sha256']
 assert sha(ROOT/'assets.json')==result['assets_sha256']
 assert sha(ROOT/'resident-inputs.json')==result['fixture_input_sha256']
 guard.check_environment(os.environ)
 for variant,directory in [('candidate','build-source'),('baseline','baseline-source')]:
  d=ROOT/directory;assert inventory(d)==preparation[variant+'_files']
  guard.check_cargo_configuration(d,ENV)
  assert subprocess.check_output(['rustc','-Vv'],cwd=d,env=ENV,text=True)==preparation['compiler']
  assert subprocess.check_output(['cargo','-Vv'],cwd=d,env=ENV,text=True)==preparation['cargo']
 assert inventory(ROOT/'authored-assets')==assets['files']
 assert inventory(ROOT/'packages')=={n:r['sha256'] for n,r in preparation['executables'].items()}
def verify_outputs():
 for name,h in result.get('bound_failed_attempt',{}).items():assert sha(ROOT/name)==h
 for name,expected in result.get('fixture_inventory',{}).items():assert inventory(ROOT/name)==expected
 for row in result['runs']:
  for name,h in row.get('driver_files',{}).items():assert sha(ROOT/name)==h
  for name,expected in row.get('retained_outputs',{}).items():assert inventory(ROOT/name)==expected

def process_snapshot():
 rows={}
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   f=p.read_text().rsplit(') ',1)[1].split();rows[int(p.parent.name)]=(int(f[1]),int(f[19]),f[0])
  except (OSError,ValueError,IndexError):pass
 return rows

def track(pid,known):
 rows=process_snapshot();selected={pid} if pid in rows and pid in known and known[pid]==rows[pid][1] else set()
 selected|={p for p,start in known.items() if p in rows and rows[p][1]==start}
 while True:
  children={p for p,(parent,_,_) in rows.items() if parent in selected}
  if children<=selected:break
  selected|=children
 known.update({p:rows[p][1] for p in selected})
 return {p for p in selected if rows[p][2]!='Z'}

def cleanup_driver(proc,known,reason):
 cleanup={'reason':reason,'signals':[],'remaining':[]}
 for sig in (signal.SIGTERM,signal.SIGKILL):
  live=track(proc.pid,known)
  for pid in sorted(live,key=lambda x:x==proc.pid):
   now=process_snapshot().get(pid)
   if now is not None and now[1]==known.get(pid):
    try:os.kill(pid,sig);cleanup['signals'].append([pid,int(sig)])
    except ProcessLookupError:pass
  until=time.monotonic()+5
  while time.monotonic()<until and track(proc.pid,known):time.sleep(.1)
 cleanup['remaining']=sorted(track(proc.pid,known))
 try:proc.wait(timeout=2)
 except subprocess.TimeoutExpired:cleanup['driver_wait_timeout']=True
 return cleanup


def run_owned(args,log,env=None,cwd=None,timeout=120):
 proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=cwd,start_new_session=True)
 initial=process_snapshot().get(proc.pid);known={proc.pid:initial[1]} if initial else {}
 record={'args':args,'pid':proc.pid,'started':time.time()};result.setdefault('processes',[]).append(record);save()
 try:
  deadline=time.monotonic()+timeout
  while proc.poll() is None:
   track(proc.pid,known)
   if time.monotonic()>deadline:raise TimeoutError('owned controller deadline')
   time.sleep(.25)
  record['exit_code']=proc.returncode
  if proc.returncode:raise RuntimeError(('process exit',proc.returncode))
  if track(proc.pid,known):raise RuntimeError('owned process left children')
 except BaseException as e:
  record['error']=repr(e);record['cleanup']=cleanup_driver(proc,known,repr(e));raise
 finally:record['finished']=time.time();save()
def replace_once(text,old,new):
 assert text.count(old)==1,(old,text.count(old));return text.replace(old,new)

TEMPLATE='import os,sys,json,time,subprocess,hashlib,signal\nfrom pathlib import Path\nroot=Path("/content/rust-duty-gpu-20261012");out=root/"vulkan-smoke3";out.mkdir()\nsource=root/"build-source";exe=root/"target/release/vector-range"\nassert hashlib.sha256(exe.read_bytes()).hexdigest()=="fccc181957a2cb064a3ca29539f194bc93170b795e1be3dff83b17169cc1ddde"\nassert not Path("/tmp/.X97-lock").exists() and not Path("/tmp/.X11-unix/X97").exists()\npref={"schema":"rust-duty-graphics-device/v1","adapter":{"backend":"vulkan","name":"NVIDIA A100-SXM4-40GB","vendor_id":4318,"device_id":8368,"device_type":"DiscreteGpu"}}\n(out/"graphics.json").write_text(json.dumps(pref))\nruntime=out/"xdg";runtime.mkdir(mode=0o700)\nenv=dict(os.environ,DISPLAY=":97",XDG_RUNTIME_DIR=str(runtime),LD_LIBRARY_PATH="/usr/lib64-nvidia",VK_ICD_FILENAMES=str(root/"nvidia-vulkan.json"),__EGL_VENDOR_LIBRARY_FILENAMES=str(root/"nvidia-egl.json"),WINIT_UNIX_BACKEND="x11")\nreceipt={"source":"c111eba1bbd67b9988aeada4fbf9b2b528d43b65","executable_sha256":hashlib.sha256(exe.read_bytes()).hexdigest(),"purpose":"procedural physical1080p Vulkan hardware surface/Record smoke; not authored performance acceptance","started":time.time(),"passed":False,"events":[]}\nchildren=[];streams=[]\ndef save():(out/"receipt.json").write_text(json.dumps(receipt,indent=2))\ndef spawn(args,name,cwd=None):\n f=(out/(name+".log")).open("x");streams.append(f);p=subprocess.Popen(args,cwd=cwd or out,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);children.append(p);return p\ndef command(args,timeout=10):return subprocess.run(args,env=env,capture_output=True,text=True,timeout=timeout,check=True).stdout\ntry:\n xv=spawn(["Xvfb",":97","-screen","0","2560x1440x24","-nolisten","tcp","-noreset"],"xvfb")\n for _ in range(50):\n  if Path("/tmp/.X11-unix/X97").exists():break\n  assert xv.poll() is None;time.sleep(.1)\n wm=spawn(["openbox","--sm-disable"],"openbox");time.sleep(1)\n args=[str(exe),"--renderer=vulkan","--physical-1080p","--present-mode=immediate","--gpu-timestamps","--no-update","--procedural-weapon","--graphics-settings="+str(out/"graphics.json")]\n game=spawn(args,"game",source);receipt.update(pid=game.pid,command=args);save()\n win=[]\n for _ in range(150):\n  assert game.poll() is None,("early_game_exit",game.returncode)\n  q=subprocess.run(["xdotool","search","--onlyvisible","--pid",str(game.pid)],env=env,capture_output=True,text=True,timeout=2)\n  if q.returncode==0:\n   win=q.stdout.splitlines();break\n  time.sleep(.2)\n assert len(win)==1,win\n w=win[0];receipt["window_id"]=w\n def key(k):\n  assert command(["xdotool","getwindowpid",w]).strip()==str(game.pid)\n  command(["xdotool","windowactivate","--sync",w])\n  command(["xdotool","keydown",k]);time.sleep(.15);command(["xdotool","keyup",k])\n  receipt["events"].append({"key":k,"at":time.time()});save()\n receipt["geometry"]=command(["xdotool","getwindowgeometry","--shell",w])\n time.sleep(3);key("Return");time.sleep(2);key("F8")\n for i in range(10):\n  assert game.poll() is None\n  row=command(["nvidia-smi","--query-gpu=utilization.gpu,utilization.memory,memory.used","--format=csv,noheader,nounits"])\n  receipt.setdefault("gpu_samples",[]).append({"at":time.time(),"value":row.strip()})\n  time.sleep(1)\n try:\n  from PIL import ImageGrab\n  ImageGrab.grab(xdisplay=":97").save(out/"display.png")\n except Exception as e:receipt["screenshot_error"]=str(e)\n key("F8");time.sleep(3);key("F10")\n receipt["game_exit"]=game.wait(timeout=20)\n log=(out/"game.log").read_text()\n receipt["passed"]=receipt["game_exit"]==0 and "backend=Vulkan adapter=NVIDIA A100-SXM4-40GB" in log and "1920" in receipt["geometry"] and "1080" in receipt["geometry"]\nexcept BaseException as e:receipt["error"]=repr(e)\nfinally:\n for p in reversed(children):\n  if p.poll() is None:\n   try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5)\n   except Exception:\n    try:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)\n    except Exception as e:receipt.setdefault("cleanup_errors",[]).append(str(e))\n for f in streams:f.close()\n receipt["finished"]=time.time();receipt["files"]={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob("*") if p.is_file() and p.name!="receipt.json"}\n save();print("SMOKE_FINISHED",json.dumps(receipt),flush=True)\n'
LOAD_WAIT='deadline=time.monotonic()+30\n while time.monotonic()<deadline:\n  assert game.poll() is None,("early_game_exit",game.returncode)\n  log=(out/"game.log").read_text()\n  assert not any(e in log for e in ["Authored viewmodel could not load:","Authored viewmodel playback failed:","Action clip timings:"]),log\n  if "Loaded Blender-authored viewmodel:" in log:break\n  time.sleep(.2)\n else:raise RuntimeError("No positive authored load within30seconds")\n time.sleep(3);key("Return");time.sleep(2);key("F8")'

try:
 verify_inputs()
 result['bound_failed_attempt']={'resident-result-r2.json': 'f90c4d302125597145300e85a805f22798bf3dbdd063b4487fbeaaa39cb5faca', 'run-resident-pair-r2.py': '750a9f2e93c7dd713ba141c8d73acca1eb328956ef0d2995d76ccaca6fad861f', 'run-resident-pair-r2.log': 'ffa48976296a2f2e224f6e09521c35d8ab390b665e6108a7dfc931e4a14fd72e'}
 result['fixture_inventory']={'resident-correctness-r2': {'ads-0-cpu.png': '655e60d078bfd957dc853d196868341ccdfb4da11ab2ef78bf88360653b605b5', 'ads-0-resident.png': '655e60d078bfd957dc853d196868341ccdfb4da11ab2ef78bf88360653b605b5', 'ads-1-cpu.png': '72cd25b6f7e49ae4b6820246cbfe70f0e0812ecfb9096b5c56d6475e38c2fc4b', 'ads-1-resident.png': '853943b78f6638be43629b7a69b786eabdf2d1933e4c30aa1d5fc9b54adf1c2a', 'ads-2-cpu.png': 'dfdcd731cf994167c42ecd4680c062a514cf0b6194d25d4c666fa8c86cf58a1c', 'ads-2-resident.png': 'dfdcd731cf994167c42ecd4680c062a514cf0b6194d25d4c666fa8c86cf58a1c', 'ads-3-cpu.png': '655e60d078bfd957dc853d196868341ccdfb4da11ab2ef78bf88360653b605b5', 'ads-3-resident.png': '655e60d078bfd957dc853d196868341ccdfb4da11ab2ef78bf88360653b605b5', 'camera.json': '17f4ced2adc17c042955ffa5e900a789ad5d2fe55257ecd201191854eac9ddb2', 'manifest-0-cpu.png': '1f491f5026b1e15f190aadb94927cb2b15fc8333ae748158eb3ec68bd1ac45f6', 'manifest-0-resident.png': 'a1046815f509fd1b3bcb87db7e4a8c40510af8f475bf4857dc99cd0c64b54cc1', 'manifest-12-cpu.png': '1f491f5026b1e15f190aadb94927cb2b15fc8333ae748158eb3ec68bd1ac45f6', 'manifest-12-resident.png': 'a1046815f509fd1b3bcb87db7e4a8c40510af8f475bf4857dc99cd0c64b54cc1', 'manifest-24-cpu.png': '1f491f5026b1e15f190aadb94927cb2b15fc8333ae748158eb3ec68bd1ac45f6', 'manifest-24-resident.png': 'a1046815f509fd1b3bcb87db7e4a8c40510af8f475bf4857dc99cd0c64b54cc1', 'ready-0-cpu.png': '1f491f5026b1e15f190aadb94927cb2b15fc8333ae748158eb3ec68bd1ac45f6', 'ready-0-resident.png': 'a1046815f509fd1b3bcb87db7e4a8c40510af8f475bf4857dc99cd0c64b54cc1', 'ready-1-cpu.png': '1f491f5026b1e15f190aadb94927cb2b15fc8333ae748158eb3ec68bd1ac45f6', 'ready-1-resident.png': 'a1046815f509fd1b3bcb87db7e4a8c40510af8f475bf4857dc99cd0c64b54cc1', 'ready-2-cpu.png': 'fe2469a475f593bfe46f8749e4c5c36e010ef241f6fbc6b90a157070973b1889', 'ready-2-resident.png': 'fe2469a475f593bfe46f8749e4c5c36e010ef241f6fbc6b90a157070973b1889', 'ready-3-cpu.png': '1f491f5026b1e15f190aadb94927cb2b15fc8333ae748158eb3ec68bd1ac45f6', 'ready-3-resident.png': 'a1046815f509fd1b3bcb87db7e4a8c40510af8f475bf4857dc99cd0c64b54cc1', 'reload-0-cpu.png': '40a3cd9224744313f0bd6b4302b9e73c2f4631167803669cd17d35b0e9ea35d2', 'reload-0-resident.png': '40a3cd9224744313f0bd6b4302b9e73c2f4631167803669cd17d35b0e9ea35d2', 'reload-1-cpu.png': '6a35f2d25b904b380e780d76c82e289108dd761622290fddf2dbded1431bccd7', 'reload-1-resident.png': '83ce911bc08c0d5613baa7b86c1cc4ca841377453a1e300455c647e17bb50deb', 'reload-2-cpu.png': '67c873599dfe4c9cb56130c498643a588a6b29708f483a3608a5c945e57508eb', 'reload-2-resident.png': '67c873599dfe4c9cb56130c498643a588a6b29708f483a3608a5c945e57508eb', 'reload-3-cpu.png': '40a3cd9224744313f0bd6b4302b9e73c2f4631167803669cd17d35b0e9ea35d2', 'reload-3-resident.png': '40a3cd9224744313f0bd6b4302b9e73c2f4631167803669cd17d35b0e9ea35d2', 'report.json': 'b97fedf3ea237313c0fe5a7460dd2923b30dfb5951b7a4a67f2596bd016d34df', 'rigid-alpha-0-cpu.png': '2c56ea3457cb95af4906a6548385aa63e2222d3527a9d9a46caeeb5f67c7252b', 'rigid-alpha-0-resident.png': '2c56ea3457cb95af4906a6548385aa63e2222d3527a9d9a46caeeb5f67c7252b', 'rigid-alpha-1-cpu.png': 'a933e266234d33e4c4e7894b087194b16460f7a0946cc6f4a2763888ecfe7a03', 'rigid-alpha-1-resident.png': 'a933e266234d33e4c4e7894b087194b16460f7a0946cc6f4a2763888ecfe7a03', 'rigid-alpha-2-cpu.png': '2c56ea3457cb95af4906a6548385aa63e2222d3527a9d9a46caeeb5f67c7252b', 'rigid-alpha-2-resident.png': '2c56ea3457cb95af4906a6548385aa63e2222d3527a9d9a46caeeb5f67c7252b', 'walk-0-cpu.png': '913e3c306d9d5e0ad176fe67ec94289dd75607c10a53bd344481178bf0320792', 'walk-0-resident.png': '42d0fbe8710b580f844730ee9568e34ffcc22eb11df9db81c9a23d0ae419bb85', 'walk-1-cpu.png': 'ce7f22c0a22286e7e9bd84845049ae62b8e88a1e63add9ffbb27bd75fd1ac561', 'walk-1-resident.png': '79332a09edde52b3f2a928e52e7ac8e2d0a870fc2241bfb7a78e673bb8aab2db', 'walk-2-cpu.png': '9ad8ff8f1adb4d6afde711d29f0ff9c182a45a868b13713cf704035a24008396', 'walk-2-resident.png': '9ad8ff8f1adb4d6afde711d29f0ff9c182a45a868b13713cf704035a24008396', 'walk-3-cpu.png': '913e3c306d9d5e0ad176fe67ec94289dd75607c10a53bd344481178bf0320792', 'walk-3-resident.png': '42d0fbe8710b580f844730ee9568e34ffcc22eb11df9db81c9a23d0ae419bb85', 'ready-2-resident.corners.bin': 'd3644b383f53effd6c813e05543c63c2336ebf8e8ed828909849a84e4309e910', 'ads-1-resident.corners.bin': 'b1e183d19dd3606ece5e3b516d33e36381729c8b350a108a4363f143913cd90c', 'ready-3-resident.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'ready-3-cpu.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'reload-3-cpu.corners.bin': '0df618c1e2d5e9598067f54380efbdaa425afcc5b6beb26285f55116bd116702', 'walk-0-resident.corners.bin': '76f7e0b3dec4b1f688c91bb730af5c2e2e4ad58c51d69f2ed597ea42a3a29048', 'ads-0-cpu.corners.bin': 'df4ad6f478773e4df04a6cd4a78955aa238f33c0f7f7268b453813bc25357774', 'ads-1-cpu.corners.bin': 'b1e183d19dd3606ece5e3b516d33e36381729c8b350a108a4363f143913cd90c', 'reload-0-cpu.corners.bin': '0df618c1e2d5e9598067f54380efbdaa425afcc5b6beb26285f55116bd116702', 'walk-1-resident.corners.bin': '02df5a89284f8dc7973bc26ab63b0ed494b534481cd6c295e9712031180795f1', 'ads-2-resident.corners.bin': '055fd37f3ed520700d9cba78dc55920e20c0b856f8795c3f60147d41dc4c25db', 'rigid-alpha-2-resident.corners.bin': '2993b313c73d3a3df647758fc46296697a20417bc45f6d6820a4ef6e11fc88eb', 'ready-1-cpu.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'manifest-0-resident.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'reload-2-resident.corners.bin': 'e024ac844dbda325a6dbeca1b98276d6ee8255bc79676ed77371ea63507e0cfd', 'ready-0-cpu.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'ads-0-resident.corners.bin': 'df4ad6f478773e4df04a6cd4a78955aa238f33c0f7f7268b453813bc25357774', 'walk-1-cpu.corners.bin': '02df5a89284f8dc7973bc26ab63b0ed494b534481cd6c295e9712031180795f1', 'manifest-0-cpu.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'manifest-24-resident.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'ads-3-resident.corners.bin': 'df4ad6f478773e4df04a6cd4a78955aa238f33c0f7f7268b453813bc25357774', 'walk-2-cpu.corners.bin': '79385be4e77ad16bc4446d9f475ea8e84ca4adedd66ba2b5411c2064c1192348', 'rigid-alpha-0-cpu.corners.bin': '2993b313c73d3a3df647758fc46296697a20417bc45f6d6820a4ef6e11fc88eb', 'walk-2-resident.corners.bin': '79385be4e77ad16bc4446d9f475ea8e84ca4adedd66ba2b5411c2064c1192348', 'rigid-alpha-1-resident.corners.bin': 'cd386741131da8a1f736a36f657b9439ba5b17cdc596d27e778fe11d9fef1319', 'reload-1-resident.corners.bin': 'fb783c88bdac57dbaaec61b8711bb27493fcc40ad6154a17cae4f74066352315', 'rigid-alpha-2-cpu.corners.bin': '2993b313c73d3a3df647758fc46296697a20417bc45f6d6820a4ef6e11fc88eb', 'reload-3-resident.corners.bin': '0df618c1e2d5e9598067f54380efbdaa425afcc5b6beb26285f55116bd116702', 'walk-3-cpu.corners.bin': '76f7e0b3dec4b1f688c91bb730af5c2e2e4ad58c51d69f2ed597ea42a3a29048', 'ready-0-resident.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'reload-2-cpu.corners.bin': 'e024ac844dbda325a6dbeca1b98276d6ee8255bc79676ed77371ea63507e0cfd', 'manifest-24-cpu.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'reload-0-resident.corners.bin': '0df618c1e2d5e9598067f54380efbdaa425afcc5b6beb26285f55116bd116702', 'ready-2-cpu.corners.bin': 'd3644b383f53effd6c813e05543c63c2336ebf8e8ed828909849a84e4309e910', 'reload-1-cpu.corners.bin': 'fb783c88bdac57dbaaec61b8711bb27493fcc40ad6154a17cae4f74066352315', 'ready-1-resident.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'manifest-12-resident.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'rigid-alpha-1-cpu.corners.bin': 'cd386741131da8a1f736a36f657b9439ba5b17cdc596d27e778fe11d9fef1319', 'ads-2-cpu.corners.bin': '055fd37f3ed520700d9cba78dc55920e20c0b856f8795c3f60147d41dc4c25db', 'walk-3-resident.corners.bin': '76f7e0b3dec4b1f688c91bb730af5c2e2e4ad58c51d69f2ed597ea42a3a29048', 'rigid-alpha-0-resident.corners.bin': '2993b313c73d3a3df647758fc46296697a20417bc45f6d6820a4ef6e11fc88eb', 'ads-3-cpu.corners.bin': 'df4ad6f478773e4df04a6cd4a78955aa238f33c0f7f7268b453813bc25357774', 'manifest-12-cpu.corners.bin': '398f59a95635cea983ddeb94d28b3f0fe43b5bf362fcc95f171a1e39567f7413', 'walk-0-cpu.corners.bin': '76f7e0b3dec4b1f688c91bb730af5c2e2e4ad58c51d69f2ed597ea42a3a29048'}, 'resident-correctness-process-r2': {'combined.log': '3e696d7f098252e19045e8be2bcee4189d705ac86b4c97c3935f469990759603'}}
 verify_outputs()
 failed=json.loads((ROOT/'resident-result-r2.json').read_text())
 assert failed['passed'] is False and failed['final_inputs_verified'] and failed['final_outputs_verified']
 assert failed['error']=="RuntimeError(('process exit', 1))" and failed['runs']==[]
 report=fixture.read_report(ROOT/'resident-correctness-r2/report.json')
 assert report['passed'] is False and report['source_receipt_sha256']==result['fixture_input_sha256']
 assert len(report['cases'])==22 and all(c['expanded_equal'] for c in report['cases'])
 assert sum(c['differing_pixels'] for c in report['cases'])==18 and max(c['maximum_channel_delta'] for c in report['cases'])==3
 result['correctness_failure']={'original_result':'resident-result-r2.json','original_report':'resident-correctness-r2/report.json','passed':False,'different_pairs':11,'differing_pixels':18,'maximum_channel_delta':3,'expanded_corner_pairs_equal':22}
 result['device']=fixture.device_evidence(ROOT/'resident-correctness-process-r2/combined.log',report)
 verify_inputs();verify_outputs();save();print('DIAGNOSTIC_ONLY_WITH_PRESERVED_PIXEL_FAILURE',flush=True)
 for i,variant in enumerate(result['order'],1):
  name=f'resident-diag-r{i:02d}';work=ROOT/(name+'-work');work.mkdir()
  public_inputs={p:h for p,h in preparation['candidate_files'].items() if p=='settings.cfg' or p.startswith(('ui/','profiles/'))}
  for p,h in public_inputs.items():
   dst=work/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/'build-source'/p,dst);assert sha(dst)==h
  script=replace_once(TEMPLATE,'/content/rust-duty-gpu-20261012',str(ROOT))
  script=replace_once(script,'out=root/"vulkan-smoke3"',f'out=root/"{name}"')
  script=replace_once(script,'source=root/"build-source";exe=root/"target/release/vector-range"',f'source=root/"{name}-work";exe=root/"packages/{variant}/vector-range"')
  script=replace_once(script,'fccc181957a2cb064a3ca29539f194bc93170b795e1be3dff83b17169cc1ddde',preparation['executables'][variant+'/vector-range']['sha256'])
  script=replace_once(script,'c111eba1bbd67b9988aeada4fbf9b2b528d43b65',preparation['source'])
  script=replace_once(script,'"--procedural-weapon"','"--animation-manifest="+str(root/"authored-assets/assets/animations.cfg")')
  script=replace_once(script,'for i in range(10):','for i in range(30):')
  script=replace_once(script,'procedural physical1080p Vulkan hardware surface/Record smoke; not authored performance acceptance','stationary resident-policy comparison on A100 Vulkan')
  script=replace_once(script,'time.sleep(3);key("Return");time.sleep(2);key("F8")',LOAD_WAIT)
  path=ROOT/(name+'-driver.py');path.write_text(script);compile(script,str(path),'exec')
  with (ROOT/(name+'-driver.log')).open('x') as log:run_owned([sys.executable,str(path)],log)
  receipt=json.loads((ROOT/name/'receipt.json').read_text())
  row={'index':i,'variant':variant,'driver_sha256':sha(path),'receipt_sha256':sha(ROOT/name/'receipt.json'),'normal_exit':receipt.get('game_exit'),'passed':False,'retained_outputs':{name:inventory(ROOT/name),name+'-work':inventory(work)}}
  row['driver_files']={n:sha(ROOT/n) for n in (name+'-driver.py',name+'-driver.log')}
  result['runs'].append(row);save()
  assert receipt['passed'] and receipt['game_exit']==0 and 'error' not in receipt and not receipt.get('cleanup_errors'),receipt
  assert receipt['executable_sha256']==preparation['executables'][variant+'/vector-range']['sha256']
  sessions=list((work/'telemetry-sessions').glob('*/frames.json'));assert len(sessions)==1
  primary,h=cpu.read_json(sessions[0]);frames.validate_report(primary)
  sub,_=cpu.read_json(sessions[0].with_name('frames.cpu-substages.json'))
  enc,_=cpu.read_json(sessions[0].with_name('frames.cpu-encode-detail.json'))
  gs,_=cpu.read_json(sessions[0].with_name('frames.gpu-timing.json'))
  ds=detail.summarize(enc,sub,primary,h);gsummary=gpu.summarize(gs,primary,h)
  assert primary['status']=={'error':None,'state':'complete'} and primary['summary']['interval_count']>=100
  assert gsummary['state']=='complete' and gsummary['availability']['state']=='available' and gsummary['measured_eligible_count']>=100,gsummary
  observed=primary['identity']['runtime_observed'];adapter=observed['actual_adapter']
  fingerprint={'backend':'vulkan','device_id':8368,'device_type':'DiscreteGpu','name':'NVIDIA A100-SXM4-40GB','vendor_id':4318}
  assert observed['actual_backend']=='Vulkan' and adapter['actual_fingerprint']==fingerprint and adapter['requested_fingerprint']==fingerprint
  assert adapter['selection_mode']=='explicit_fingerprint' and adapter['force_fallback_requested'] is False
  assert adapter['backend']=='Vulkan' and adapter['name']==fingerprint['name'] and adapter['vendor_id']==4318 and adapter['device_id']==8368 and adapter['device_type']=='DiscreteGpu'
  assert adapter['driver']=='NVIDIA' and preparation['gpu']==fingerprint['name']+', '+adapter['driver_info']
  assert adapter['present_mode']=='Immediate' and adapter['present_policy']=={'actual_mode':'immediate','explicit_request':True,'requested_mode':'immediate'}
  descriptor=adapter['instance_descriptor'];assert descriptor['flags_bits']==32 and descriptor['application_debug_assertions'] is False and descriptor['environment_overrides_applied'] is False
  assert adapter['gpu_timestamps_requested'] is True and adapter['gpu_timestamp_features_enabled'] is True
  window=observed['initial_window'];assert window['physical_width']==1920 and window['physical_height']==1080
  assert all(s['physical_width']==1920 and s['physical_height']==1080 for s in primary['cpu_frame_stages']['samples'])
  scene={'capture_sequence':None,'demo':False,'diagnostic_capture':False,'name':'vector_range_default_range','presentation':'authored_viewmodel','profile_base':'m4a1','reference_viewport':False,'weapon_id':'hk416a5'}
  assert observed['scene']==scene
  bound_identity={'adapter':adapter,'window':window,'scene':scene}
  if 'matched_runtime_identity' not in result:result['matched_runtime_identity']=bound_identity
  assert bound_identity==result['matched_runtime_identity']
  assert enc['schema']==detail.SCHEMA_V4 and enc['staging_policy']=='bounded_staging_v1' and enc['resident_policy']==('vertex_lit_skin_v1' if variant=='candidate' else 'cpu_vertex_reference_v1')
  assert ds['diagnostic_status']=='complete' and ds['summarized_attempts']>=100
  if variant=='candidate':
   assert ds['counters']['resident_rigid_draws']['min']>0 and ds['counters']['resident_skinned_draws']['min']>0
  else:assert ds['counters']['resident_draws']['total']==0
  log=(ROOT/name/'game.log').read_text()
  assert 'Loaded Blender-authored viewmodel:' in log and not any(e in log for e in ['Authored viewmodel could not load:','Authored viewmodel playback failed:','Action clip timings:'])
  for p,h0 in public_inputs.items():assert sha(work/p)==h0
  row.update(session=str(sessions[0].parent.relative_to(ROOT)),primary_sha256=h,frame_summary=primary['summary'],cpu_detail_summary=ds,gpu_summary=gsummary)
  verify_inputs();verify_outputs();row['passed']=True;save();print('RESIDENT_RUN_FINISHED',i,variant,primary['summary'],flush=True)
 result['capture_protocol_passed']=True
except BaseException as e:result['error']=repr(e)
finally:
 try:verify_inputs();verify_outputs();result['final_inputs_verified']=True;result['final_outputs_verified']=True
 except BaseException as e:result['final_check_error']=repr(e);result['passed']=False;result['capture_protocol_passed']=False
 result['finished']=time.time();save();print('RESIDENT_DIAGNOSTIC_FINISHED',result['capture_protocol_passed'],result.get('error'),flush=True)
