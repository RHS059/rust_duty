"""Fresh, source-bound Linux resident-policy pair; no private model inputs."""
from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,urllib.request,zipfile,stat,sys

ROOT=Path('/content/rust-duty-resident-staging-20261012')
PIN='1ef12e3f5840e1411c131e2859b133737f4ec565'
TREE='18d01cae913011f577f2d34802806693c95cc75d'
ASSET_URL='https://github.com/RHS059/rust_duty/releases/download/v0.1.9/Rust-Duty-0.1.9-Linux-x64.zip'
ASSET_SHA='b4978796abf0b3301649ae885bf5cce1c0043036ee5297cfc6220ec933b3a5d0'
ROOT.mkdir(exist_ok=False)
status={'schema':'rust-duty-colab-resident-preparation/v1','source':PIN,'tree':TREE,'started':time.time(),'passed':False,'commands':[]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():(ROOT/'preparation.json').write_text(json.dumps(status,indent=2)+'\n')
def process_snapshot():
 rows={}
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   f=p.read_text().rsplit(') ',1)[1].split();rows[int(p.parent.name)]=(int(f[1]),int(f[19]),f[0])
  except (OSError,ValueError,IndexError):pass
 return rows
def track(pid,known):
 rows=process_snapshot();selected={pid} if pid in rows and pid in known and known[pid]==rows[pid][1] else set()
 selected|={p for p,start in known.items() if p in rows and rows[p][1]==start}
 while True:
  children={p for p,(parent,_,_) in rows.items() if parent in selected}
  if children<=selected:break
  selected|=children
 known.update({p:rows[p][1] for p in selected})
 return {p for p in selected if rows[p][2]!='Z'}
def cleanup_driver(proc,known,reason):
 cleanup={'reason':reason,'signals':[],'remaining':[]}
 for sig in (signal.SIGTERM,signal.SIGKILL):
  live=track(proc.pid,known)
  for pid in sorted(live,key=lambda x:x==proc.pid):
   now=process_snapshot().get(pid)
   if now is not None and now[1]==known.get(pid):
    try:os.kill(pid,sig);cleanup['signals'].append([pid,int(sig)])
    except ProcessLookupError:pass
  until=time.monotonic()+5
  while time.monotonic()<until and track(proc.pid,known):time.sleep(.1)
 cleanup['remaining']=sorted(track(proc.pid,known))
 try:proc.wait(timeout=2)
 except subprocess.TimeoutExpired:cleanup['driver_wait_timeout']=True
 return cleanup
def run(args,cwd=None,env=None,timeout=1200):
 status['phase']=' '.join(map(str,args[:3]));save()
 p=subprocess.Popen(args,cwd=cwd or ROOT,env=env,stdin=subprocess.DEVNULL,start_new_session=True)
 initial=process_snapshot().get(p.pid);known={p.pid:initial[1]} if initial is not None else {}
 row={'command':list(map(str,args)),'pid':p.pid,'started':time.time()};status['commands'].append(row);save()
 try:
  deadline=time.monotonic()+timeout
  while p.poll() is None:
   track(p.pid,known)
   if time.monotonic()>deadline:raise TimeoutError('owned preparation deadline')
   time.sleep(.25)
  row['exit_code']=p.returncode
  if p.returncode:raise RuntimeError(('exit',p.returncode))
  if track(p.pid,known):raise RuntimeError('preparation command left owned children')
 except BaseException as error:
  row['error']=repr(error);row['cleanup']=cleanup_driver(p,known,repr(error));raise
 finally:row['finished']=time.time();save()
def inventory(directory):
 entries=list(directory.rglob('*'));assert not any(p.is_symlink() for p in entries)
 return {str(p.relative_to(directory)):sha(p) for p in entries if p.is_file()}

try:
 assert 'VR_WEAPON_ASSET' not in os.environ
 forbidden=[k for k in os.environ if k.startswith(('CARGO_BUILD_','CARGO_TARGET_','CARGO_PROFILE_','CARGO_SOURCE_','CARGO_PATCH_')) or k in ['RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_ENCODED_RUSTDOCFLAGS','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC_BOOTSTRAP','RUSTDOC','RUSTUP_TOOLCHAIN']]
 assert not forbidden,forbidden
 env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_LFS_SKIP_SMUDGE='1',CARGO_HOME=str(ROOT/'cargo'),RUSTUP_HOME=str(ROOT/'rustup'),RUSTUP_TOOLCHAIN='1.99.0',CARGO_TARGET_DIR=str(ROOT/'target'),CI='true')
 env['PATH']=str(ROOT/'cargo/bin')+':'+env['PATH']
 status['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True).strip()
 assert status['gpu'].startswith('NVIDIA A100-SXM4-40GB,'),status['gpu']
 driver=Path('/usr/lib64-nvidia/libGLX_nvidia.so.0');assert driver.is_file()
 (ROOT/'nvidia-vulkan.json').write_text(json.dumps({'file_format_version':'1.0.0','ICD':{'library_path':str(driver),'api_version':'1.3.0'}}))
 (ROOT/'nvidia-egl.json').write_text(json.dumps({'file_format_version':'1.0.0','ICD':{'library_path':'/usr/lib64-nvidia/libEGL_nvidia.so.0'}}))
 run(['apt-get','update'],timeout=600)
 run(['apt-get','install','-y','openbox','xdotool','x11-utils','libxkbcommon-x11-0'],timeout=600)
 source=ROOT/'source';run(['git','init',str(source)],env=env)
 run(['git','-C',str(source),'config','core.sparseCheckout','true'],env=env)
 run(['git','-C',str(source),'config','core.autocrlf','false'],env=env)
 paths=['Cargo.toml','Cargo.lock','build.rs','build_number.rs','LICENSE','THIRD_PARTY_LICENSES.txt','rust-toolchain','rust-toolchain.toml','.cargo/','.gitattributes','.gitignore','src/','updater/','tools/','examples/resident_authored_contract.rs','ui/','profiles/','settings.cfg','assets/sight_alignment.json','assets/animations.cfg']
 (source/'.git/info/sparse-checkout').write_text(''.join('/'+p+'\n' for p in paths))
 run(['git','-c','credential.helper=','-C',str(source),'fetch','--depth=1','--filter=blob:none','https://github.com/RHS059/rust_duty.git',PIN],env=env)
 run(['git','-C',str(source),'checkout','--detach','FETCH_HEAD'],env=env)
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD^{tree}'],env=env,text=True).strip()==TREE
 assert not (source/'assets/weapons').exists()
 candidate=ROOT/'build-source';candidate.mkdir()
 for p in source.iterdir():
  if p.name=='.git':continue
  assert not p.is_symlink()
  if p.is_dir():shutil.copytree(p,candidate/p.name)
  elif p.is_file():shutil.copy2(p,candidate/p.name)
 status['candidate_files']=inventory(candidate)
 for name,h in status['candidate_files'].items():assert hashlib.sha256(subprocess.check_output(['git','-C',str(source),'show','HEAD:'+name],env=env)).hexdigest()==h,name
 run([sys.executable,'-m','pip','install','Pillow==11.3.0','PyYAML==6.0.3'],timeout=600)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(candidate/'tools'))
 import run_cpu_image_preservation as guard
 guard.check_environment(os.environ)
 guard.check_cargo_configuration(candidate,env)
 urllib.request.urlretrieve('https://sh.rustup.rs',ROOT/'rustup-init.sh')
 run(['sh',str(ROOT/'rustup-init.sh'),'-y','--no-modify-path','--profile','minimal','--default-toolchain','1.99.0'],env=env,timeout=900)
 status['compiler']=subprocess.check_output(['rustc','-Vv'],env=env,text=True);assert 'release: 1.99.0\n' in status['compiler']
 status['cargo']=subprocess.check_output(['cargo','-Vv'],env=env,text=True);assert status['cargo'].startswith('cargo 1.99.0 ')
 def verify_tools(directory):
  guard.check_environment(os.environ);guard.check_cargo_configuration(directory,env)
  assert subprocess.check_output(['rustc','-Vv'],cwd=directory,env=env,text=True)==status['compiler']
  assert subprocess.check_output(['cargo','-Vv'],cwd=directory,env=env,text=True)==status['cargo']
 verify_tools(candidate)
 archive=ROOT/'public-assets-release.zip';urllib.request.urlretrieve(ASSET_URL,archive)
 assert archive.stat().st_size==102577561 and sha(archive)==ASSET_SHA
 assets=ROOT/'authored-assets';assets.mkdir();groups={'locomotion','walk','ads','directional','jump','reload'}
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  names=z.namelist();assert len(names)==len(set(names))
  total=0
  for i in z.infolist():
   p=Path(i.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and ':' not in i.filename and not stat.S_ISLNK(i.external_attr>>16)
   parts=p.parts
   if 'assets' not in parts:continue
   a=parts.index('assets');rel=Path(*parts[a:])
   if len(rel.parts)<2 or rel.parts[1] not in groups or i.is_dir():continue
   assert i.file_size<=128*1024*1024 and rel.suffix.lower() in {'.vra','.vrs','.vrm','.json','.gz','.md'}
   total+=i.file_size;assert total<2*1024**3
   dest=assets/rel;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_bytes(z.read(i))
 shutil.copy2(candidate/'assets/animations.cfg',assets/'assets/animations.cfg')
 asset_files=inventory(assets);assert len(asset_files)==77,len(asset_files)
 asset_receipt={'url':ASSET_URL,'archive_sha256':ASSET_SHA,'files':asset_files};(ROOT/'assets.json').write_text(json.dumps(asset_receipt,indent=2)+'\n')
 packages=ROOT/'packages';packages.mkdir()
 build=['cargo','build','--locked','--no-default-features','--features','wgpu-runtime','--release']
 run(build+['--bin','vector-range'],cwd=candidate,env=env)
 (packages/'candidate').mkdir();shutil.copy2(ROOT/'target/release/vector-range',packages/'candidate/vector-range')
 inputs={'source':PIN,'tree':TREE,'files':status['candidate_files'],'compiler':status['compiler'],'cargo':status['cargo'],'profile':'release','features':['wgpu-runtime'],'default_features':False,'asset_receipt_sha256':sha(ROOT/'assets.json')}
 (ROOT/'resident-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');receipt_hash=sha(ROOT/'resident-inputs.json')
 fixture_env=dict(env,PASS_SUBMISSION_SOURCE_SHA256=receipt_hash)
 run(build+['--example','resident_authored_contract'],cwd=candidate,env=fixture_env)
 shutil.copy2(ROOT/'target/release/examples/resident_authored_contract',packages/'candidate/resident_authored_contract')
 baseline=ROOT/'baseline-source';shutil.copytree(candidate,baseline)
 policy=baseline/'src/frame_resident_policy.rs';b=policy.read_bytes();assert b.count(b'pub const ENABLED: bool = true;')==1;policy.write_bytes(b.replace(b'pub const ENABLED: bool = true;',b'pub const ENABLED: bool = false;'))
 status['baseline_files']=inventory(baseline)
 assert [n for n,h in status['candidate_files'].items() if status['baseline_files'][n]!=h]==['src/frame_resident_policy.rs']
 verify_tools(baseline)
 run(build+['--bin','vector-range'],cwd=baseline,env=env)
 (packages/'baseline').mkdir();shutil.copy2(ROOT/'target/release/vector-range',packages/'baseline/vector-range')
 status['executables']={str(p.relative_to(packages)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in packages.rglob('*') if p.is_file()}
 assert inventory(candidate)==status['candidate_files'] and inventory(baseline)==status['baseline_files'] and inventory(assets)==asset_files
 verify_tools(candidate);verify_tools(baseline)
 status['fixture_receipt_sha256']=receipt_hash;status['asset_receipt_sha256']=sha(ROOT/'assets.json');status['passed']=True
except BaseException as error:status['error']=repr(error)
finally:
 try:
  if 'verify_tools' in globals():
   verify_tools(candidate)
   if 'baseline' in globals():verify_tools(baseline)
   status['final_tool_configuration_verified']=True
 except BaseException as error:status['final_tool_error']=repr(error);status['passed']=False
 status['finished']=time.time();save();print('RESIDENT_PREPARATION_FINISHED',json.dumps({k:v for k,v in status.items() if k not in ['candidate_files','baseline_files','commands']}),flush=True)
